"use strict";(self.rspackChunkpayme_mini_app=self.rspackChunkpayme_mini_app||[]).push([["1y"],{yS(t,e,n){n.d(e,{A:()=>h});var a=n("X"),c=n("AS"),s=n("sE"),i=n("MA"),o=n("tT"),l=n("wS"),d=n("u"),h=(0,d.forwardRef)((t,e)=>{let n,{defaultValue:h,placeholder:r="",onChangeValue:x}=t,[p]=(0,o.A)(),[g,u]=(0,d.useState)(h||""),[m,b]=(0,d.useState)(!1),f=(0,d.useRef)(null);return(0,d.useImperativeHandle)(e,()=>({value:g,setValue:t=>u(t)})),(0,a.jsxs)(c.A,{sx:{display:"flex",flexDirection:"row",pt:1.25,pb:1.25,pr:2,pl:2,borderRadius:2,border:"1px solid",borderColor:m?"primary.main":"colors.gray",width:"100%"},children:[(0,a.jsx)(c.A,{sx:{width:20,height:20},children:(n="light"===p?"#3D3D3D":"#FFFFFF",(0,a.jsxs)("svg",{width:"100%",height:"100%",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[(0,a.jsx)("path",{d:"M11.5 21C16.7467 21 21 16.7467 21 11.5C21 6.25329 16.7467 2 11.5 2C6.25329 2 2 6.25329 2 11.5C2 16.7467 6.25329 21 11.5 21Z",stroke:n,strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round"}),(0,a.jsx)("path",{d:"M22 22L20 20",stroke:n,strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round"})]}))}),(0,a.jsx)(s.A,{ref:f,inputProps:{style:{padding:0}},sx:{color:"text.primary",fontSize:14,paddingLeft:1.5,paddingRight:1.5,fontWeight:"normal","::placeholder":{color:"text.buttonDisable"},flex:1},fullWidth:!0,placeholder:r,disableUnderline:!0,value:g,onChange:t=>{x?.(t.target.value||""),u(t.target.value||"")},onFocus:()=>b(!0),onBlur:()=>b(!1)}),g&&(0,a.jsx)(i.A,{sx:{p:0},onClick:()=>{u(""),x?.(""),f.current?.focus()},children:(0,a.jsx)(l.A,{src:"/images/icons/clearIcon.svg",duration:0,width:20})})]})})},ze(t,e,n){var a=n("X"),c=n("qM"),s=n("AS"),i=n("mf"),o=n("mZ"),l=n("wS"),d=n("bC"),h=n("I1");n.d(e,{},{A:function(t){var e;let n,{item:r,onClick:x}=t,{t:p}=(0,h.B)();return(0,a.jsx)(c.A,{onClick:x,sx:{padding:0,paddingTop:1.5,paddingBottom:1.5,borderBottom:"1px solid",borderColor:"colors.light"},children:(0,a.jsxs)(s.A,{sx:{display:"flex",flexDirection:"row",pr:2.5,alignItems:"center"},children:[(0,a.jsx)(l.A,{src:"CREDIT"===r.gateway?"/images/iconCredit.png":(0,d.o)({type:d.W.METHOD,swiftCode:r.swiftCode}),width:32,duration:0,height:"auto",fit:"cover",iconWrapperStyle:{alignItems:"center"},showLoading:(0,a.jsx)(i.A,{animation:"wave",variant:"circular",width:32,height:32}),errorIcon:(0,a.jsx)(l.A,{src:"/images/bank_default.png",width:32,duration:0,height:"auto",fit:"cover",iconWrapperStyle:{alignItems:"center"},showLoading:(0,a.jsx)(i.A,{animation:"wave",variant:"circular",width:32,height:32})})}),(0,a.jsxs)(s.A,{sx:{display:"flex",flex:1,flexDirection:"column",pl:1.5},children:[(0,a.jsx)(o.A,{variant:"h4",sx:{textAlign:"left",color:"text.primary"},children:p(r?.shortName||"")}),(0,a.jsx)(s.A,{sx:{pt:.5}}),(0,a.jsx)(o.A,{variant:"subtitle1",className:"one-line",sx:{color:"text.gray"},children:(n=(e=r?.viName).indexOf("("))<=0?e:e.substring(0,n).trim()})]})]})})}})},FV(t,e,n){n.d(e,{GC:()=>a,Kh:()=>c,fc:()=>s,H6:()=>i});let a=`
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
</head>
<style type="text/css">
    body {
        font-family: "Times New Roman";
        font-size: 11pt;
    }

    p {
        margin: 0;
    }

    .col-2 {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
    }

    .mb-4 {
        margin-bottom: 16px;
    }

    .contract {
        max-width: 860px;
        margin: auto;
        padding: 10px 0;
    }

    .header {
        margin-bottom: 24px;
    }

    .header strong {
        text-align: center;
        display: block;
    }

    .table {
        width: 90%;
        margin: auto;
        text-align: start;
        margin-top: 5px;
    }

    .table td {
        font-weight: 700;
        padding: 4pt;
    }

    .toc {
        width: 100%;
        border-collapse: collapse;
    }

    .toc td {
        padding-top: 3px;
        padding-bottom: 3px;
        padding-right: 3px;
    }

    .toc td:first-child {
        padding-left: 3px;
        padding-right: 0;
    }

    .toc tr {
        vertical-align: baseline;
        padding: 5px;
        text-align: justify;
    }

    .toc-header {
        font-weight: 600;
        text-align: justify;
    }

    .toc-content {
        margin-top: 5px;
        text-align: justify;
    }

    .toc-index {
        width: 40px;
        text-align: justify;
    }

    .toc-child {
        width: 25px;
        text-align: justify;
    }

    .italic-text {
        font-style: italic;
        height: 80px;
        margin-top: 40px;
    }

    .bold-text {
        font-weight: 700;
    }

    .info {
        margin-top: 5px;
        margin-bottom: 5px;
    }
</style>

<body>
    <section class="contract">
        <div class="header">
            <p style="text-align: center">
                <strong style="font-size: 13pt">ĐIỀU KHOẢN V\xc0 ĐIỀU KIỆN </strong>
                (D\xe0nh cho kh\xe1ch h\xe0ng li\xean kết V\xed điện tử PAYME với TKTT/Thẻ BIDV)
            </p>
        </div>

        <div style="padding: 0 5% 0 5%">
            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index">1.</td>
                        <td class="toc-label">Định nghĩa:</td>
                    </tr>
                </table>
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">1.1</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Kh\xe1ch h\xe0ng (KH): </span>
                            l\xe0 kh\xe1ch h\xe0ng mở v\xe0 sử dụng TKTT/Thẻ, mở v\xe0 sử dụng V\xed điện tử
                            PAYME.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">1.2</td>
                        <td class="toc-label">
                            <span style="font-weight: 700">
                                BIDV <span style="font-weight: 400">hoặc</span> Ng\xe2n h\xe0ng:
                            </span>
                            l\xe0 Ng\xe2n h\xe0ng TMCP Đầu tư v\xe0 Ph\xe1t triển Việt Nam.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">1.3</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> PAYME: </span>
                            l\xe0 C\xf4ng ty Cổ phần C\xf4ng nghệ PAYME.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">1.4</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Website/Mobile App: </span>
                            l\xe0 trang web mang t\xean miền hoặc ứng dụng tr\xean nền tảng di động
                            do PAYME ph\xe1t triển, vận h\xe0nh v\xe0 quản l\xfd, cho ph\xe9p Kh\xe1ch h\xe0ng sử
                            dụng dịch vụ trung gian thanh to\xe1n được Ng\xe2n h\xe0ng Nh\xe0 nước cấp
                            ph\xe9p v\xe0 dịch vụ kh\xe1c của PAYME, được triển khai dưới thương hiệu
                            PAYME.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">1.5</td>
                        <td class="toc-label">
                            <span style="font-weight: 700">
                                Điều khoản v\xe0 Điều kiện (T&C):
                            </span>
                            l\xe0 bản điều khoản v\xe0 điều kiện n\xe0y d\xe0nh cho Kh\xe1ch h\xe0ng thực hiện
                            Li\xean kết để nạp, r\xfat V\xed điện tử, thanh to\xe1n h\xe0ng h\xf3a dịch vụ,
                            đăng k\xfd v\xe0 thực hiện thanh to\xe1n trực tiếp từ TKTT/Thẻ th\xf4ng qua
                            Website/App
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">1.6</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> TKTT/Thẻ: </span>
                            l\xe0 t\xe0i khoản thanh to\xe1n/thẻ ghi nợ nội địa do Kh\xe1ch h\xe0ng mở tại
                            BIDV
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">1.7</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> V\xed điện tử PAYME: </span>
                            l\xe0 t\xe0i khoản v\xed điện tử do PAYME tạo lập v\xe0 cung cấp cho Kh\xe1ch
                            h\xe0ng để truy cập, sử dụng c\xe1c dịch vụ do PAYME cung cấp.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">1.8</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Li\xean k\xeát: </span>
                            l\xe0 việc KH thực hiện li\xean kết giữa TKTT/Thẻ với V\xed điện tử
                            PAYME. C\xe1c th\xf4ng tin li\xean kết sẽ được mã hóa v\xe0 lưu lại cho c\xe1c
                            giao dịch nạp/r\xfat/thanh to\xe1n tại c\xe1c lần giao dịch tiếp theo m\xe0
                            KH kh\xf4ng cần phải nhập lại th\xf4ng tin.
                        </td>
                    </tr>
                </table>
            </div>

            <table cellspacing="0" cellpadding="0" class="toc">
                <tr class="toc-header">
                    <td class="toc-index">2.</td>
                    <td class="toc-label">Quyền v\xe0 tr\xe1ch nhiệm của Kh\xe1ch h\xe0ng</td>
                </tr>
                <tr class="toc-content">
                    <td class="toc-index">2.1</td>
                    <td class="toc-label">
                        <p>KH đã đọc, hiểu rõ v\xe0 đ\xf4̀ng \xfd r\xe0ng buộc bởi c\xe1c nội dung trong
                            bản Điều khoản điều kiện về mở, sử dụng t\xe0i khoản thanh to\xe1n,
                            ph\xe1t h\xe0nh v\xe0 sử dụng thẻ d\xe0nh cho KHCN đã k\xfd kết với BIDV, c\xe1c
                            thủ tục đăng k\xfd, tr\xecnh tự giao dịch v\xe0 c\xe1c hướng dẫn kh\xe1c của
                            BIDV được đăng tải tr\xean địa chỉ website:
                            <a style="color: blue" href="https://bidv.com.vn">https://bidv.com.vn</a>
                            trong từng thời kỳ.
                        </p>
                    </td>
                </tr>
                <tr class="toc-content">
                    <td class="toc-index">2.2</td>
                    <td class="toc-label">
                        <span>KH cam kết tu\xe2n thủ c\xe1c quy định của ph\xe1p luật, NHNN, quy định
                            của BIDV v\xe0 PAYME li\xean quan đến việc sử dụng TKTT/Thẻ v\xe0 V\xed điện
                            tử PAYME theo từng thời kỳ.</span>
                    </td>
                </tr>
                <tr class="toc-content">
                    <td class="toc-index">2.3</td>
                    <td class="toc-label">
                        <span>KH đ\xf4̀ng \xfd nhận c\xe1c th\xf4ng tin do BIDV gửi tới (th\xf4ng qua tin
                            nhắn, h\xf2m thư điện tử... v\xe0 c\xe1c k\xeanh kh\xe1c theo quy định của
                            BIDV) bao g\xf4̀m nhưng kh\xf4ng giới hạn ở: Th\xf4ng b\xe1o SMS OTP, Th\xf4ng
                            b\xe1o c\xe1c sản phẩm, dịch vụ mới, chương tr\xecnh khuyến mại, Th\xf4ng
                            b\xe1o kh\xe1c phục vụ cho việc thực hiện giao dịch thanh to\xe1n qua di
                            động với KH.</span>
                    </td>
                </tr>
                <tr class="toc-content">
                    <td class="toc-index">2.4</td>
                    <td class="toc-label">
                        <span>Trường hợp KH thực hiện li\xean kết TKTT/Thẻ để nạp/r\xfat V\xed điện tử
                            PAYME, KH đ\xf4̀ng \xfd để BIDV sử dụng c\xe1c th\xf4ng tin đã khai b\xe1o để
                            thực hiện c\xe1c giao dịch li\xean kết/nạp/thanh to\xe1n/r\xfat tiền V\xed điện
                            tử PAYME từ/v\xe0o TKTT/Thẻ, v\xe0 (ii) Chủ động tr\xedch nợ/ghi c\xf3
                            TKTT/Thẻ khi nhận được y\xeau cầu của KH khi nạp, r\xfat tiền V\xed điện
                            tử PAYME từ/v\xe0o TKTT/Thẻ.</span>
                    </td>
                </tr>
                <tr class="toc-content">
                    <td class="toc-index">2.5</td>
                    <td class="toc-label">
                        <span>Để đăng k\xfd hoặc thực hiện giao dịch của KH, KH c\xf3 thể cần x\xe1c
                            thực giao dịch bằng c\xe1c phương thức x\xe1c thực do PAYME v\xe0/hoặc
                            BIDV y\xeau cầu (*). Với c\xe1c giao dịch y\xeau cầu KH x\xe1c thực, KH c\xf3
                            tr\xe1ch nhiệm:</span>
                    </td>
                </tr>
                <tr class="toc-content">
                    <td class="toc-index"></td>
                    <td class="toc-label">
                        <table cellspacing="0" cellpadding="0" class="toc">
                            <tr class="toc-content">
                                <td class="toc-child">(i)</td>
                                <td class="toc-label">
                                    Bảo mật mật khẩu giao dịch/OTP v\xe0 c\xe1c yếu tố định danh kh\xe1c
                                    do BIDV/PAYME cấp v\xe0/hoặc do KH tự tạo theo y\xeau cầu tr\xean
                                    Website/Mobile App;
                                </td>
                            </tr>
                            <tr class="toc-content">
                                <td class="toc-child">(ii)</td>
                                <td class="toc-label">
                                    Sử dụng mọi biện ph\xe1p cần thiết để ngăn chặn việc sử dụng
                                    t\xednh năng li\xean kết/nạp/thanh to\xe1n/r\xfat V\xed điện tử PAYME từ
                                    TKTT/Thẻ th\xf4ng qua Website/Mobile App bởi những người kh\xf4ng
                                    c\xf3 thẩm quyền;
                                </td>
                            </tr>
                            <tr class="toc-content">
                                <td class="toc-child">(iii)</td>
                                <td class="toc-label">
                                    Chịu tr\xe1ch nhiệm trong trường hợp mật khẩu x\xe1c thực giao
                                    dịch/ OTP v\xe0 c\xe1c yếu tố định danh kh\xe1c bị mất, bị lợi dụng,
                                    tiết lộ v\xe0 sẽ chịu mọi rủi ro, thiệt hại g\xe2y ra do việc bị
                                    mất, lợi dụng v\xe0 tiết lộ đó.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr class="toc-content">
                    <td class="toc-index">2.6</td>
                    <td class="toc-label">
                        <span>KH chịu ho\xe0n to\xe0n tr\xe1ch nhiệm, BIDV được miễn tr\xe1ch to\xe0n bộ
                            trong trường hợp th\xf4ng tin của KH bị mất, bị lợi dụng hoặc tiết
                            lộ cho người kh\xe1c sử dụng/tiếp cận th\xf4ng tin li\xean quan đến số
                            TKTT/Thẻ/V\xed điện tử PAYME, m\xe3 bảo mật in tr\xean thẻ, c\xe1c mật khẩu
                            PayME của KH tại BIDV hoặc PAYME.</span>
                    </td>
                </tr>
            </table>

            <table cellspacing="0" cellpadding="0" class="toc">
                <tr class="toc-header">
                    <td class="toc-index">3.</td>
                    <td class="toc-label">Sửa đổi Điều khoản v\xe0 Điều kiện</td>
                </tr>
            </table>
            <p>
                Bản Điều kiện v\xe0 Điều khoản n\xe0y c\xf3 thể được sửa đổi v\xe0 bổ sung trong
                từng thời kỳ, th\xf4ng qua việc cập nhật l\xean Website/Mobile App. Việc
                KH tiếp tục sử dụng t\xednh năng li\xean kết/nạp/ r\xfat V\xed điện tử PAYME với
                TKTT/Thẻ v\xe0/hoặc t\xednh năng thanh to\xe1n trực tiếp từ TKTT/Thẻ th\xf4ng
                qua Website/Mobile App sau thời điểm c\xe1c Điều khoản v\xe0 Điều kiện
                được sửa đổi, bổ sung c\xf3 hiệu lực được hiểu l\xe0 KH chấp thuận to\xe0n bộ
                những nội dung sửa đổi, bổ sung đó v\xe0 kh\xf4ng cần phải c\xf3 th\xeam bất kỳ
                chấp thuận n\xe0o kh\xe1c của KH.
            </p>
            <p style="font-weight: 600; margin-top: 5pt; margin-bottom: 5pt;">
                (*) Phương thức xác thực đ\xf4́i với từng loại giao dịch:
            </p>
            <div>
                <table border="1" cellspacing="0" cellpadding="8" style="border-collapse: collapse; width: 100%;">
                    <thead>
                        <tr>
                            <th colspan="2"><strong>Loại giao dịch</strong></th>
                            <th><strong>Phương thức x\xe1c thực</strong></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="2">Li\xean kết V\xed điện tử với TKTT/Thẻ</td>
                            <td>OTP do BIDV gửi tới số điện thoại của KH lưu tại hệ thống BIDV</td>
                        </tr>
                        <tr>
                            <td rowspan="2">
                                <div>Nạp tiền thanh to\xe1n h\xe0ng h\xf3a, dịch vụ trực tiếp từ TKTT/Thẻ th\xf4ng qua
                                    Website/Mobile App</div>
                            </td>
                            <td>Số tiền giao dịch ≤ 2triệu đ\xf4̀ng/giao dịch v\xe0 tổng số tiền c\xe1c giao dịch ≤ 2 triệu đ\xf4̀ng
                                n\xe0y ≤ 5 triệu đ\xf4̀ng/ng\xe0y/KH</td>
                            <td>OTP do PAYME gửi tới số điện thoại của KH</td>
                        </tr>
                        <tr>
                            <td>Trường hợp c\xf2n lại</td>
                            <td>
                                OTP do BIDV gửi tới số điện thoại của KH lưu tại hệ thống BIDV
                                v\xe0/hoặc phương thức x\xe1c thực bằng Sinh trắc học tại k\xeanh BIDV Smartbanking
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</body>

</html>
`,c=`
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
</head>
<style type="text/css">
    body {
        font-family: "Times New Roman";
        font-size: 11pt;
    }

    p {
        margin: 0;
    }

    .col-2 {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
    }

    .mb-4 {
        margin-bottom: 16px;
    }

    .contract {
        max-width: 860px;
        margin: auto;
        padding: 10px 0;
    }

    .header {
        margin-bottom: 24px;
    }

    .header strong {
        text-align: center;
        display: block;
    }

    .table {
        width: 90%;
        margin: auto;
        text-align: start;
        margin-top: 5px;
    }

    .table td {
        font-weight: 700;
        padding: 4pt;
    }

    .toc {
        width: 100%;
        border-collapse: collapse;
    }

    .toc td {
        padding-top: 3px;
        padding-bottom: 3px;
        padding-right: 3px;
    }

    .toc td:first-child {
        padding-left: 3px;
        padding-right: 0;
    }

    .toc tr {
        vertical-align: baseline;
        padding: 5px;
        text-align: justify;
    }

    .toc-header {
        font-weight: 600;
        text-align: justify;
    }

    .toc-content {
        margin-top: 5px;
        text-align: justify;
    }

    .toc-index {
        width: 40px;
        text-align: justify;
    }

    .toc-child {
        width: 25px;
        text-align: justify;
    }

    .italic-text {
        font-style: italic;
        height: 80px;
        margin-top: 40px;
    }

    .bold-text {
        font-weight: 700;
    }

    .info {
        margin-top: 5px;
        margin-bottom: 5px;
    }
</style>

<body>
    <section class="contract">
        <div class="header">
            <p style="text-align: center">
                <strong style="font-size: 13pt">TERMS AND CONDITIONS</strong>
                (For customers linking PAYME e-wallet with BIDV current account/card)
            </p>
        </div>

        <div style="padding: 0 5% 0 5%">
            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index">1.</td>
                        <td class="toc-label">Definitions:</td>
                    </tr>
                </table>

                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">1.1</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Customer (KH): </span>
                            refers to a customer who opens and uses a current account/card, or opens and uses an e-wallet from PAYME.
                        </td>
                    </tr>

                    <tr class="toc-content">
                        <td class="toc-index">1.2</td>
                        <td class="toc-label">
                            <span style="font-weight: 700">
                                BIDV or Bank:
                            </span>
                            refers to the Joint Stock Commercial Bank for Investment and Development of Vietnam.
                        </td>
                    </tr>

                    <tr class="toc-content">
                        <td class="toc-index">1.3</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> PAYME: </span>
                            is PAYME Technology Joint Stock Company.
                        </td>
                    </tr>

                    <tr class="toc-content">
                        <td class="toc-index">1.4</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Website/Mobile App: </span>
                            is a website with a domain name or a mobile application developed, operated, and managed by PAYME, allowing customers to use intermediary payment services licensed by the State Bank of Vietnam and other PAYME services, implemented under the PAYME brand.
                        </td>
                    </tr>

                    <tr class="toc-content">
                        <td class="toc-index">1.5</td>
                        <td class="toc-label">
                            <span style="font-weight: 700">
                                Terms and Conditions (T&amp;C):
                            </span>
                            These terms and conditions apply to Customers who link their accounts to top up and withdraw from e-wallets, pay for goods and services, register for and make direct payments from their current account/card via the Website/App.
                        </td>
                    </tr>

                    <tr class="toc-content">
                        <td class="toc-index">1.6</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Payment Account/Card: </span>
                            This refers to a domestic payment account/debit card opened by the Customer at BIDV.
                        </td>
                    </tr>

                    <tr class="toc-content">
                        <td class="toc-index">1.7</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> PAYME e-wallet: </span>
                            This is an e-wallet account created and provided by PAYME to customers to access and use the services offered by PAYME.
                        </td>
                    </tr>

                    <tr class="toc-content">
                        <td class="toc-index">1.8</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Linking: </span>
                            This refers to the process where the customer links their current account/card with their PAYME e-wallet. The linked information will be encrypted and stored for subsequent deposit/withdrawal/payment transactions, eliminating the need for the customer to re-enter the information.
                        </td>
                    </tr>
                </table>
            </div>

            <table cellspacing="0" cellpadding="0" class="toc">
                <tr class="toc-header">
                    <td class="toc-index">2.</td>
                    <td class="toc-label">Rights and Responsibilities of the Customer</td>
                </tr>

                <tr class="toc-content">
                    <td class="toc-index">2.1</td>
                    <td class="toc-label">
                        <p>
                            The Customer acknowledges that they have read, understood, and agreed to be bound by the Terms and Conditions for opening and using payment accounts, as well as the issuance and usage of cards for individual customers signed with BIDV. This includes all registration procedures, transaction processes, and other instructions issued by BIDV on their official website
                            <a style="color: blue" href="https://bidv.com.vn">https://bidv.com.vn</a> from time to time.
                        </p>
                    </td>
                </tr>

                <tr class="toc-content">
                    <td class="toc-index">2.2</td>
                    <td class="toc-label">
                        <span>
                            The Customer commits to complying with all applicable laws, regulations of the State Bank of Vietnam, and the specific policies of BIDV and PAYME regarding the use of payment accounts/cards and PAYME e-wallets, as updated from time to time.
                        </span>
                    </td>
                </tr>

                <tr class="toc-content">
                    <td class="toc-index">2.3</td>
                    <td class="toc-label">
                        <span>
                            The Customer agrees to receive communications from BIDV (via SMS, email, and other regulated channels), including but not limited to: SMS OTP notifications, updates on new products and services, promotional programs, and other relevant notifications for conducting mobile payment transactions.
                        </span>
                    </td>
                </tr>

                <tr class="toc-content">
                    <td class="toc-index">2.4</td>
                    <td class="toc-label">
                        <span>
                            In cases where the Customer links their payment account/card to a PAYME e-wallet for deposits or withdrawals:
                        </span>
                    </td>
                </tr>
                <tr class="toc-content">
                    <td class="toc-index"></td>
                    <td class="toc-label">
                        <table cellspacing="0" cellpadding="0" class="toc">
                            <tr class="toc-content">
                                <td class="toc-child">(i)</td>
                                <td class="toc-label">
                                    The Customer authorizes BIDV to use their declared information to execute linking, deposit, payment, and withdrawal transactions to/from the PAYME e-wallet.
                                </td>
                            </tr>

                            <tr class="toc-content">
                                <td class="toc-child">(ii)</td>
                                <td class="toc-label">
                                    BIDV is authorized to proactively debit or credit the payment account/card upon receiving the Customer’s request for depositing to or withdrawing from the PAYME e-wallet.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <tr class="toc-content">
                    <td class="toc-index">2.5</td>
                    <td class="toc-label">
                        <span>
                            To register or conduct transactions, Customers may be required to use authentication methods specified by PAYME and/or BIDV (*). For transactions requiring authentication, Customers are responsible for:
                        </span>
                    </td>
                </tr>

                <tr class="toc-content">
                    <td class="toc-index"></td>
                    <td class="toc-label">
                        <table cellspacing="0" cellpadding="0" class="toc">
                            <tr class="toc-content">
                                <td class="toc-child">(i)</td>
                                <td class="toc-label">
                                    Securing transaction passwords, OTPs, and other identifying factors issued by BIDV/PAYME or created by the Customer on the Website/Mobile App.
                                </td>
                            </tr>

                            <tr class="toc-content">
                                <td class="toc-child">(ii)</td>
                                <td class="toc-label">
                                    Taking all necessary measures to prevent unauthorized persons from accessing the linking, deposit, payment, or withdrawal features via the Website/Mobile App.
                                </td>
                            </tr>

                            <tr class="toc-content">
                                <td class="toc-child">(iii)</td>
                                <td class="toc-label">
                                    Assuming full responsibility if authentication passwords, OTPs, or other identifying factors are lost, misused, or disclosed. The Customer shall bear all risks and damages resulting from such incidents.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <tr class="toc-content">
                    <td class="toc-index">2.6</td>
                    <td class="toc-label">
                        <span>
                            The Customer is solely responsible, and BIDV is fully exempt from liability, in the event that the Customer's information is lost, misused, or disclosed to third parties. This includes information related to the payment account number, card details, PAYME e-wallet, security codes (CVV/CVC), or any passwords used at BIDV or PAYME.
                        </span>
                    </td>
                </tr>
            </table>

            <table cellspacing="0" cellpadding="0" class="toc">
                <tr class="toc-header">
                    <td class="toc-index">3.</td>
                    <td class="toc-label">Amendments to the Terms and Conditions</td>
                </tr>
            </table>

            <p>
                These Terms and Conditions may be amended or supplemented from time to time via updates on the Website/Mobile App. The Customer’s continued use of the linking, deposit, or withdrawal features between the PAYME e-wallet and their payment account/card, or the continued making of direct payments after the effective date of such amendments, shall constitute the Customer’s full acceptance of the revised Terms and Conditions. No further explicit consent from the Customer shall be required.
            </p>

            <p style="font-weight: 600; margin-top: 5pt; margin-bottom: 5pt;">
                (*) Authentication method for each type of transaction:
            </p>

            <div>
                <table border="1" cellspacing="0" cellpadding="8" style="border-collapse: collapse; width: 100%;">
                    <thead>
                        <tr>
                            <th colspan="2"><strong>Transaction Type</strong></th>
                            <th><strong>Authentication Method</strong></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="2">Link E-wallet with Account/Card</td>
                            <td>
                                OTP sent by BIDV to the customer's registered phone number.
                            </td>
                        </tr>

                        <tr>
                            <td rowspan="2">
                                <div>
                                    Top-up and Payment for goods/services directly from Account/Card via Website/Mobile App
                                </div>
                            </td>
                            <td>
                                Transaction value ≤ 2 million VND/transaction and total daily volume ≤ 5 million VND/customer.
                            </td>
                            <td>
                                OTP sent by PAYME to the customer's phone number.
                            </td>
                        </tr>

                        <tr>
                            <td>Other cases</td>
                            <td>
                                OTP sent by BIDV to the customer's registered phone number and/or Biometric authentication via BIDV SmartBanking.
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</body>

</html>
`,s=`
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
</head>
<style type="text/css">
    body {
        font-family: "Times New Roman";
        font-size: 11pt;
    }

    p {
        margin: 0;
    }

    .col-2 {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
    }

    .mb-4 {
        margin-bottom: 16px;
    }

    .contract {
        max-width: 860px;
        margin: auto;
        padding: 10px 0;
    }

    .header {
        margin-bottom: 24px;
    }

    .header strong {
        text-align: center;
        display: block;
    }

    .table {
        width: 90%;
        margin: auto;
        text-align: start;
        margin-top: 5px;
    }

    .table td {
        font-weight: 700;
        padding: 4pt;
    }

    .toc {
        width: 100%;
        border-collapse: collapse;
    }

    .toc td {
        padding-top: 3px;
        padding-bottom: 3px;
        padding-right: 3px;
    }

    .toc td:first-child {
        padding-left: 3px;
        padding-right: 0;
    }

    .toc tr {
        vertical-align: baseline;
        padding: 5px;
        text-align: justify;
    }

    .toc1 {
        width: 100%;
    }

    .toc1 td {
        padding-top: 3px;
        padding-bottom: 3px;
        padding-right: 3px;
    }

    .toc1 td:first-child {
        padding-left: 3px;
        padding-right: 0;
    }

    .toc1 tr {
        vertical-align: baseline;
        padding: 5px;
        text-align: justify;
    }

    .toc-header {
        font-weight: 600;
        text-align: justify;
    }

    .toc-content {
        margin-top: 5px;
        text-align: justify;
    }

    .toc-index-title {
        width: 50px;
        text-align: justify;
    }

    .toc-index {
        width: 30px;
        text-align: justify;
    }

    .toc-child {
        width: 25px;
        text-align: justify;
    }

    .italic-text {
        font-style: italic;
        height: 80px;
        margin-top: 40px;
    }

    .bold-text {
        font-weight: 700;
    }

    .info {
        margin-top: 5px;
        margin-bottom: 5px;
    }
</style>

<body>
    <section class="contract">
        <div class="header">
            <p style="text-align: center">
                <strong style="font-size: 13pt">ĐIỀU KHOẢN V\xc0 ĐIỀU KIỆN </strong>
                (\xc1p dụng cho Kh\xe1ch h\xe0ng li\xean kết V\xed điện tử với TKTT/Thẻ BVBank, thực hiện giao dịch từ TKTT/Thẻ th\xf4ng
                qua V\xed điện tử PAYME)
            </p>
        </div>

        <div style="padding: 0 5% 0 5%">
            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index-title">Điều 1.</td>
                        <td class="toc-label">Giải th\xedch từ ngữ:</td>
                    </tr>
                </table>
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">1.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Kh\xe1ch h\xe0ng: </span>
                            L\xe0 Kh\xe1ch h\xe0ng c\xe1 nh\xe2n đang sử dụng ứng dụng V\xed điện tử của PayME v\xe0 sử dụng
                            T\xe0i khoản thanh to\xe1n, Thẻ ghi nợ của BVBank, c\xf3 nhu cầu v\xe0 đủ điều kiện li\xean kết v\xe0 sử dụng
                            V\xed điện tử với T\xe0i khoản thanh to\xe1n hoặc Thẻ ghi nợ.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">2. </td>
                        <td class="toc-label">
                            <span style="font-weight: 700">
                                Ng\xe2n h\xe0ng/BVBank:
                            </span>
                            L\xe0 Ng\xe2n h\xe0ng Thương mại Cổ phần Bản Việt.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">3.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Tổ chức cung ứng V\xed điện tử (Đối t\xe1c): </span>
                            L\xe0 C\xf4ng ty cổ phẩn c\xf4ng nghệ PayME, l\xe0 đối t\xe1c hợp t\xe1c với BVBank cung cấp dịch vụ trung
                            gian thanh to\xe1n cho Kh\xe1ch h\xe0ng th\xf4ng qua ứng dụng V\xed PayME, sau đ\xe2y gọi tắt l\xe0 “Đối t\xe1c li\xean
                            kết” hoặc “Đối t\xe1c”.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">4.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> K\xeanh đối t\xe1c: </span>
                            L\xe0 Website/ứng dụng Đối t\xe1c/k\xeanh giao dịch bằng phương tiện điện tử của Đối t\xe1c.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">5.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700">
                                V\xed điện tử/V\xed PayME:
                            </span>
                            L\xe0 phương tiện lưu trữ tiền điện tử hay c\xf2n gọi l\xe0 T\xe0i khoản V\xed điện tử PayME cung cấp cho
                            Kh\xe1ch h\xe0ng, cho ph\xe9p Kh\xe1ch h\xe0ng sử dụng dịch vụ th\xf4ng qua ứng dụng V\xed PayME.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">6.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Ứng dụng V\xed điện tử/ Ứng dụng V\xed PayME: </span>
                            L\xe0 một ứng dụng tr\xean điện thoại di động thuộc quyền sở hữu, quản l\xfd, sử dụng v\xe0 vận h\xe0nh hợp
                            ph\xe1p của PAYME để cung cấp c\xe1c dịch vụ trung gian thanh to\xe1n được Ng\xe2n h\xe0ng Nh\xe0 nước Việt
                            Nam cấp ph\xe9p v\xe0 c\xe1c dịch vụ kh\xe1c triển khai dưới thương hiệu V\xed PayME.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">7.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> T\xe0i khoản thanh to\xe1n/TKTT: </span>
                            L\xe0 t\xe0i khoản thanh to\xe1n VND của Kh\xe1ch h\xe0ng mở tại BVBank.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">8.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Thẻ ghi nợ/Thẻ: </span>
                            L\xe0 thẻ ghi nợ của Kh\xe1ch h\xe0ng mở tại BVBank.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">9.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Li\xean kết V\xed điện tử/Li\xean kết: </span>
                            Là việc Kh\xe1ch h\xe0ng thực hiện li\xean kết V\xed điện tử PayME của Kh\xe1ch h\xe0ng với TKTT/Thẻ của
                            ch\xednh Kh\xe1ch h\xe0ng mở tại BVBank để thực hiện c\xe1c giao dịch nạp tiền v\xe0o, r\xfat tiền ra khỏi V\xed
                            điện tử, chuyển tiền, thanh to\xe1n hoặc c\xe1c giao dịch hợp ph\xe1p kh\xe1c th\xf4ng qua TKTT/Thẻ đ\xe3 li\xean
                            kết theo quy định ph\xe1p luật.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">10.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Hủy li\xean kết: </span>
                            L\xe0 việc Kh\xe1ch h\xe0ng thực hiện hủy li\xean kết V\xed điện tử với TKTT/Thẻ BVBank tr\xean ứng dụng Đối
                            t\xe1c hoặc c\xe1c k\xeanh triển khai do BVBank v\xe0 Đối t\xe1c hợp t\xe1c cung cấp.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">11.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> OTP (One Time Password): </span>
                            l\xe0 h\xecnh thức x\xe1c nhận giao dịch điện tử bằng m\xe3 kh\xf3a b\xed mật trong đ\xf3 m\xe3 kh\xf3a b\xed mật c\xf3 gi\xe1
                            trị sử dụng một lần v\xe0 c\xf3 hiệu lực trong một khoảng thời gian nhất định. OTP được BVBank gửi
                            cho Kh\xe1ch h\xe0ng qua SMS, token, email hoặc một phương thức/thiết bị x\xe1c thực kh\xe1c do BVBank
                            triển khai ph\xf9 hợp quy định của Ph\xe1p luật v\xe0 c\xf4ng bố từng thời kỳ.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">12.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> M\xe3 PIN: </span>
                            L\xe0 h\xecnh thức x\xe1c nhận bằng m\xe3 kh\xf3a b\xed mật trong đ\xf3 m\xe3 kh\xf3a b\xed mật được tạo từ một chuỗi c\xe1c
                            chữ số. Kh\xe1ch h\xe0ng nhập m\xe3 PIN tr\xean giao diện x\xe1c nhận giao dịch để x\xe1c nhận giao dịch.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">13.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Sinh trắc học: </span>
                            L\xe0 những thuộc t\xednh vật l\xfd, đặc điểm sinh học c\xe1 biệt v\xe0 ổn định của một người để nhận diện,
                            ph\xe2n biệt người n\xe0y với người kh\xe1c như ảnh khu\xf4n mặt, v\xe2n tay, mống mắt, giọng n\xf3i….Sinh
                            trắc học \xe1p dụng tại Điều khoản v\xe0 điều kiện n\xe0y l\xe0 dữ liệu sinh trắc học khu\xf4n mặt của
                            Kh\xe1ch h\xe0ng được BVBank thu thập, kiểm tra, đối chiếu, x\xe1c minh ch\xednh x\xe1c Kh\xe1ch h\xe0ng theo c\xe1c
                            biện ph\xe1p c\xf4ng nghệ được BVBank triển khai ph\xf9 hợp theo quy định của NHNN từng thời kỳ.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">14.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> H\xecnh thức x\xe1c nhận giao dịch Đối t\xe1c: </span>
                            L\xe0 phương thức xác nhận giao dịch do Đối t\xe1c cung ứng dịch vụ V\xed điện tử y\xeau cầu, được \xe1p
                            dụng tr\xean K\xeanh Đối t\xe1c để Kh\xe1ch h\xe0ng x\xe1c nhận đồng \xfd nội dung hoặc k\xfd kết hợp đồng hoặc x\xe1c
                            nhận giao dịch, bao gồm m\xe3 PIN v\xe0 c\xe1c biện ph\xe1p kh\xe1c theo quy định của Pháp lu\xe2̣t.
                        </td>
                    </tr>
                </table>
            </div>

            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index-title">Điều 2.</td>
                        <td class="toc-label">Li\xean kết V\xed điện tử với TKTT/Thẻ BVBank v\xe0 giao dịch bằng TKTT/Thẻ đ\xe3 li\xean
                            kết</td>
                    </tr>
                </table>
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">1. </td>
                        <td class="toc-label">
                            <span>
                                Điều kiện li\xean kết với TKTT/Thẻ BVBank
                            </span>
                        </td>
                    </tr>
                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px">
                        <tr class="toc-content">
                            <td class="toc-index">a) </td>
                            <td class="toc-label">
                                <span>
                                    TKTT hoặc Thẻ của Kh\xe1ch h\xe0ng sử dụng để li\xean kết với V\xed điện tử phải c\xf3 trạng th\xe1i
                                    hoạt
                                    động v\xe0 kh\xf4ng bị hạn chế giao dịch bằng phương tiện điện tử.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">b) </td>
                            <td class="toc-label">
                                <span>
                                    Kh\xe1ch h\xe0ng đ\xe3 định danh V\xed điện tử với đầy đủ c\xe1c th\xf4ng tin v\xe0 hồ sơ mở V\xed điện tử
                                    theo
                                    quy định của NHNN từng thời kỳ.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">c) </td>
                            <td class="toc-label">
                                <span>
                                    Giấy tờ t\xf9y th\xe2n tại BVBank c\xf2n hiệu lực v\xe0 Kh\xe1ch h\xe0ng đ\xe3 được BVBank ho\xe0n th\xe0nh
                                    việc
                                    x\xe1c minh th\xf4ng tin nhận biết KH, đối chiếu khớp đ\xfang th\xf4ng tin Sinh trắc học của
                                    Kh\xe1ch
                                    h\xe0ng với th\xf4ng tin Sinh trắc học được lưu tại Cơ sở dữ liệu quốc gia về d\xe2n cư; hoặc
                                    với
                                    dữ liệu Sinh trắc học được thu thập th\xf4ng qua gặp mặt trực tiếp Kh\xe1ch h\xe0ng đối với
                                    trường hợp l\xe0 người nước ngo\xe0i kh\xf4ng sử dụng danh t\xednh điện tử, người gốc Việt Nam
                                    chưa
                                    x\xe1c định được quốc tịch theo c\xe1c biện ph\xe1p c\xf4ng nghệ được BVBank triển khai ph\xf9 hợp
                                    theo
                                    quy định của NHNN từng thời kỳ.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">d) </td>
                            <td class="toc-label">
                                <span>
                                    Số điện thoại v\xe0 th\xf4ng tin giấy tờ t\xf9y th\xe2n đăng k\xfd V\xed điện tử phải tr\xf9ng khớp với
                                    th\xf4ng
                                    tin đăng k\xfd tại BVBank.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">e) </td>
                            <td class="toc-label">
                                <span>
                                    Kh\xe1ch h\xe0ng đ\xe3 đăng k\xfd sử dụng dịch vụ Ng\xe2n h\xe0ng điện tử của BVBank.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">f) </td>
                            <td class="toc-label">
                                <span>
                                    Đ\xe3 đọc v\xe0 đồng \xfd Điều khoản v\xe0 điều kiện n\xe0y.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">g) </td>
                            <td class="toc-label">
                                <span>
                                    Đ\xe1p ứng c\xe1c điều kiện kh\xe1c theo quy định của Đối t\xe1c cung cấp V\xed điện tử.
                                </span>
                            </td>
                        </tr>
                    </table>
                </table>
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">2. </td>
                        <td class="toc-label">
                            <span>
                                Bằng việc đăng k\xfd li\xean kết V\xed điện tử với TKTT/Thẻ BVBank th\xf4ng qua ứng dụng V\xed PayME,
                                Kh\xe1ch h\xe0ng khẳng định m\xecnh hiểu, biết r\xf5 v\xe0 x\xe1c nhận đồng \xfd:
                            </span>
                        </td>
                    </tr>
                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">a) </td>
                            <td class="toc-label">
                                <span>
                                    Đồng \xfd cho PAYME tiếp nhận, chia sẻ th\xf4ng tin Kh\xe1ch h\xe0ng v\xe0 chuyển tiếp dữ liệu li\xean
                                    kết, chỉ thị v\xe0 c\xe1c x\xe1c nhận của Kh\xe1ch h\xe0ng được thực hiện tr\xean ứng dụng V\xed PayME
                                    đến hệ
                                    thống BVBank để thực hiện li\xean kết V\xed điện tử v\xe0 xử l\xfd c\xe1c giao dịch thanh to\xe1n,
                                    chuyển
                                    tiền, nạp, r\xfat tiền V\xed điện tử từ/về TKTT hoặc Thẻ của Kh\xe1ch h\xe0ng. Mọi sự đồng \xfd
                                    của
                                    Kh\xe1ch h\xe0ng tại Bản điều khoản điều kiện n\xe0y l\xe0 dựa tr\xean cơ sở tự nguyện v\xe0 hiểu biết
                                    r\xf5
                                    r\xe0ng về c\xe1c quyền v\xe0 nghĩa vụ của c\xe1c B\xean theo c\xe1c quy định ph\xe1p luật c\xf3 li\xean quan
                                    (bao
                                    gồm việc BVBank được thực hiện to\xe0n bộ c\xe1c quyền của B\xean Kiểm So\xe1t v\xe0 Xử l\xfd dữ liệu
                                    theo
                                    quy định của ph\xe1p luật về Bảo vệ dữ liệu c\xe1 nh\xe2n).
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">b) </td>
                            <td class="toc-label">
                                <span>
                                    Để li\xean kết V\xed điện tử với TKTT/Thẻ hoặc thực hiện giao dịch bằng TKTT/Thẻ đ\xe3 li\xean
                                    kết,
                                    Kh\xe1ch h\xe0ng cần x\xe1c nhận giao dịch bằng các H\xecnh thức x\xe1c nhận giao dịch Đối t\xe1c v\xe0
                                    phải
                                    x\xe1c nhận giao dịch bằng OTP hoặc c\xe1c h\xecnh thức x\xe1c nhận giao dịch kh\xe1c do BVBank
                                    cung
                                    c\xe2́p ph\xf9 hợp với quy định ph\xe1p luật từng thời kỳ (ngoại từ c\xe1c giao dịch m\xe0 BVBank
                                    chủ
                                    động tr\xedch nợ theo quy định tại điểm c, điểm d khoản 2 điều n\xe0y)
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">c) </td>
                            <td class="toc-label">
                                <span>
                                    Đồng \xfd để BVBank được quyền chủ động tr\xedch Nợ TKTT (hoặc TKTT gắn với Thẻ ghi nợ) đ\xe3
                                    li\xean kết với V\xed điện tử để thực hiện:
                                </span>
                            </td>
                        </tr>
                        <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 60px;">
                            <tr class="toc-content">
                                <td class="toc-index">i. </td>
                                <td class="toc-label">
                                    <span>
                                        C\xe1c giao dịch qua K\xeanh đối t\xe1c gồm: Nạp tiền, chuyển tiền, thanh to\xe1n h\xe0ng h\xf3a,
                                        dịch vụ v\xe0 c\xe1c giao dịch kh\xe1c theo quy định của ph\xe1p luật th\xf4ng qua TKTT/Thẻ đ\xe3
                                        li\xean kết với V\xed điện tử.
                                    </span>
                                </td>
                            </tr>
                            <tr class="toc-content">
                                <td class="toc-index">ii. </td>
                                <td class="toc-label">
                                    <span>
                                        Hạn mức giao dịch được BVBank quy định từng thời kỳ, tu\xe2n thủ quy định của ph\xe1p
                                        luật.
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </table>
                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">d) </td>
                            <td class="toc-label">
                                <span>
                                    Đối với c\xe1c giao dịch m\xe0 BVBank chủ động tr\xedch nợ TKTT (hoặc TKTT gắn với Thẻ ghi
                                    nợ) đ\xe3
                                    li\xean kết với V\xed điện tử:
                                </span>
                            </td>
                        </tr>
                        <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 60px;">
                            <tr class="toc-content">
                                <td class="toc-index">i. </td>
                                <td class="toc-label">
                                    <span>
                                        Kh\xe1ch h\xe0ng thực hiện x\xe1c thực theo H\xecnh thức x\xe1c nhận giao dịch Đối t\xe1c
                                    </span>
                                </td>
                            </tr>
                            <tr class="toc-content">
                                <td class="toc-index">ii. </td>
                                <td class="toc-label">
                                    <span>
                                        Kh\xe1ch h\xe0ng đồng \xfd đăng k\xfd để BVBank x\xe1c nhận c\xe1c giao dịch n\xe0y th\xf4ng qua kết nối
                                        giữa BVBank v\xe0 Đối t\xe1c V\xed điện tử, th\xf4ng tin li\xean kết TKTT (hoặc TKTT gắn với
                                        Thẻ ghi nợ) đ\xe3 li\xean kết với V\xed điện tử.
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </table>
                </table>
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">3.</td>
                        <td class="toc-label">
                            <span> C\xe1c phương thức xác nhận giao dịch sẽ được quy định \xe1p dụng đối với từng loại giao
                                dịch cụ thể tr\xean cơ sở đ\xe1nh gi\xe1 rủi ro được BVBank quy định từng thời kỳ v\xe0 tu\xe2n thủ quy
                                định của ph\xe1p luật. </span>
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">4.</td>
                        <td class="toc-label">
                            <span> Kh\xe1ch h\xe0ng hủy li\xean kết TKTT/Thẻ với V\xed điện tử tr\xean c\xe1c K\xeanh đối t\xe1c triển khai từng
                                thời kỳ. </span>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index-title">Điều 3.</td>
                        <td class="toc-label">Quyền v\xe0 nghĩa vụ của Kh\xe1ch h\xe0ng</td>
                    </tr>
                </table>
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">1. </td>
                        <td class="toc-label">
                            <span style="font-weight: 700;">
                                Quyền của Kh\xe1ch h\xe0ng
                            </span>
                        </td>
                    </tr>
                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">a) </td>
                            <td class="toc-label">
                                <span>
                                    Li\xean kết hoặc chấm dứt li\xean kết V\xed điện tử với TKTT/ Thẻ theo quy định BVBank.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">b) </td>
                            <td class="toc-label">
                                <span>
                                    Được thực hiện c\xe1c giao dịch nạp, r\xfat, chuyển tiền, thanh to\xe1n từ V\xed điện tử từ/v\xe0o
                                    TKTT
                                    hoặc Thẻ v\xe0 c\xe1c giao dịch hợp ph\xe1p kh\xe1c sau khi li\xean kết th\xe0nh c\xf4ng.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">c) </td>
                            <td class="toc-label">
                                <span>
                                    C\xe1c quyền kh\xe1c theo quy định tại Bản điều khoản, điều kiện n\xe0y v\xe0 c\xe1c văn bản thỏa
                                    thuận
                                    kh\xe1c giữa c\xe1c b\xean v\xe0 quy định của ph\xe1p luật li\xean quan.
                                </span>
                            </td>
                        </tr>
                    </table>
                </table>
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">2. </td>
                        <td class="toc-label">
                            <span style="font-weight: 700;">
                                Nghĩa vụ của Kh\xe1ch h\xe0ng
                            </span>
                        </td>
                    </tr>
                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">a) </td>
                            <td class="toc-label">
                                <span>
                                    Tu\xe2n thủ quy đinh tại Điều khoản v\xe0 điều kiện n\xe0y v\xe0 c\xe1c quy định tại Bản Điều khoản
                                    điều kiện v\xeà mở, sử dụng tài khoản thanh toán, phát hành v\xe0 sử dụng thẻ d\xe0nh
                                    cho
                                    Kh\xe1ch h\xe0ng đ\xe3 k\xfd với BVBank, được BVBank đăng tải tr\xean website ch\xednh thức
                                    <a style="color: blue" href="https://bvbank.net.vn">https://bvbank.net.vn</a> trong từng thời kỳ, quy định của ph\xe1p luật, NHNN, quy định của
                                    BVBank v\xe0 Đối t\xe1c li\xean quan đến việc sử dụng TKTT/Thẻ v\xe0 V\xed điện tử theo từng thời
                                    kỳ.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">b) </td>
                            <td class="toc-label">
                                <span>
                                    C\xe1c giao dịch được xem l\xe0 x\xe1c lập bởi Kh\xe1ch h\xe0ng v\xe0 Kh\xe1ch h\xe0ng chịu ho\xe0n ho\xe0n tr\xe1ch
                                    nhiệm v\xe0 kh\xf4ng được từ chối khi Kh\xe1ch h\xe0ng đ\xe3 x\xe1c thực theo h\xecnh thức x\xe1c thực theo
                                    quy
                                    định Điều khoản v\xe0 điều kiện n\xe0y.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">c) </td>
                            <td class="toc-label">
                                <span>
                                    Th\xf4ng b\xe1o kịp thời với BVBank khi ph\xe1t hiện sai s\xf3t, nhầm lẫn tr\xean TKTT/Thẻ hoặc
                                    TKTT/Thẻ bị lợi dụng để li\xean kết V\xed điện tử hoặc giao dịch sau khi li\xean kết th\xe0nh
                                    c\xf4ng.
                                    Kh\xe1ch h\xe0ng chịu ho\xe0n to\xe0n tr\xe1ch nhiệm trong mọi tổn thất li\xean quan đến việc Kh\xe1ch
                                    h\xe0ng
                                    ủy quyền hoặc cung cấp th\xf4ng tin của Kh\xe1ch h\xe0ng cho người kh\xe1c sử dụng TKTT/Thẻ/V\xed
                                    điện
                                    tử hoặc tiếp cận c\xe1c th\xf4ng tin li\xean quan đến số TKTT/Thẻ, m\xe3 bảo mật in tr\xean thẻ,
                                    c\xe1c
                                    mật khẩu… của Kh\xe1ch h\xe0ng tại BVBank hoặc Đối t\xe1c.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">d) </td>
                            <td class="toc-label">
                                <span>
                                    Thanh to\xe1n c\xe1c khoản ph\xed li\xean quan đến li\xean kết V\xed điện tử với TKTT/Thẻ theo quy
                                    định
                                    BVBank.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">e) </td>
                            <td class="toc-label">
                                <span>
                                    Chịu tr\xe1ch nhiệm v\xe0 miễn trừ cho BVBank khỏi c\xe1c tranh chấp, khiếu nại, khiếu kiện
                                    giữa
                                    Kh\xe1ch h\xe0ng, Đối t\xe1c v\xe0 c\xe1c b\xean thứ ba kh\xe1c li\xean quan đến việc mở, quản l\xfd v\xe0 sử dụng
                                    V\xed
                                    điện tử của Kh\xe1ch h\xe0ng.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">f) </td>
                            <td class="toc-label">
                                <span>
                                    C\xe1c nghĩa vụ kh\xe1c theo quy định tại Bản điều khoản điều kiện n\xe0y v\xe0 ph\xe1p luật Việt
                                    Nam.
                                </span>
                            </td>
                        </tr>
                    </table>
                </table>
            </div>

            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index-title">Điều 4.</td>
                        <td class="toc-label">Quyền v\xe0 nghĩa vụ của BVBank</td>
                    </tr>
                </table>
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">1. </td>
                        <td class="toc-label">
                            <span style="font-weight: 700;">
                                Quyền của BVBank
                            </span>
                        </td>
                    </tr>
                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">a) </td>
                            <td class="toc-label">
                                <span>
                                    Được quyền từ chối việc li\xean kết hoặc từ chối việc thực hiện c\xe1c giao dịch đối với
                                    TKTT/Thẻ li\xean kết với V\xed điện tử kh\xf4ng đ\xe1p ứng c\xe1c quy định tại Bản điều khoản điều
                                    kiện
                                    n\xe0y hoặc c\xe1c quy định kh\xe1c li\xean quan đến việc sử dụng T\xe0i khoản thanh to\xe1n, ph\xe1t
                                    h\xe0nh v\xe0
                                    sử dụng Thẻ ghi nợ giữa BVBank v\xe0 Kh\xe1ch h\xe0ng.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">b) </td>
                            <td class="toc-label">
                                <span>
                                    Được quyền phong toả khoản tiền được ghi c\xf3 v\xe0o TKTT th\xf4ng qua giao dịch r\xfat tiền
                                    khỏi
                                    V\xed điện tử khi c\xf3 y\xeau cầu bằng văn bản của cơ quan c\xf3 thẩm quyền hoặc c\xf3 cơ sở tin
                                    rằng
                                    khoản tiền n\xe0y li\xean quan đến hoạt động gian lận/giả mạo theo quy định ph\xe1p luật v\xe0
                                    quy
                                    định của BVBank.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">c) </td>
                            <td class="toc-label">
                                <span>
                                    Được miễn tr\xe1ch nhiệm trong trường hợp hệ thống xử l\xfd, truyền tin của BVBank hoặc
                                    Đối
                                    t\xe1c bị lỗi dẫn đến BVBank kh\xf4ng nhận được th\xf4ng tin để thực hiện c\xe1c y\xeau cầu nạp/r\xfat
                                    tiền/giao dịch kh\xe1c đối với V\xed điện tử th\xf4ng qua TKTT/Thẻ của Kh\xe1ch h\xe0ng.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">d) </td>
                            <td class="toc-label">
                                <span>
                                    Được miễn tr\xe1ch nhiệm trong c\xe1c tranh chấp, khiếu nại, khiếu kiện giữa Kh\xe1ch h\xe0ng,
                                    Đối
                                    t\xe1c v\xe0 c\xe1c b\xean thứ ba kh\xe1c li\xean quan đến việc mở, quản l\xfd v\xe0 sử dụng V\xed điện tử của
                                    Kh\xe1ch h\xe0ng.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">e) </td>
                            <td class="toc-label">
                                <span>
                                    Được quyền sử dụng c\xe1c th\xf4ng tin về Kh\xe1ch h\xe0ng v\xe0 giao dịch của Kh\xe1ch h\xe0ng bao gồm
                                    cả
                                    c\xe1c th\xf4ng tin từ văn bản, c\xe1c t\xe0i liệu do Kh\xe1ch h\xe0ng cung cấp; c\xe1c hợp đồng, văn bản
                                    k\xfd
                                    giữa Kh\xe1ch h\xe0ng v\xe0 BVBank để cung cấp cho c\xe1c cơ quan c\xf3 thẩm quyền y\xeau cầu cung cấp
                                    th\xf4ng tin theo quy định của ph\xe1p luật hoặc cung cấp cho c\xe1c đối t\xe1c li\xean quan trong
                                    việc
                                    hợp t\xe1c với BVBank để ph\xe1t triển sản phẩm, dịch vụ của BVBank.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">f) </td>
                            <td class="toc-label">
                                <span>
                                    Được quyền cung cấp c\xe1c th\xf4ng tin li\xean quan đến Kh\xe1ch h\xe0ng, giao dịch li\xean kết V\xed
                                    điện
                                    tử, thanh to\xe1n từ TKTT/Thẻ li\xean kết của Kh\xe1ch h\xe0ng cho cơ quan nh\xe0 nước c\xf3 thẩm
                                    quyền v\xe0
                                    cho b\xean thứ ba kh\xe1c theo quyết định của BVBank.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">g) </td>
                            <td class="toc-label">
                                <span>
                                    C\xe1c quyền kh\xe1c theo quy định tại Bản điều khoản điều kiện n\xe0y v\xe0 c\xe1c văn bản thỏa
                                    thuận
                                    kh\xe1c giữa c\xe1c b\xean v\xe0 quy định của ph\xe1p luật li\xean quan.
                                </span>
                            </td>
                        </tr>
                    </table>
                </table>
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">2. </td>
                        <td class="toc-label">
                            <span style="font-weight: 700;">
                                Nghĩa vụ của BVBank
                            </span>
                        </td>
                    </tr>
                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">a) </td>
                            <td class="toc-label">
                                <span>
                                    Thực hiện c\xe1c giao dịch ghi Nợ/ghi C\xf3 TKTT li\xean kết với V\xed điện tử (hoặc TKTT gắn
                                    với
                                    Thẻ được li\xean kết với V\xed điện tử) theo y\xeau cầu của Kh\xe1ch h\xe0ng theo Bản điều khoản
                                    điều
                                    kiện n\xe0y.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">b) </td>
                            <td class="toc-label">
                                <span>
                                    C\xe1c nghĩa vụ kh\xe1c theo Bản điều khoản điều kiện n\xe0y, quy định của ph\xe1p luật v\xe0 quy
                                    định
                                    kh\xe1c c\xf3 li\xean quan của BVBank.
                                </span>
                            </td>
                        </tr>
                    </table>
                </table>
            </div>

            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index-title">Điều 5.</td>
                        <td class="toc-label">Điều khoản thi h\xe0nh</td>
                    </tr>
                </table>
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index"></td>
                        <td class="toc-label">
                            <span>
                                Bản điều khoản điều kiện n\xe0y c\xf3 thể được sửa đổi v\xe0 bổ sung theo quyết định của BVBank
                                trong từng thời kỳ. Mọi sự thay đổi, bổ sung c\xf3 hiệu lực v\xe0o ng\xe0y được ghi trong th\xf4ng
                                b\xe1o hoặc ng\xe0y BVBank/Đối t\xe1c cập nhật l\xean ứng dụng V\xed điện tử hoặc webiste của Đối t\xe1c/
                                BVBank. Việc Kh\xe1ch h\xe0ng tiếp tục thực hiện c\xe1c giao dịch thanh to\xe1n, nạp, r\xfat tiền V\xed
                                điện tử từ/về TKTT/Thẻ, hoặc thanh to\xe1n trực tiếp từ TKTT/Thẻ th\xf4ng qua c\xe1c k\xeanh đối
                                t\xe1c triển khai sau thời điểm Bản điều khoản điều kiện n\xe0y được sửa đổi, bổ sung c\xf3 hiệu
                                lực được hiểu l\xe0 Kh\xe1ch h\xe0ng chấp thuận to\xe0n bộ những nội dung sửa đổi, bổ sung đ\xf3 v\xe0
                                kh\xf4ng cần phải c\xf3 th\xeam bất kỳ chấp thuận n\xe0o kh\xe1c của Kh\xe1ch h\xe0ng.
                            </span>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </section>
</body>

</html>
`,i=`
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
</head>
<style type="text/css">
    body {
        font-family: "Times New Roman";
        font-size: 11pt;
    }

    p {
        margin: 0;
    }

    .col-2 {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
    }

    .mb-4 {
        margin-bottom: 16px;
    }

    .contract {
        max-width: 860px;
        margin: auto;
        padding: 10px 0;
    }

    .header {
        margin-bottom: 24px;
    }

    .header strong {
        text-align: center;
        display: block;
    }

    .table {
        width: 90%;
        margin: auto;
        text-align: start;
        margin-top: 5px;
    }

    .table td {
        font-weight: 700;
        padding: 4pt;
    }

    .toc {
        width: 100%;
        border-collapse: collapse;
    }

    .toc td {
        padding-top: 3px;
        padding-bottom: 3px;
        padding-right: 3px;
    }

    .toc td:first-child {
        padding-left: 3px;
        padding-right: 0;
    }

    .toc tr {
        vertical-align: baseline;
        padding: 5px;
        text-align: justify;
    }

    .toc1 {
        width: 100%;
    }

    .toc1 td {
        padding-top: 3px;
        padding-bottom: 3px;
        padding-right: 3px;
    }

    .toc1 td:first-child {
        padding-left: 3px;
        padding-right: 0;
    }

    .toc1 tr {
        vertical-align: baseline;
        padding: 5px;
        text-align: justify;
    }

    .toc-header {
        font-weight: 600;
        text-align: justify;
    }

    .toc-content {
        margin-top: 5px;
        text-align: justify;
    }

    .toc-index-title {
        width: 65px;
        text-align: justify;
    }

    .toc-index {
        width: 30px;
        text-align: justify;
    }

    .toc-child {
        width: 25px;
        text-align: justify;
    }

    .italic-text {
        font-style: italic;
        height: 80px;
        margin-top: 40px;
    }

    .bold-text {
        font-weight: 700;
    }

    .info {
        margin-top: 5px;
        margin-bottom: 5px;
    }
</style>

<body>
    <section class="contract">
        <div class="header">
            <p style="text-align: center">
                <strong style="font-size: 13pt">TERMS AND CONDITIONS</strong>
                Applicable to Customers linking E-wallets with BVBank Accounts/Cards, and conducting transactions from Accounts/Cards via PAYME e-wallet
            </p>
        </div>

        <div style="padding: 0 5% 0 5%">
            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index-title">Article 1.</td>
                        <td class="toc-label">Definitions:</td>
                    </tr>
                </table>
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">1.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Customer: </span>
                            refers to an individual customer who is using the PAYME e-wallet application of the Partner and using a Payment Account or Debit Card at BVBank, and who is eligible and wishes to link and use an E-wallet with said Payment Account or Debit Card.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">2.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700">
                                Bank/BVBank:
                            </span>
                            refers to Ban Viet Joint Stock Commercial Bank.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">3.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> E-wallet Service Provider (Partner): </span>
                            refers to PayME Technology Joint Stock Company, a partner cooperating with BVBank to provide intermediary payment services to Customers via the PAYME e-wallet application, hereinafter referred to as the "Linked Partner" or "Partner."
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">4.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Partner Channel: </span>
                            refers to the Partner's Website/application/electronic transaction channels.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">5.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700">
                                E-wallet/PayME Wallet:
                            </span>
                            refers to an electronic value storage medium, also known as an E-wallet Account, provided by the Partner to Customers, allowing them to use services via the PAYME e-wallet application.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">6.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> E-wallet Application/PayME Application: </span>
                            refers to a mobile application legally owned, managed, and operated by the PayME to provide intermediary payment services licensed by the State Bank of Vietnam and other services deployed under the PAYME e-wallet brand.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">7.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Payment Account: </span>
                            refers to the Customer's VND payment account opened at BVBank.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">8.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Debit Card/Card: </span>
                            refers to the Customer's debit card opened at BVBank.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">9.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> E-wallet Linking/Linking: </span>
                            refers to the act of a Customer linking their PAYME e-wallet with their own Payment Account/Card at BVBank to perform top-up, withdrawal, transfer, payment, or other legal transactions via the linked Account/Card in accordance with the law.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">10.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Unlinking: </span>
                            refers to the act of a Customer canceling the link between their E-wallet and BVBank Payment Account/Card on the Partner's application or other channels provided by BVBank and the Partner.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">11.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> OTP (One-Time Password): </span>
                            refers to a form of electronic transaction authentication using a secret code that is valid for a single use and for a specific duration. OTP is sent to the Customer by BVBank via SMS, token, email, or other authentication methods/devices deployed by BVBank in accordance with the law and announced from time to time.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">12.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> PIN: </span>
                            refers to a form of authentication using a secret code consisting of a sequence of numbers. The Customer enters the PIN on the transaction authentication interface to confirm the transaction.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">13.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Biometrics: </span>
                            refer to unique and stable physical characteristics or biological traits of a person used for identification, such as facial images, fingerprints, irises, voice... Biometrics applied in these Terms and Conditions refer to the Customer's facial biometric data collected, verified, and authenticated by BVBank through technological measures in accordance with the regulations of the State Bank of Vietnam from time to time.
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">14.</td>
                        <td class="toc-label">
                            <span style="font-weight: 700"> Partner Transaction Authentication Method: </span>
                            refers to the transaction authentication method requested by the E-wallet service provider (Partner), applied on the Partner Channel to confirm the Customer's agreement to the contents of a contract or transaction, including PIN and other measures as prescribed by law.
                        </td>
                    </tr>
                </table>
            </div>

            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index-title">Article 2.</td>
                        <td class="toc-label">
                            E-wallet Linking with BVBank Payment Accounts/Cards and Transactions using Linked Accounts/Cards
                        </td>
                    </tr>
                </table>

                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">1.</td>
                        <td class="toc-label">
                            <span>
                                Conditions for Linking with BVBank Payment Accounts/Cards:
                            </span>
                        </td>
                    </tr>

                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px">
                        <tr class="toc-content">
                            <td class="toc-index">a)</td>
                            <td class="toc-label">
                                <span>
                                    The Customer’s Payment Account or Card used for linking with the E-wallet must be in an "active" status and not be restricted from electronic transactions.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">b)</td>
                            <td class="toc-label">
                                <span>
                                    The Customer must have completed the E-wallet identity verification (KYC) with full information and documentation as prescribed by the State Bank of Vietnam (SBV) from time to time.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">c)</td>
                            <td class="toc-label">
                                <span>
                                    Identity documents at BVBank must be valid, and BVBank must have completed the verification of the Customer's identity information, ensuring a match with the Biometric data stored in the National Population Database; or with Biometric data collected through face-to-face meetings for foreign individuals not using electronic identities, or persons of Vietnamese origin whose nationality is yet to be determined, through technological measures deployed by BVBank in accordance with SBV regulations from time to time.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">d)</td>
                            <td class="toc-label">
                                <span>
                                    The phone number and identity document information registered for the E-wallet must match the information registered at BVBank.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">e)</td>
                            <td class="toc-label">
                                <span>
                                    The Customer must have registered for BVBank's Digital Banking services.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">f)</td>
                            <td class="toc-label">
                                <span>
                                    The Customer has read and agreed to these Terms and Conditions.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">g)</td>
                            <td class="toc-label">
                                <span>
                                    The Customer meets other conditions as prescribed by the E-wallet Service Provider.
                                </span>
                            </td>
                        </tr>
                    </table>
                </table>

                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">2.</td>
                        <td class="toc-label">
                            <span>
                                By registering to link an E-wallet with a BVBank Payment Account/Card via the PAYME e-wallet application, the Customer affirms their understanding and explicitly agrees to:
                            </span>
                        </td>
                    </tr>

                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">a)</td>
                            <td class="toc-label">
                                <span>
                                    Authorize the PayME to receive, share, and transfer linking data, instructions, and Customer's authentications performed on the PAYME e-wallet application to BVBank's system to execute the E-wallet link and process payment, transfer, top-up, and withdrawal transactions to/from the Customer's Account or Card. All Customer consent within these Terms and Conditions is based on a voluntary basis and a clear understanding of the rights and obligations of the Parties under relevant laws (including BVBank’s right to perform all roles as a Controller and Processor of personal data as prescribed by data protection laws).
                                </span>
                            </td>
                        </tr>

                        <tr class="toc-content">
                            <td class="toc-index">b)</td>
                            <td class="toc-label">
                                <span>
                                    To link the E-wallet or perform transactions via the linked Account/Card, the Customer must authenticate the transaction using the Partner Transaction Authentication Methods and must authenticate via OTP or other methods provided by BVBank in accordance with the law (except for transactions where BVBank proactively debits according to Point c, Point d, Clause 2 of this Article).
                                </span>
                            </td>
                        </tr>

                        <tr class="toc-content">
                            <td class="toc-index">c)</td>
                            <td class="toc-label">
                                <span>
                                    Authorize BVBank to proactively debit the linked Payment Account (or Account associated with the linked Debit Card) to execute:
                                </span>
                            </td>
                        </tr>

                        <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 60px;">
                            <tr class="toc-content">
                                <td class="toc-index">i.</td>
                                <td class="toc-label">
                                    <span>
                                        Transactions via Partner Channels including: Top-ups, transfers, payments for goods and services, and other transactions as prescribed by law via the linked Account/Card.
                                    </span>
                                </td>
                            </tr>
                            <tr class="toc-content">
                                <td class="toc-index">ii.</td>
                                <td class="toc-label">
                                    <span>
                                        Transaction limits as specified by BVBank from time to time, in compliance with the law.
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </table>

                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">d)</td>
                            <td class="toc-label">
                                <span>
                                    For transactions where BVBank proactively debits the linked Payment Account (or Account associated with the linked Debit Card):
                                </span>
                            </td>
                        </tr>

                        <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 60px;">
                            <tr class="toc-content">
                                <td class="toc-index">i.</td>
                                <td class="toc-label">
                                    <span>
                                        The Customer shall perform authentication via the Partner Transaction Authentication Method; and
                                    </span>
                                </td>
                            </tr>
                            <tr class="toc-content">
                                <td class="toc-index">ii.</td>
                                <td class="toc-label">
                                    <span>
                                        The Customer agrees to register for BVBank to acknowledge these transactions through the connection between BVBank and the E-wallet Partner, using the linked Account/Card information.
                                    </span>
                                </td>
                            </tr>
                        </table>
                    </table>
                </table>

                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">3.</td>
                        <td class="toc-label">
                            <span>
                                Transaction authentication methods shall be applied to each specific type of transaction service based on risk assessments specified by BVBank from time to time and in compliance with the law.
                            </span>
                        </td>
                    </tr>
                    <tr class="toc-content">
                        <td class="toc-index">4.</td>
                        <td class="toc-label">
                            <span>
                                Customers may cancel the link between their Payment Account/Card and the E-wallet on the Partner Channels deployed from time to time.
                            </span>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index-title">Article 3.</td>
                        <td class="toc-label">Rights and Obligations of the Customer</td>
                    </tr>
                </table>

                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">1. </td>
                        <td class="toc-label">
                            <span style="font-weight: 700;">
                                Rights of the Customer
                            </span>
                        </td>
                    </tr>

                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">a) </td>
                            <td class="toc-label">
                                <span>
                                    To link or terminate the E-wallet link with Payment Accounts/Cards in accordance with BVBank's regulations.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">b) </td>
                            <td class="toc-label">
                                <span>
                                    To perform top-up, withdrawal, transfer, and payment transactions from the E-wallet to/from Payment Accounts or Cards, as well as other lawful transactions after successful linking.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">c) </td>
                            <td class="toc-label">
                                <span>
                                    Other rights as prescribed in these Terms and Conditions, other agreements between the parties, and relevant legal regulations.
                                </span>
                            </td>
                        </tr>
                    </table>
                </table>

                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">2. </td>
                        <td class="toc-label">
                            <span style="font-weight: 700;">
                                Obligations of the Customer
                            </span>
                        </td>
                    </tr>

                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">a) </td>
                            <td class="toc-label">
                                <span>
                                    To comply with the provisions of these Terms and Conditions and the Terms and Conditions for opening and using payment accounts, and the issuance and use of cards for individual customers signed with BVBank, as posted on the official website <a style="color: blue" href="https://bvbank.net.vn">https://bvbank.net.vn</a> from time to time; regulations of the law, the SBV, and regulations of BVBank and the Partner regarding the use of Payment Accounts/Cards and E-wallets from time to time.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">b) </td>
                            <td class="toc-label">
                                <span>
                                    Transactions shall be deemed established by the Customer, and the Customer shall assume full responsibility and may not reject them once the Customer has authenticated the transaction in accordance with the authentication methods specified in these Terms and Conditions.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">c) </td>
                            <td class="toc-label">
                                <span>
                                    To promptly notify BVBank upon discovering any errors or discrepancies in the Payment Account/Card, or if the Payment Account/Card is misused for E-wallet linking or transactions after successful linking. The Customer shall be fully responsible for any losses arising from the Customer's authorization or provision of information to others to use the Payment Account/Card/E-wallet, or for providing access to information related to the Payment Account/Card number, security codes printed on the card, passwords, etc., at BVBank or the Partner.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">d) </td>
                            <td class="toc-label">
                                <span>
                                    To pay all fees related to the E-wallet linking with Payment Accounts/Cards as prescribed by BVBank.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">e) </td>
                            <td class="toc-label">
                                <span>
                                    To take responsibility for and indemnify BVBank against any disputes, complaints, or litigation between the Customer, the Partner, and other third parties related to the opening, management, and use of the Customer's E-wallet.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">f) </td>
                            <td class="toc-label">
                                <span>
                                    Other obligations as prescribed in these Terms and Conditions and the laws of Vietnam.
                                </span>
                            </td>
                        </tr>
                    </table>
                </table>
            </div>

            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index-title">Article 4.</td>
                        <td class="toc-label">Rights and Obligations of BVBank</td>
                    </tr>
                </table>

                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">1. </td>
                        <td class="toc-label">
                            <span style="font-weight: 700;">
                                Rights of BVBank
                            </span>
                        </td>
                    </tr>

                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">a) </td>
                            <td class="toc-label">
                                <span>
                                    To reserve the right to refuse linking or refuse to execute transactions for Payment Accounts/Cards linked to E-wallets that do not comply with the provisions of these Terms and Conditions or other relevant regulations on the use of payment accounts and the issuance and use of debit cards between BVBank and the Customer.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">b) </td>
                            <td class="toc-label">
                                <span>
                                    To reserve the right to freeze funds credited to the Payment Account via E-wallet withdrawal transactions upon written request from a competent state authority or if there are reasonable grounds to believe that such funds are related to fraudulent/counterfeit activities as prescribed by law and BVBank's regulations.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">c) </td>
                            <td class="toc-label">
                                <span>
                                    To be exempt from liability in the event of errors in the processing or communication systems of BVBank or the Partner, resulting in BVBank not receiving information to execute top-up/withdrawal/transaction requests for the E-wallet via the Customer's Payment Account/Card.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">d) </td>
                            <td class="toc-label">
                                <span>
                                    To be exempt from liability in disputes, complaints, or litigation between the Customer, the Partner, and other third parties related to the opening, management, and use of the Customer's E-wallet.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">e) </td>
                            <td class="toc-label">
                                <span>
                                    To reserve the right to use Customer and transaction information, including information from documents and materials provided by the Customer, contracts, and agreements signed between the Customer and BVBank, to provide to competent authorities requesting information as prescribed by law, or to provide to relevant partners collaborating with BVBank to develop BVBank's products and services.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">f) </td>
                            <td class="toc-label">
                                <span>
                                    To reserve the right to provide information related to the Customer, E-wallet linking transactions, and payments from the Customer's linked Payment Account/Card to competent state authorities and other third parties as determined by BVBank.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">g) </td>
                            <td class="toc-label">
                                <span>
                                    Other rights as prescribed in these Terms and Conditions, other agreements between the parties, and relevant legal regulations.
                                </span>
                            </td>
                        </tr>
                    </table>
                </table>

                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index">2. </td>
                        <td class="toc-label">
                            <span style="font-weight: 700;">
                                Obligations of BVBank
                            </span>
                        </td>
                    </tr>

                    <table cellspacing="0" cellpadding="0" class="toc1" style="padding-left: 30px;">
                        <tr class="toc-content">
                            <td class="toc-index">a) </td>
                            <td class="toc-label">
                                <span>
                                    To execute debit/credit transactions on the linked Payment Account (or Account associated with the linked Card) upon the Customer's request in accordance with these Terms and Conditions.
                                </span>
                            </td>
                        </tr>
                        <tr class="toc-content">
                            <td class="toc-index">b) </td>
                            <td class="toc-label">
                                <span>
                                    Other obligations as prescribed in these Terms and Conditions, relevant legal regulations, and other relevant regulations of BVBank.
                                </span>
                            </td>
                        </tr>
                    </table>
                </table>
            </div>

            <div class="mb-4">
                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-header">
                        <td class="toc-index-title">Article 5.</td>
                        <td class="toc-label">Implementation Provisions</td>
                    </tr>
                </table>

                <table cellspacing="0" cellpadding="0" class="toc">
                    <tr class="toc-content">
                        <td class="toc-index"></td>
                        <td class="toc-label">
                            <span>
                                These Terms and Conditions may be amended and supplemented at BVBank's discretion from time to time. Any amendments or supplements shall take effect on the date specified in the notice or the date BVBank/the Partner updates them on the E-wallet application or the Partner/BVBank's website. The Customer's continued execution of payment, top-up, or withdrawal transactions to/from the E-wallet via the Payment Account/Card, or direct payments from the Payment Account/Card via the deployed Partner Channels after the effective date of such amended and supplemented Terms and Conditions, shall be understood as the Customer's acceptance of all such amendments and supplements, and no further consent from the Customer shall be required.
                            </span>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </section>
</body>

</html>
`}}]);