"use strict";
(() => {
  // node_modules/workbox-core/_version.js
  try {
    self["workbox:core:7.4.0"] && _();
  } catch (e) {
  }

  // node_modules/workbox-core/_private/logger.js
  var logger = true ? null : (() => {
    if (!("__WB_DISABLE_DEV_LOGS" in globalThis)) {
      self.__WB_DISABLE_DEV_LOGS = false;
    }
    let inGroup = false;
    const methodToColorMap = {
      debug: `#7f8c8d`,
      log: `#2ecc71`,
      warn: `#f39c12`,
      error: `#c0392b`,
      groupCollapsed: `#3498db`,
      groupEnd: null
      // No colored prefix on groupEnd
    };
    const print = function(method, args) {
      if (self.__WB_DISABLE_DEV_LOGS) {
        return;
      }
      if (method === "groupCollapsed") {
        if (/^((?!chrome|android).)*safari/i.test(navigator.userAgent)) {
          console[method](...args);
          return;
        }
      }
      const styles = [
        `background: ${methodToColorMap[method]}`,
        `border-radius: 0.5em`,
        `color: white`,
        `font-weight: bold`,
        `padding: 2px 0.5em`
      ];
      const logPrefix = inGroup ? [] : ["%cworkbox", styles.join(";")];
      console[method](...logPrefix, ...args);
      if (method === "groupCollapsed") {
        inGroup = true;
      }
      if (method === "groupEnd") {
        inGroup = false;
      }
    };
    const api = {};
    const loggerMethods = Object.keys(methodToColorMap);
    for (const key of loggerMethods) {
      const method = key;
      api[method] = (...args) => {
        print(method, args);
      };
    }
    return api;
  })();

  // node_modules/workbox-core/models/messages/messageGenerator.js
  var fallback = (code, ...args) => {
    let msg = code;
    if (args.length > 0) {
      msg += ` :: ${JSON.stringify(args)}`;
    }
    return msg;
  };
  var messageGenerator = true ? fallback : generatorFunction;

  // node_modules/workbox-core/_private/WorkboxError.js
  var WorkboxError = class extends Error {
    /**
     *
     * @param {string} errorCode The error code that
     * identifies this particular error.
     * @param {Object=} details Any relevant arguments
     * that will help developers identify issues should
     * be added as a key on the context object.
     */
    constructor(errorCode, details) {
      const message = messageGenerator(errorCode, details);
      super(message);
      this.name = errorCode;
      this.details = details;
    }
  };

  // node_modules/workbox-core/models/quotaErrorCallbacks.js
  var quotaErrorCallbacks = /* @__PURE__ */ new Set();

  // node_modules/workbox-core/registerQuotaErrorCallback.js
  function registerQuotaErrorCallback(callback) {
    if (false) {
      finalAssertExports.isType(callback, "function", {
        moduleName: "workbox-core",
        funcName: "register",
        paramName: "callback"
      });
    }
    quotaErrorCallbacks.add(callback);
    if (false) {
      logger.log("Registered a callback to respond to quota errors.", callback);
    }
  }

  // node_modules/workbox-core/_private/cacheNames.js
  var _cacheNameDetails = {
    googleAnalytics: "googleAnalytics",
    precache: "precache-v2",
    prefix: "workbox",
    runtime: "runtime",
    suffix: typeof registration !== "undefined" ? registration.scope : ""
  };
  var _createCacheName = (cacheName) => {
    return [_cacheNameDetails.prefix, cacheName, _cacheNameDetails.suffix].filter((value) => value && value.length > 0).join("-");
  };
  var eachCacheNameDetail = (fn) => {
    for (const key of Object.keys(_cacheNameDetails)) {
      fn(key);
    }
  };
  var cacheNames = {
    updateDetails: (details) => {
      eachCacheNameDetail((key) => {
        if (typeof details[key] === "string") {
          _cacheNameDetails[key] = details[key];
        }
      });
    },
    getGoogleAnalyticsName: (userCacheName) => {
      return userCacheName || _createCacheName(_cacheNameDetails.googleAnalytics);
    },
    getPrecacheName: (userCacheName) => {
      return userCacheName || _createCacheName(_cacheNameDetails.precache);
    },
    getPrefix: () => {
      return _cacheNameDetails.prefix;
    },
    getRuntimeName: (userCacheName) => {
      return userCacheName || _createCacheName(_cacheNameDetails.runtime);
    },
    getSuffix: () => {
      return _cacheNameDetails.suffix;
    }
  };

  // node_modules/workbox-core/_private/cacheMatchIgnoreParams.js
  function stripParams(fullURL, ignoreParams) {
    const strippedURL = new URL(fullURL);
    for (const param of ignoreParams) {
      strippedURL.searchParams.delete(param);
    }
    return strippedURL.href;
  }
  async function cacheMatchIgnoreParams(cache, request, ignoreParams, matchOptions) {
    const strippedRequestURL = stripParams(request.url, ignoreParams);
    if (request.url === strippedRequestURL) {
      return cache.match(request, matchOptions);
    }
    const keysOptions = Object.assign(Object.assign({}, matchOptions), { ignoreSearch: true });
    const cacheKeys = await cache.keys(request, keysOptions);
    for (const cacheKey of cacheKeys) {
      const strippedCacheKeyURL = stripParams(cacheKey.url, ignoreParams);
      if (strippedRequestURL === strippedCacheKeyURL) {
        return cache.match(cacheKey, matchOptions);
      }
    }
    return;
  }

  // node_modules/workbox-core/_private/canConstructResponseFromBodyStream.js
  var supportStatus;
  function canConstructResponseFromBodyStream() {
    if (supportStatus === void 0) {
      const testResponse = new Response("");
      if ("body" in testResponse) {
        try {
          new Response(testResponse.body);
          supportStatus = true;
        } catch (error) {
          supportStatus = false;
        }
      }
      supportStatus = false;
    }
    return supportStatus;
  }

  // node_modules/workbox-core/_private/dontWaitFor.js
  function dontWaitFor(promise) {
    void promise.then(() => {
    });
  }

  // node_modules/workbox-core/_private/Deferred.js
  var Deferred = class {
    /**
     * Creates a promise and exposes its resolve and reject functions as methods.
     */
    constructor() {
      this.promise = new Promise((resolve, reject) => {
        this.resolve = resolve;
        this.reject = reject;
      });
    }
  };

  // node_modules/workbox-core/_private/executeQuotaErrorCallbacks.js
  async function executeQuotaErrorCallbacks() {
    if (false) {
      logger.log(`About to run ${quotaErrorCallbacks.size} callbacks to clean up caches.`);
    }
    for (const callback of quotaErrorCallbacks) {
      await callback();
      if (false) {
        logger.log(callback, "is complete.");
      }
    }
    if (false) {
      logger.log("Finished running callbacks.");
    }
  }

  // node_modules/workbox-core/_private/getFriendlyURL.js
  var getFriendlyURL = (url) => {
    const urlObj = new URL(String(url), location.href);
    return urlObj.href.replace(new RegExp(`^${location.origin}`), "");
  };

  // node_modules/workbox-core/_private/timeout.js
  function timeout(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // node_modules/workbox-core/_private/waitUntil.js
  function waitUntil(event, asyncFn) {
    const returnPromise = asyncFn();
    event.waitUntil(returnPromise);
    return returnPromise;
  }

  // node_modules/workbox-core/copyResponse.js
  async function copyResponse(response, modifier) {
    let origin = null;
    if (response.url) {
      const responseURL = new URL(response.url);
      origin = responseURL.origin;
    }
    if (origin !== self.location.origin) {
      throw new WorkboxError("cross-origin-copy-response", { origin });
    }
    const clonedResponse = response.clone();
    const responseInit = {
      headers: new Headers(clonedResponse.headers),
      status: clonedResponse.status,
      statusText: clonedResponse.statusText
    };
    const modifiedResponseInit = modifier ? modifier(responseInit) : responseInit;
    const body = canConstructResponseFromBodyStream() ? clonedResponse.body : await clonedResponse.blob();
    return new Response(body, modifiedResponseInit);
  }

  // node_modules/workbox-core/clientsClaim.js
  function clientsClaim() {
    self.addEventListener("activate", () => self.clients.claim());
  }

  // node_modules/idb/build/wrap-idb-value.js
  var instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);
  var idbProxyableTypes;
  var cursorAdvanceMethods;
  function getIdbProxyableTypes() {
    return idbProxyableTypes || (idbProxyableTypes = [
      IDBDatabase,
      IDBObjectStore,
      IDBIndex,
      IDBCursor,
      IDBTransaction
    ]);
  }
  function getCursorAdvanceMethods() {
    return cursorAdvanceMethods || (cursorAdvanceMethods = [
      IDBCursor.prototype.advance,
      IDBCursor.prototype.continue,
      IDBCursor.prototype.continuePrimaryKey
    ]);
  }
  var cursorRequestMap = /* @__PURE__ */ new WeakMap();
  var transactionDoneMap = /* @__PURE__ */ new WeakMap();
  var transactionStoreNamesMap = /* @__PURE__ */ new WeakMap();
  var transformCache = /* @__PURE__ */ new WeakMap();
  var reverseTransformCache = /* @__PURE__ */ new WeakMap();
  function promisifyRequest(request) {
    const promise = new Promise((resolve, reject) => {
      const unlisten = () => {
        request.removeEventListener("success", success);
        request.removeEventListener("error", error);
      };
      const success = () => {
        resolve(wrap(request.result));
        unlisten();
      };
      const error = () => {
        reject(request.error);
        unlisten();
      };
      request.addEventListener("success", success);
      request.addEventListener("error", error);
    });
    promise.then((value) => {
      if (value instanceof IDBCursor) {
        cursorRequestMap.set(value, request);
      }
    }).catch(() => {
    });
    reverseTransformCache.set(promise, request);
    return promise;
  }
  function cacheDonePromiseForTransaction(tx) {
    if (transactionDoneMap.has(tx))
      return;
    const done = new Promise((resolve, reject) => {
      const unlisten = () => {
        tx.removeEventListener("complete", complete);
        tx.removeEventListener("error", error);
        tx.removeEventListener("abort", error);
      };
      const complete = () => {
        resolve();
        unlisten();
      };
      const error = () => {
        reject(tx.error || new DOMException("AbortError", "AbortError"));
        unlisten();
      };
      tx.addEventListener("complete", complete);
      tx.addEventListener("error", error);
      tx.addEventListener("abort", error);
    });
    transactionDoneMap.set(tx, done);
  }
  var idbProxyTraps = {
    get(target, prop, receiver) {
      if (target instanceof IDBTransaction) {
        if (prop === "done")
          return transactionDoneMap.get(target);
        if (prop === "objectStoreNames") {
          return target.objectStoreNames || transactionStoreNamesMap.get(target);
        }
        if (prop === "store") {
          return receiver.objectStoreNames[1] ? void 0 : receiver.objectStore(receiver.objectStoreNames[0]);
        }
      }
      return wrap(target[prop]);
    },
    set(target, prop, value) {
      target[prop] = value;
      return true;
    },
    has(target, prop) {
      if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) {
        return true;
      }
      return prop in target;
    }
  };
  function replaceTraps(callback) {
    idbProxyTraps = callback(idbProxyTraps);
  }
  function wrapFunction(func) {
    if (func === IDBDatabase.prototype.transaction && !("objectStoreNames" in IDBTransaction.prototype)) {
      return function(storeNames, ...args) {
        const tx = func.call(unwrap(this), storeNames, ...args);
        transactionStoreNamesMap.set(tx, storeNames.sort ? storeNames.sort() : [storeNames]);
        return wrap(tx);
      };
    }
    if (getCursorAdvanceMethods().includes(func)) {
      return function(...args) {
        func.apply(unwrap(this), args);
        return wrap(cursorRequestMap.get(this));
      };
    }
    return function(...args) {
      return wrap(func.apply(unwrap(this), args));
    };
  }
  function transformCachableValue(value) {
    if (typeof value === "function")
      return wrapFunction(value);
    if (value instanceof IDBTransaction)
      cacheDonePromiseForTransaction(value);
    if (instanceOfAny(value, getIdbProxyableTypes()))
      return new Proxy(value, idbProxyTraps);
    return value;
  }
  function wrap(value) {
    if (value instanceof IDBRequest)
      return promisifyRequest(value);
    if (transformCache.has(value))
      return transformCache.get(value);
    const newValue = transformCachableValue(value);
    if (newValue !== value) {
      transformCache.set(value, newValue);
      reverseTransformCache.set(newValue, value);
    }
    return newValue;
  }
  var unwrap = (value) => reverseTransformCache.get(value);

  // node_modules/idb/build/index.js
  function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
    const request = indexedDB.open(name, version);
    const openPromise = wrap(request);
    if (upgrade) {
      request.addEventListener("upgradeneeded", (event) => {
        upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
      });
    }
    if (blocked) {
      request.addEventListener("blocked", (event) => blocked(
        // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion,
        event.newVersion,
        event
      ));
    }
    openPromise.then((db) => {
      if (terminated)
        db.addEventListener("close", () => terminated());
      if (blocking) {
        db.addEventListener("versionchange", (event) => blocking(event.oldVersion, event.newVersion, event));
      }
    }).catch(() => {
    });
    return openPromise;
  }
  function deleteDB(name, { blocked } = {}) {
    const request = indexedDB.deleteDatabase(name);
    if (blocked) {
      request.addEventListener("blocked", (event) => blocked(
        // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion,
        event
      ));
    }
    return wrap(request).then(() => void 0);
  }
  var readMethods = ["get", "getKey", "getAll", "getAllKeys", "count"];
  var writeMethods = ["put", "add", "delete", "clear"];
  var cachedMethods = /* @__PURE__ */ new Map();
  function getMethod(target, prop) {
    if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) {
      return;
    }
    if (cachedMethods.get(prop))
      return cachedMethods.get(prop);
    const targetFuncName = prop.replace(/FromIndex$/, "");
    const useIndex = prop !== targetFuncName;
    const isWrite = writeMethods.includes(targetFuncName);
    if (
      // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
      !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))
    ) {
      return;
    }
    const method = async function(storeName, ...args) {
      const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
      let target2 = tx.store;
      if (useIndex)
        target2 = target2.index(args.shift());
      return (await Promise.all([
        target2[targetFuncName](...args),
        isWrite && tx.done
      ]))[0];
    };
    cachedMethods.set(prop, method);
    return method;
  }
  replaceTraps((oldTraps) => ({
    ...oldTraps,
    get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
    has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop)
  }));

  // node_modules/workbox-expiration/_version.js
  try {
    self["workbox:expiration:7.4.0"] && _();
  } catch (e) {
  }

  // node_modules/workbox-expiration/models/CacheTimestampsModel.js
  var DB_NAME = "workbox-expiration";
  var CACHE_OBJECT_STORE = "cache-entries";
  var normalizeURL = (unNormalizedUrl) => {
    const url = new URL(unNormalizedUrl, location.href);
    url.hash = "";
    return url.href;
  };
  var CacheTimestampsModel = class {
    /**
     *
     * @param {string} cacheName
     *
     * @private
     */
    constructor(cacheName) {
      this._db = null;
      this._cacheName = cacheName;
    }
    /**
     * Performs an upgrade of indexedDB.
     *
     * @param {IDBPDatabase<CacheDbSchema>} db
     *
     * @private
     */
    _upgradeDb(db) {
      const objStore = db.createObjectStore(CACHE_OBJECT_STORE, { keyPath: "id" });
      objStore.createIndex("cacheName", "cacheName", { unique: false });
      objStore.createIndex("timestamp", "timestamp", { unique: false });
    }
    /**
     * Performs an upgrade of indexedDB and deletes deprecated DBs.
     *
     * @param {IDBPDatabase<CacheDbSchema>} db
     *
     * @private
     */
    _upgradeDbAndDeleteOldDbs(db) {
      this._upgradeDb(db);
      if (this._cacheName) {
        void deleteDB(this._cacheName);
      }
    }
    /**
     * @param {string} url
     * @param {number} timestamp
     *
     * @private
     */
    async setTimestamp(url, timestamp) {
      url = normalizeURL(url);
      const entry = {
        url,
        timestamp,
        cacheName: this._cacheName,
        // Creating an ID from the URL and cache name won't be necessary once
        // Edge switches to Chromium and all browsers we support work with
        // array keyPaths.
        id: this._getId(url)
      };
      const db = await this.getDb();
      const tx = db.transaction(CACHE_OBJECT_STORE, "readwrite", {
        durability: "relaxed"
      });
      await tx.store.put(entry);
      await tx.done;
    }
    /**
     * Returns the timestamp stored for a given URL.
     *
     * @param {string} url
     * @return {number | undefined}
     *
     * @private
     */
    async getTimestamp(url) {
      const db = await this.getDb();
      const entry = await db.get(CACHE_OBJECT_STORE, this._getId(url));
      return entry === null || entry === void 0 ? void 0 : entry.timestamp;
    }
    /**
     * Iterates through all the entries in the object store (from newest to
     * oldest) and removes entries once either `maxCount` is reached or the
     * entry's timestamp is less than `minTimestamp`.
     *
     * @param {number} minTimestamp
     * @param {number} maxCount
     * @return {Array<string>}
     *
     * @private
     */
    async expireEntries(minTimestamp, maxCount) {
      const db = await this.getDb();
      let cursor = await db.transaction(CACHE_OBJECT_STORE).store.index("timestamp").openCursor(null, "prev");
      const entriesToDelete = [];
      let entriesNotDeletedCount = 0;
      while (cursor) {
        const result = cursor.value;
        if (result.cacheName === this._cacheName) {
          if (minTimestamp && result.timestamp < minTimestamp || maxCount && entriesNotDeletedCount >= maxCount) {
            entriesToDelete.push(cursor.value);
          } else {
            entriesNotDeletedCount++;
          }
        }
        cursor = await cursor.continue();
      }
      const urlsDeleted = [];
      for (const entry of entriesToDelete) {
        await db.delete(CACHE_OBJECT_STORE, entry.id);
        urlsDeleted.push(entry.url);
      }
      return urlsDeleted;
    }
    /**
     * Takes a URL and returns an ID that will be unique in the object store.
     *
     * @param {string} url
     * @return {string}
     *
     * @private
     */
    _getId(url) {
      return this._cacheName + "|" + normalizeURL(url);
    }
    /**
     * Returns an open connection to the database.
     *
     * @private
     */
    async getDb() {
      if (!this._db) {
        this._db = await openDB(DB_NAME, 1, {
          upgrade: this._upgradeDbAndDeleteOldDbs.bind(this)
        });
      }
      return this._db;
    }
  };

  // node_modules/workbox-expiration/CacheExpiration.js
  var CacheExpiration = class {
    /**
     * To construct a new CacheExpiration instance you must provide at least
     * one of the `config` properties.
     *
     * @param {string} cacheName Name of the cache to apply restrictions to.
     * @param {Object} config
     * @param {number} [config.maxEntries] The maximum number of entries to cache.
     * Entries used the least will be removed as the maximum is reached.
     * @param {number} [config.maxAgeSeconds] The maximum age of an entry before
     * it's treated as stale and removed.
     * @param {Object} [config.matchOptions] The [`CacheQueryOptions`](https://developer.mozilla.org/en-US/docs/Web/API/Cache/delete#Parameters)
     * that will be used when calling `delete()` on the cache.
     */
    constructor(cacheName, config = {}) {
      this._isRunning = false;
      this._rerunRequested = false;
      if (false) {
        finalAssertExports.isType(cacheName, "string", {
          moduleName: "workbox-expiration",
          className: "CacheExpiration",
          funcName: "constructor",
          paramName: "cacheName"
        });
        if (!(config.maxEntries || config.maxAgeSeconds)) {
          throw new WorkboxError("max-entries-or-age-required", {
            moduleName: "workbox-expiration",
            className: "CacheExpiration",
            funcName: "constructor"
          });
        }
        if (config.maxEntries) {
          finalAssertExports.isType(config.maxEntries, "number", {
            moduleName: "workbox-expiration",
            className: "CacheExpiration",
            funcName: "constructor",
            paramName: "config.maxEntries"
          });
        }
        if (config.maxAgeSeconds) {
          finalAssertExports.isType(config.maxAgeSeconds, "number", {
            moduleName: "workbox-expiration",
            className: "CacheExpiration",
            funcName: "constructor",
            paramName: "config.maxAgeSeconds"
          });
        }
      }
      this._maxEntries = config.maxEntries;
      this._maxAgeSeconds = config.maxAgeSeconds;
      this._matchOptions = config.matchOptions;
      this._cacheName = cacheName;
      this._timestampModel = new CacheTimestampsModel(cacheName);
    }
    /**
     * Expires entries for the given cache and given criteria.
     */
    async expireEntries() {
      if (this._isRunning) {
        this._rerunRequested = true;
        return;
      }
      this._isRunning = true;
      const minTimestamp = this._maxAgeSeconds ? Date.now() - this._maxAgeSeconds * 1e3 : 0;
      const urlsExpired = await this._timestampModel.expireEntries(minTimestamp, this._maxEntries);
      const cache = await self.caches.open(this._cacheName);
      for (const url of urlsExpired) {
        await cache.delete(url, this._matchOptions);
      }
      if (false) {
        if (urlsExpired.length > 0) {
          logger.groupCollapsed(`Expired ${urlsExpired.length} ${urlsExpired.length === 1 ? "entry" : "entries"} and removed ${urlsExpired.length === 1 ? "it" : "them"} from the '${this._cacheName}' cache.`);
          logger.log(`Expired the following ${urlsExpired.length === 1 ? "URL" : "URLs"}:`);
          urlsExpired.forEach((url) => logger.log(`    ${url}`));
          logger.groupEnd();
        } else {
          logger.debug(`Cache expiration ran and found no entries to remove.`);
        }
      }
      this._isRunning = false;
      if (this._rerunRequested) {
        this._rerunRequested = false;
        dontWaitFor(this.expireEntries());
      }
    }
    /**
     * Update the timestamp for the given URL. This ensures the when
     * removing entries based on maximum entries, most recently used
     * is accurate or when expiring, the timestamp is up-to-date.
     *
     * @param {string} url
     */
    async updateTimestamp(url) {
      if (false) {
        finalAssertExports.isType(url, "string", {
          moduleName: "workbox-expiration",
          className: "CacheExpiration",
          funcName: "updateTimestamp",
          paramName: "url"
        });
      }
      await this._timestampModel.setTimestamp(url, Date.now());
    }
    /**
     * Can be used to check if a URL has expired or not before it's used.
     *
     * This requires a look up from IndexedDB, so can be slow.
     *
     * Note: This method will not remove the cached entry, call
     * `expireEntries()` to remove indexedDB and Cache entries.
     *
     * @param {string} url
     * @return {boolean}
     */
    async isURLExpired(url) {
      if (!this._maxAgeSeconds) {
        if (false) {
          throw new WorkboxError(`expired-test-without-max-age`, {
            methodName: "isURLExpired",
            paramName: "maxAgeSeconds"
          });
        }
        return false;
      } else {
        const timestamp = await this._timestampModel.getTimestamp(url);
        const expireOlderThan = Date.now() - this._maxAgeSeconds * 1e3;
        return timestamp !== void 0 ? timestamp < expireOlderThan : true;
      }
    }
    /**
     * Removes the IndexedDB object store used to keep track of cache expiration
     * metadata.
     */
    async delete() {
      this._rerunRequested = false;
      await this._timestampModel.expireEntries(Infinity);
    }
  };

  // node_modules/workbox-expiration/ExpirationPlugin.js
  var ExpirationPlugin = class {
    /**
     * @param {ExpirationPluginOptions} config
     * @param {number} [config.maxEntries] The maximum number of entries to cache.
     * Entries used the least will be removed as the maximum is reached.
     * @param {number} [config.maxAgeSeconds] The maximum age of an entry before
     * it's treated as stale and removed.
     * @param {Object} [config.matchOptions] The [`CacheQueryOptions`](https://developer.mozilla.org/en-US/docs/Web/API/Cache/delete#Parameters)
     * that will be used when calling `delete()` on the cache.
     * @param {boolean} [config.purgeOnQuotaError] Whether to opt this cache in to
     * automatic deletion if the available storage quota has been exceeded.
     */
    constructor(config = {}) {
      this.cachedResponseWillBeUsed = async ({ event, request, cacheName, cachedResponse }) => {
        if (!cachedResponse) {
          return null;
        }
        const isFresh = this._isResponseDateFresh(cachedResponse);
        const cacheExpiration = this._getCacheExpiration(cacheName);
        dontWaitFor(cacheExpiration.expireEntries());
        const updateTimestampDone = cacheExpiration.updateTimestamp(request.url);
        if (event) {
          try {
            event.waitUntil(updateTimestampDone);
          } catch (error) {
            if (false) {
              if ("request" in event) {
                logger.warn(`Unable to ensure service worker stays alive when updating cache entry for '${getFriendlyURL(event.request.url)}'.`);
              }
            }
          }
        }
        return isFresh ? cachedResponse : null;
      };
      this.cacheDidUpdate = async ({ cacheName, request }) => {
        if (false) {
          finalAssertExports.isType(cacheName, "string", {
            moduleName: "workbox-expiration",
            className: "Plugin",
            funcName: "cacheDidUpdate",
            paramName: "cacheName"
          });
          finalAssertExports.isInstance(request, Request, {
            moduleName: "workbox-expiration",
            className: "Plugin",
            funcName: "cacheDidUpdate",
            paramName: "request"
          });
        }
        const cacheExpiration = this._getCacheExpiration(cacheName);
        await cacheExpiration.updateTimestamp(request.url);
        await cacheExpiration.expireEntries();
      };
      if (false) {
        if (!(config.maxEntries || config.maxAgeSeconds)) {
          throw new WorkboxError("max-entries-or-age-required", {
            moduleName: "workbox-expiration",
            className: "Plugin",
            funcName: "constructor"
          });
        }
        if (config.maxEntries) {
          finalAssertExports.isType(config.maxEntries, "number", {
            moduleName: "workbox-expiration",
            className: "Plugin",
            funcName: "constructor",
            paramName: "config.maxEntries"
          });
        }
        if (config.maxAgeSeconds) {
          finalAssertExports.isType(config.maxAgeSeconds, "number", {
            moduleName: "workbox-expiration",
            className: "Plugin",
            funcName: "constructor",
            paramName: "config.maxAgeSeconds"
          });
        }
      }
      this._config = config;
      this._maxAgeSeconds = config.maxAgeSeconds;
      this._cacheExpirations = /* @__PURE__ */ new Map();
      if (config.purgeOnQuotaError) {
        registerQuotaErrorCallback(() => this.deleteCacheAndMetadata());
      }
    }
    /**
     * A simple helper method to return a CacheExpiration instance for a given
     * cache name.
     *
     * @param {string} cacheName
     * @return {CacheExpiration}
     *
     * @private
     */
    _getCacheExpiration(cacheName) {
      if (cacheName === cacheNames.getRuntimeName()) {
        throw new WorkboxError("expire-custom-caches-only");
      }
      let cacheExpiration = this._cacheExpirations.get(cacheName);
      if (!cacheExpiration) {
        cacheExpiration = new CacheExpiration(cacheName, this._config);
        this._cacheExpirations.set(cacheName, cacheExpiration);
      }
      return cacheExpiration;
    }
    /**
     * @param {Response} cachedResponse
     * @return {boolean}
     *
     * @private
     */
    _isResponseDateFresh(cachedResponse) {
      if (!this._maxAgeSeconds) {
        return true;
      }
      const dateHeaderTimestamp = this._getDateHeaderTimestamp(cachedResponse);
      if (dateHeaderTimestamp === null) {
        return true;
      }
      const now = Date.now();
      return dateHeaderTimestamp >= now - this._maxAgeSeconds * 1e3;
    }
    /**
     * This method will extract the data header and parse it into a useful
     * value.
     *
     * @param {Response} cachedResponse
     * @return {number|null}
     *
     * @private
     */
    _getDateHeaderTimestamp(cachedResponse) {
      if (!cachedResponse.headers.has("date")) {
        return null;
      }
      const dateHeader = cachedResponse.headers.get("date");
      const parsedDate = new Date(dateHeader);
      const headerTime = parsedDate.getTime();
      if (isNaN(headerTime)) {
        return null;
      }
      return headerTime;
    }
    /**
     * This is a helper method that performs two operations:
     *
     * - Deletes *all* the underlying Cache instances associated with this plugin
     * instance, by calling caches.delete() on your behalf.
     * - Deletes the metadata from IndexedDB used to keep track of expiration
     * details for each Cache instance.
     *
     * When using cache expiration, calling this method is preferable to calling
     * `caches.delete()` directly, since this will ensure that the IndexedDB
     * metadata is also cleanly removed and open IndexedDB instances are deleted.
     *
     * Note that if you're *not* using cache expiration for a given cache, calling
     * `caches.delete()` and passing in the cache's name should be sufficient.
     * There is no Workbox-specific method needed for cleanup in that case.
     */
    async deleteCacheAndMetadata() {
      for (const [cacheName, cacheExpiration] of this._cacheExpirations) {
        await self.caches.delete(cacheName);
        await cacheExpiration.delete();
      }
      this._cacheExpirations = /* @__PURE__ */ new Map();
    }
  };

  // node_modules/workbox-precaching/_version.js
  try {
    self["workbox:precaching:7.4.0"] && _();
  } catch (e) {
  }

  // node_modules/workbox-precaching/utils/createCacheKey.js
  var REVISION_SEARCH_PARAM = "__WB_REVISION__";
  function createCacheKey(entry) {
    if (!entry) {
      throw new WorkboxError("add-to-cache-list-unexpected-type", { entry });
    }
    if (typeof entry === "string") {
      const urlObject = new URL(entry, location.href);
      return {
        cacheKey: urlObject.href,
        url: urlObject.href
      };
    }
    const { revision, url } = entry;
    if (!url) {
      throw new WorkboxError("add-to-cache-list-unexpected-type", { entry });
    }
    if (!revision) {
      const urlObject = new URL(url, location.href);
      return {
        cacheKey: urlObject.href,
        url: urlObject.href
      };
    }
    const cacheKeyURL = new URL(url, location.href);
    const originalURL = new URL(url, location.href);
    cacheKeyURL.searchParams.set(REVISION_SEARCH_PARAM, revision);
    return {
      cacheKey: cacheKeyURL.href,
      url: originalURL.href
    };
  }

  // node_modules/workbox-precaching/utils/PrecacheInstallReportPlugin.js
  var PrecacheInstallReportPlugin = class {
    constructor() {
      this.updatedURLs = [];
      this.notUpdatedURLs = [];
      this.handlerWillStart = async ({ request, state }) => {
        if (state) {
          state.originalRequest = request;
        }
      };
      this.cachedResponseWillBeUsed = async ({ event, state, cachedResponse }) => {
        if (event.type === "install") {
          if (state && state.originalRequest && state.originalRequest instanceof Request) {
            const url = state.originalRequest.url;
            if (cachedResponse) {
              this.notUpdatedURLs.push(url);
            } else {
              this.updatedURLs.push(url);
            }
          }
        }
        return cachedResponse;
      };
    }
  };

  // node_modules/workbox-precaching/utils/PrecacheCacheKeyPlugin.js
  var PrecacheCacheKeyPlugin = class {
    constructor({ precacheController: precacheController2 }) {
      this.cacheKeyWillBeUsed = async ({ request, params }) => {
        const cacheKey = (params === null || params === void 0 ? void 0 : params.cacheKey) || this._precacheController.getCacheKeyForURL(request.url);
        return cacheKey ? new Request(cacheKey, { headers: request.headers }) : request;
      };
      this._precacheController = precacheController2;
    }
  };

  // node_modules/workbox-strategies/_version.js
  try {
    self["workbox:strategies:7.4.0"] && _();
  } catch (e) {
  }

  // node_modules/workbox-strategies/StrategyHandler.js
  function toRequest(input) {
    return typeof input === "string" ? new Request(input) : input;
  }
  var StrategyHandler = class {
    /**
     * Creates a new instance associated with the passed strategy and event
     * that's handling the request.
     *
     * The constructor also initializes the state that will be passed to each of
     * the plugins handling this request.
     *
     * @param {workbox-strategies.Strategy} strategy
     * @param {Object} options
     * @param {Request|string} options.request A request to run this strategy for.
     * @param {ExtendableEvent} options.event The event associated with the
     *     request.
     * @param {URL} [options.url]
     * @param {*} [options.params] The return value from the
     *     {@link workbox-routing~matchCallback} (if applicable).
     */
    constructor(strategy, options) {
      this._cacheKeys = {};
      if (false) {
        finalAssertExports.isInstance(options.event, ExtendableEvent, {
          moduleName: "workbox-strategies",
          className: "StrategyHandler",
          funcName: "constructor",
          paramName: "options.event"
        });
      }
      Object.assign(this, options);
      this.event = options.event;
      this._strategy = strategy;
      this._handlerDeferred = new Deferred();
      this._extendLifetimePromises = [];
      this._plugins = [...strategy.plugins];
      this._pluginStateMap = /* @__PURE__ */ new Map();
      for (const plugin of this._plugins) {
        this._pluginStateMap.set(plugin, {});
      }
      this.event.waitUntil(this._handlerDeferred.promise);
    }
    /**
     * Fetches a given request (and invokes any applicable plugin callback
     * methods) using the `fetchOptions` (for non-navigation requests) and
     * `plugins` defined on the `Strategy` object.
     *
     * The following plugin lifecycle methods are invoked when using this method:
     * - `requestWillFetch()`
     * - `fetchDidSucceed()`
     * - `fetchDidFail()`
     *
     * @param {Request|string} input The URL or request to fetch.
     * @return {Promise<Response>}
     */
    async fetch(input) {
      const { event } = this;
      let request = toRequest(input);
      if (request.mode === "navigate" && event instanceof FetchEvent && event.preloadResponse) {
        const possiblePreloadResponse = await event.preloadResponse;
        if (possiblePreloadResponse) {
          if (false) {
            logger.log(`Using a preloaded navigation response for '${getFriendlyURL(request.url)}'`);
          }
          return possiblePreloadResponse;
        }
      }
      const originalRequest = this.hasCallback("fetchDidFail") ? request.clone() : null;
      try {
        for (const cb of this.iterateCallbacks("requestWillFetch")) {
          request = await cb({ request: request.clone(), event });
        }
      } catch (err) {
        if (err instanceof Error) {
          throw new WorkboxError("plugin-error-request-will-fetch", {
            thrownErrorMessage: err.message
          });
        }
      }
      const pluginFilteredRequest = request.clone();
      try {
        let fetchResponse;
        fetchResponse = await fetch(request, request.mode === "navigate" ? void 0 : this._strategy.fetchOptions);
        if (false) {
          logger.debug(`Network request for '${getFriendlyURL(request.url)}' returned a response with status '${fetchResponse.status}'.`);
        }
        for (const callback of this.iterateCallbacks("fetchDidSucceed")) {
          fetchResponse = await callback({
            event,
            request: pluginFilteredRequest,
            response: fetchResponse
          });
        }
        return fetchResponse;
      } catch (error) {
        if (false) {
          logger.log(`Network request for '${getFriendlyURL(request.url)}' threw an error.`, error);
        }
        if (originalRequest) {
          await this.runCallbacks("fetchDidFail", {
            error,
            event,
            originalRequest: originalRequest.clone(),
            request: pluginFilteredRequest.clone()
          });
        }
        throw error;
      }
    }
    /**
     * Calls `this.fetch()` and (in the background) runs `this.cachePut()` on
     * the response generated by `this.fetch()`.
     *
     * The call to `this.cachePut()` automatically invokes `this.waitUntil()`,
     * so you do not have to manually call `waitUntil()` on the event.
     *
     * @param {Request|string} input The request or URL to fetch and cache.
     * @return {Promise<Response>}
     */
    async fetchAndCachePut(input) {
      const response = await this.fetch(input);
      const responseClone = response.clone();
      void this.waitUntil(this.cachePut(input, responseClone));
      return response;
    }
    /**
     * Matches a request from the cache (and invokes any applicable plugin
     * callback methods) using the `cacheName`, `matchOptions`, and `plugins`
     * defined on the strategy object.
     *
     * The following plugin lifecycle methods are invoked when using this method:
     * - cacheKeyWillBeUsed()
     * - cachedResponseWillBeUsed()
     *
     * @param {Request|string} key The Request or URL to use as the cache key.
     * @return {Promise<Response|undefined>} A matching response, if found.
     */
    async cacheMatch(key) {
      const request = toRequest(key);
      let cachedResponse;
      const { cacheName, matchOptions } = this._strategy;
      const effectiveRequest = await this.getCacheKey(request, "read");
      const multiMatchOptions = Object.assign(Object.assign({}, matchOptions), { cacheName });
      cachedResponse = await caches.match(effectiveRequest, multiMatchOptions);
      if (false) {
        if (cachedResponse) {
          logger.debug(`Found a cached response in '${cacheName}'.`);
        } else {
          logger.debug(`No cached response found in '${cacheName}'.`);
        }
      }
      for (const callback of this.iterateCallbacks("cachedResponseWillBeUsed")) {
        cachedResponse = await callback({
          cacheName,
          matchOptions,
          cachedResponse,
          request: effectiveRequest,
          event: this.event
        }) || void 0;
      }
      return cachedResponse;
    }
    /**
     * Puts a request/response pair in the cache (and invokes any applicable
     * plugin callback methods) using the `cacheName` and `plugins` defined on
     * the strategy object.
     *
     * The following plugin lifecycle methods are invoked when using this method:
     * - cacheKeyWillBeUsed()
     * - cacheWillUpdate()
     * - cacheDidUpdate()
     *
     * @param {Request|string} key The request or URL to use as the cache key.
     * @param {Response} response The response to cache.
     * @return {Promise<boolean>} `false` if a cacheWillUpdate caused the response
     * not be cached, and `true` otherwise.
     */
    async cachePut(key, response) {
      const request = toRequest(key);
      await timeout(0);
      const effectiveRequest = await this.getCacheKey(request, "write");
      if (false) {
        if (effectiveRequest.method && effectiveRequest.method !== "GET") {
          throw new WorkboxError("attempt-to-cache-non-get-request", {
            url: getFriendlyURL(effectiveRequest.url),
            method: effectiveRequest.method
          });
        }
        const vary = response.headers.get("Vary");
        if (vary) {
          logger.debug(`The response for ${getFriendlyURL(effectiveRequest.url)} has a 'Vary: ${vary}' header. Consider setting the {ignoreVary: true} option on your strategy to ensure cache matching and deletion works as expected.`);
        }
      }
      if (!response) {
        if (false) {
          logger.error(`Cannot cache non-existent response for '${getFriendlyURL(effectiveRequest.url)}'.`);
        }
        throw new WorkboxError("cache-put-with-no-response", {
          url: getFriendlyURL(effectiveRequest.url)
        });
      }
      const responseToCache = await this._ensureResponseSafeToCache(response);
      if (!responseToCache) {
        if (false) {
          logger.debug(`Response '${getFriendlyURL(effectiveRequest.url)}' will not be cached.`, responseToCache);
        }
        return false;
      }
      const { cacheName, matchOptions } = this._strategy;
      const cache = await self.caches.open(cacheName);
      const hasCacheUpdateCallback = this.hasCallback("cacheDidUpdate");
      const oldResponse = hasCacheUpdateCallback ? await cacheMatchIgnoreParams(
        // TODO(philipwalton): the `__WB_REVISION__` param is a precaching
        // feature. Consider into ways to only add this behavior if using
        // precaching.
        cache,
        effectiveRequest.clone(),
        ["__WB_REVISION__"],
        matchOptions
      ) : null;
      if (false) {
        logger.debug(`Updating the '${cacheName}' cache with a new Response for ${getFriendlyURL(effectiveRequest.url)}.`);
      }
      try {
        await cache.put(effectiveRequest, hasCacheUpdateCallback ? responseToCache.clone() : responseToCache);
      } catch (error) {
        if (error instanceof Error) {
          if (error.name === "QuotaExceededError") {
            await executeQuotaErrorCallbacks();
          }
          throw error;
        }
      }
      for (const callback of this.iterateCallbacks("cacheDidUpdate")) {
        await callback({
          cacheName,
          oldResponse,
          newResponse: responseToCache.clone(),
          request: effectiveRequest,
          event: this.event
        });
      }
      return true;
    }
    /**
     * Checks the list of plugins for the `cacheKeyWillBeUsed` callback, and
     * executes any of those callbacks found in sequence. The final `Request`
     * object returned by the last plugin is treated as the cache key for cache
     * reads and/or writes. If no `cacheKeyWillBeUsed` plugin callbacks have
     * been registered, the passed request is returned unmodified
     *
     * @param {Request} request
     * @param {string} mode
     * @return {Promise<Request>}
     */
    async getCacheKey(request, mode) {
      const key = `${request.url} | ${mode}`;
      if (!this._cacheKeys[key]) {
        let effectiveRequest = request;
        for (const callback of this.iterateCallbacks("cacheKeyWillBeUsed")) {
          effectiveRequest = toRequest(await callback({
            mode,
            request: effectiveRequest,
            event: this.event,
            // params has a type any can't change right now.
            params: this.params
            // eslint-disable-line
          }));
        }
        this._cacheKeys[key] = effectiveRequest;
      }
      return this._cacheKeys[key];
    }
    /**
     * Returns true if the strategy has at least one plugin with the given
     * callback.
     *
     * @param {string} name The name of the callback to check for.
     * @return {boolean}
     */
    hasCallback(name) {
      for (const plugin of this._strategy.plugins) {
        if (name in plugin) {
          return true;
        }
      }
      return false;
    }
    /**
     * Runs all plugin callbacks matching the given name, in order, passing the
     * given param object (merged ith the current plugin state) as the only
     * argument.
     *
     * Note: since this method runs all plugins, it's not suitable for cases
     * where the return value of a callback needs to be applied prior to calling
     * the next callback. See
     * {@link workbox-strategies.StrategyHandler#iterateCallbacks}
     * below for how to handle that case.
     *
     * @param {string} name The name of the callback to run within each plugin.
     * @param {Object} param The object to pass as the first (and only) param
     *     when executing each callback. This object will be merged with the
     *     current plugin state prior to callback execution.
     */
    async runCallbacks(name, param) {
      for (const callback of this.iterateCallbacks(name)) {
        await callback(param);
      }
    }
    /**
     * Accepts a callback and returns an iterable of matching plugin callbacks,
     * where each callback is wrapped with the current handler state (i.e. when
     * you call each callback, whatever object parameter you pass it will
     * be merged with the plugin's current state).
     *
     * @param {string} name The name fo the callback to run
     * @return {Array<Function>}
     */
    *iterateCallbacks(name) {
      for (const plugin of this._strategy.plugins) {
        if (typeof plugin[name] === "function") {
          const state = this._pluginStateMap.get(plugin);
          const statefulCallback = (param) => {
            const statefulParam = Object.assign(Object.assign({}, param), { state });
            return plugin[name](statefulParam);
          };
          yield statefulCallback;
        }
      }
    }
    /**
     * Adds a promise to the
     * [extend lifetime promises]{@link https://w3c.github.io/ServiceWorker/#extendableevent-extend-lifetime-promises}
     * of the event associated with the request being handled (usually a
     * `FetchEvent`).
     *
     * Note: you can await
     * {@link workbox-strategies.StrategyHandler~doneWaiting}
     * to know when all added promises have settled.
     *
     * @param {Promise} promise A promise to add to the extend lifetime promises
     *     of the event that triggered the request.
     */
    waitUntil(promise) {
      this._extendLifetimePromises.push(promise);
      return promise;
    }
    /**
     * Returns a promise that resolves once all promises passed to
     * {@link workbox-strategies.StrategyHandler~waitUntil}
     * have settled.
     *
     * Note: any work done after `doneWaiting()` settles should be manually
     * passed to an event's `waitUntil()` method (not this handler's
     * `waitUntil()` method), otherwise the service worker thread may be killed
     * prior to your work completing.
     */
    async doneWaiting() {
      while (this._extendLifetimePromises.length) {
        const promises = this._extendLifetimePromises.splice(0);
        const result = await Promise.allSettled(promises);
        const firstRejection = result.find((i) => i.status === "rejected");
        if (firstRejection) {
          throw firstRejection.reason;
        }
      }
    }
    /**
     * Stops running the strategy and immediately resolves any pending
     * `waitUntil()` promises.
     */
    destroy() {
      this._handlerDeferred.resolve(null);
    }
    /**
     * This method will call cacheWillUpdate on the available plugins (or use
     * status === 200) to determine if the Response is safe and valid to cache.
     *
     * @param {Request} options.request
     * @param {Response} options.response
     * @return {Promise<Response|undefined>}
     *
     * @private
     */
    async _ensureResponseSafeToCache(response) {
      let responseToCache = response;
      let pluginsUsed = false;
      for (const callback of this.iterateCallbacks("cacheWillUpdate")) {
        responseToCache = await callback({
          request: this.request,
          response: responseToCache,
          event: this.event
        }) || void 0;
        pluginsUsed = true;
        if (!responseToCache) {
          break;
        }
      }
      if (!pluginsUsed) {
        if (responseToCache && responseToCache.status !== 200) {
          responseToCache = void 0;
        }
        if (false) {
          if (responseToCache) {
            if (responseToCache.status !== 200) {
              if (responseToCache.status === 0) {
                logger.warn(`The response for '${this.request.url}' is an opaque response. The caching strategy that you're using will not cache opaque responses by default.`);
              } else {
                logger.debug(`The response for '${this.request.url}' returned a status code of '${response.status}' and won't be cached as a result.`);
              }
            }
          }
        }
      }
      return responseToCache;
    }
  };

  // node_modules/workbox-strategies/Strategy.js
  var Strategy = class {
    /**
     * Creates a new instance of the strategy and sets all documented option
     * properties as public instance properties.
     *
     * Note: if a custom strategy class extends the base Strategy class and does
     * not need more than these properties, it does not need to define its own
     * constructor.
     *
     * @param {Object} [options]
     * @param {string} [options.cacheName] Cache name to store and retrieve
     * requests. Defaults to the cache names provided by
     * {@link workbox-core.cacheNames}.
     * @param {Array<Object>} [options.plugins] [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
     * to use in conjunction with this caching strategy.
     * @param {Object} [options.fetchOptions] Values passed along to the
     * [`init`](https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters)
     * of [non-navigation](https://github.com/GoogleChrome/workbox/issues/1796)
     * `fetch()` requests made by this strategy.
     * @param {Object} [options.matchOptions] The
     * [`CacheQueryOptions`]{@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions}
     * for any `cache.match()` or `cache.put()` calls made by this strategy.
     */
    constructor(options = {}) {
      this.cacheName = cacheNames.getRuntimeName(options.cacheName);
      this.plugins = options.plugins || [];
      this.fetchOptions = options.fetchOptions;
      this.matchOptions = options.matchOptions;
    }
    /**
     * Perform a request strategy and returns a `Promise` that will resolve with
     * a `Response`, invoking all relevant plugin callbacks.
     *
     * When a strategy instance is registered with a Workbox
     * {@link workbox-routing.Route}, this method is automatically
     * called when the route matches.
     *
     * Alternatively, this method can be used in a standalone `FetchEvent`
     * listener by passing it to `event.respondWith()`.
     *
     * @param {FetchEvent|Object} options A `FetchEvent` or an object with the
     *     properties listed below.
     * @param {Request|string} options.request A request to run this strategy for.
     * @param {ExtendableEvent} options.event The event associated with the
     *     request.
     * @param {URL} [options.url]
     * @param {*} [options.params]
     */
    handle(options) {
      const [responseDone] = this.handleAll(options);
      return responseDone;
    }
    /**
     * Similar to {@link workbox-strategies.Strategy~handle}, but
     * instead of just returning a `Promise` that resolves to a `Response` it
     * it will return an tuple of `[response, done]` promises, where the former
     * (`response`) is equivalent to what `handle()` returns, and the latter is a
     * Promise that will resolve once any promises that were added to
     * `event.waitUntil()` as part of performing the strategy have completed.
     *
     * You can await the `done` promise to ensure any extra work performed by
     * the strategy (usually caching responses) completes successfully.
     *
     * @param {FetchEvent|Object} options A `FetchEvent` or an object with the
     *     properties listed below.
     * @param {Request|string} options.request A request to run this strategy for.
     * @param {ExtendableEvent} options.event The event associated with the
     *     request.
     * @param {URL} [options.url]
     * @param {*} [options.params]
     * @return {Array<Promise>} A tuple of [response, done]
     *     promises that can be used to determine when the response resolves as
     *     well as when the handler has completed all its work.
     */
    handleAll(options) {
      if (options instanceof FetchEvent) {
        options = {
          event: options,
          request: options.request
        };
      }
      const event = options.event;
      const request = typeof options.request === "string" ? new Request(options.request) : options.request;
      const params = "params" in options ? options.params : void 0;
      const handler = new StrategyHandler(this, { event, request, params });
      const responseDone = this._getResponse(handler, request, event);
      const handlerDone = this._awaitComplete(responseDone, handler, request, event);
      return [responseDone, handlerDone];
    }
    async _getResponse(handler, request, event) {
      await handler.runCallbacks("handlerWillStart", { event, request });
      let response = void 0;
      try {
        response = await this._handle(request, handler);
        if (!response || response.type === "error") {
          throw new WorkboxError("no-response", { url: request.url });
        }
      } catch (error) {
        if (error instanceof Error) {
          for (const callback of handler.iterateCallbacks("handlerDidError")) {
            response = await callback({ error, event, request });
            if (response) {
              break;
            }
          }
        }
        if (!response) {
          throw error;
        } else if (false) {
          logger.log(`While responding to '${getFriendlyURL(request.url)}', an ${error instanceof Error ? error.toString() : ""} error occurred. Using a fallback response provided by a handlerDidError plugin.`);
        }
      }
      for (const callback of handler.iterateCallbacks("handlerWillRespond")) {
        response = await callback({ event, request, response });
      }
      return response;
    }
    async _awaitComplete(responseDone, handler, request, event) {
      let response;
      let error;
      try {
        response = await responseDone;
      } catch (error2) {
      }
      try {
        await handler.runCallbacks("handlerDidRespond", {
          event,
          request,
          response
        });
        await handler.doneWaiting();
      } catch (waitUntilError) {
        if (waitUntilError instanceof Error) {
          error = waitUntilError;
        }
      }
      await handler.runCallbacks("handlerDidComplete", {
        event,
        request,
        response,
        error
      });
      handler.destroy();
      if (error) {
        throw error;
      }
    }
  };

  // node_modules/workbox-precaching/PrecacheStrategy.js
  var PrecacheStrategy = class _PrecacheStrategy extends Strategy {
    /**
     *
     * @param {Object} [options]
     * @param {string} [options.cacheName] Cache name to store and retrieve
     * requests. Defaults to the cache names provided by
     * {@link workbox-core.cacheNames}.
     * @param {Array<Object>} [options.plugins] {@link https://developers.google.com/web/tools/workbox/guides/using-plugins|Plugins}
     * to use in conjunction with this caching strategy.
     * @param {Object} [options.fetchOptions] Values passed along to the
     * {@link https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters|init}
     * of all fetch() requests made by this strategy.
     * @param {Object} [options.matchOptions] The
     * {@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions|CacheQueryOptions}
     * for any `cache.match()` or `cache.put()` calls made by this strategy.
     * @param {boolean} [options.fallbackToNetwork=true] Whether to attempt to
     * get the response from the network if there's a precache miss.
     */
    constructor(options = {}) {
      options.cacheName = cacheNames.getPrecacheName(options.cacheName);
      super(options);
      this._fallbackToNetwork = options.fallbackToNetwork === false ? false : true;
      this.plugins.push(_PrecacheStrategy.copyRedirectedCacheableResponsesPlugin);
    }
    /**
     * @private
     * @param {Request|string} request A request to run this strategy for.
     * @param {workbox-strategies.StrategyHandler} handler The event that
     *     triggered the request.
     * @return {Promise<Response>}
     */
    async _handle(request, handler) {
      const response = await handler.cacheMatch(request);
      if (response) {
        return response;
      }
      if (handler.event && handler.event.type === "install") {
        return await this._handleInstall(request, handler);
      }
      return await this._handleFetch(request, handler);
    }
    async _handleFetch(request, handler) {
      let response;
      const params = handler.params || {};
      if (this._fallbackToNetwork) {
        if (false) {
          logger.warn(`The precached response for ${getFriendlyURL(request.url)} in ${this.cacheName} was not found. Falling back to the network.`);
        }
        const integrityInManifest = params.integrity;
        const integrityInRequest = request.integrity;
        const noIntegrityConflict = !integrityInRequest || integrityInRequest === integrityInManifest;
        response = await handler.fetch(new Request(request, {
          integrity: request.mode !== "no-cors" ? integrityInRequest || integrityInManifest : void 0
        }));
        if (integrityInManifest && noIntegrityConflict && request.mode !== "no-cors") {
          this._useDefaultCacheabilityPluginIfNeeded();
          const wasCached = await handler.cachePut(request, response.clone());
          if (false) {
            if (wasCached) {
              logger.log(`A response for ${getFriendlyURL(request.url)} was used to "repair" the precache.`);
            }
          }
        }
      } else {
        throw new WorkboxError("missing-precache-entry", {
          cacheName: this.cacheName,
          url: request.url
        });
      }
      if (false) {
        const cacheKey = params.cacheKey || await handler.getCacheKey(request, "read");
        logger.groupCollapsed(`Precaching is responding to: ` + getFriendlyURL(request.url));
        logger.log(`Serving the precached url: ${getFriendlyURL(cacheKey instanceof Request ? cacheKey.url : cacheKey)}`);
        logger.groupCollapsed(`View request details here.`);
        logger.log(request);
        logger.groupEnd();
        logger.groupCollapsed(`View response details here.`);
        logger.log(response);
        logger.groupEnd();
        logger.groupEnd();
      }
      return response;
    }
    async _handleInstall(request, handler) {
      this._useDefaultCacheabilityPluginIfNeeded();
      const response = await handler.fetch(request);
      const wasCached = await handler.cachePut(request, response.clone());
      if (!wasCached) {
        throw new WorkboxError("bad-precaching-response", {
          url: request.url,
          status: response.status
        });
      }
      return response;
    }
    /**
     * This method is complex, as there a number of things to account for:
     *
     * The `plugins` array can be set at construction, and/or it might be added to
     * to at any time before the strategy is used.
     *
     * At the time the strategy is used (i.e. during an `install` event), there
     * needs to be at least one plugin that implements `cacheWillUpdate` in the
     * array, other than `copyRedirectedCacheableResponsesPlugin`.
     *
     * - If this method is called and there are no suitable `cacheWillUpdate`
     * plugins, we need to add `defaultPrecacheCacheabilityPlugin`.
     *
     * - If this method is called and there is exactly one `cacheWillUpdate`, then
     * we don't have to do anything (this might be a previously added
     * `defaultPrecacheCacheabilityPlugin`, or it might be a custom plugin).
     *
     * - If this method is called and there is more than one `cacheWillUpdate`,
     * then we need to check if one is `defaultPrecacheCacheabilityPlugin`. If so,
     * we need to remove it. (This situation is unlikely, but it could happen if
     * the strategy is used multiple times, the first without a `cacheWillUpdate`,
     * and then later on after manually adding a custom `cacheWillUpdate`.)
     *
     * See https://github.com/GoogleChrome/workbox/issues/2737 for more context.
     *
     * @private
     */
    _useDefaultCacheabilityPluginIfNeeded() {
      let defaultPluginIndex = null;
      let cacheWillUpdatePluginCount = 0;
      for (const [index, plugin] of this.plugins.entries()) {
        if (plugin === _PrecacheStrategy.copyRedirectedCacheableResponsesPlugin) {
          continue;
        }
        if (plugin === _PrecacheStrategy.defaultPrecacheCacheabilityPlugin) {
          defaultPluginIndex = index;
        }
        if (plugin.cacheWillUpdate) {
          cacheWillUpdatePluginCount++;
        }
      }
      if (cacheWillUpdatePluginCount === 0) {
        this.plugins.push(_PrecacheStrategy.defaultPrecacheCacheabilityPlugin);
      } else if (cacheWillUpdatePluginCount > 1 && defaultPluginIndex !== null) {
        this.plugins.splice(defaultPluginIndex, 1);
      }
    }
  };
  PrecacheStrategy.defaultPrecacheCacheabilityPlugin = {
    async cacheWillUpdate({ response }) {
      if (!response || response.status >= 400) {
        return null;
      }
      return response;
    }
  };
  PrecacheStrategy.copyRedirectedCacheableResponsesPlugin = {
    async cacheWillUpdate({ response }) {
      return response.redirected ? await copyResponse(response) : response;
    }
  };

  // node_modules/workbox-precaching/PrecacheController.js
  var PrecacheController = class {
    /**
     * Create a new PrecacheController.
     *
     * @param {Object} [options]
     * @param {string} [options.cacheName] The cache to use for precaching.
     * @param {string} [options.plugins] Plugins to use when precaching as well
     * as responding to fetch events for precached assets.
     * @param {boolean} [options.fallbackToNetwork=true] Whether to attempt to
     * get the response from the network if there's a precache miss.
     */
    constructor({ cacheName, plugins = [], fallbackToNetwork = true } = {}) {
      this._urlsToCacheKeys = /* @__PURE__ */ new Map();
      this._urlsToCacheModes = /* @__PURE__ */ new Map();
      this._cacheKeysToIntegrities = /* @__PURE__ */ new Map();
      this._strategy = new PrecacheStrategy({
        cacheName: cacheNames.getPrecacheName(cacheName),
        plugins: [
          ...plugins,
          new PrecacheCacheKeyPlugin({ precacheController: this })
        ],
        fallbackToNetwork
      });
      this.install = this.install.bind(this);
      this.activate = this.activate.bind(this);
    }
    /**
     * @type {workbox-precaching.PrecacheStrategy} The strategy created by this controller and
     * used to cache assets and respond to fetch events.
     */
    get strategy() {
      return this._strategy;
    }
    /**
     * Adds items to the precache list, removing any duplicates and
     * stores the files in the
     * {@link workbox-core.cacheNames|"precache cache"} when the service
     * worker installs.
     *
     * This method can be called multiple times.
     *
     * @param {Array<Object|string>} [entries=[]] Array of entries to precache.
     */
    precache(entries) {
      this.addToCacheList(entries);
      if (!this._installAndActiveListenersAdded) {
        self.addEventListener("install", this.install);
        self.addEventListener("activate", this.activate);
        this._installAndActiveListenersAdded = true;
      }
    }
    /**
     * This method will add items to the precache list, removing duplicates
     * and ensuring the information is valid.
     *
     * @param {Array<workbox-precaching.PrecacheController.PrecacheEntry|string>} entries
     *     Array of entries to precache.
     */
    addToCacheList(entries) {
      if (false) {
        finalAssertExports.isArray(entries, {
          moduleName: "workbox-precaching",
          className: "PrecacheController",
          funcName: "addToCacheList",
          paramName: "entries"
        });
      }
      const urlsToWarnAbout = [];
      for (const entry of entries) {
        if (typeof entry === "string") {
          urlsToWarnAbout.push(entry);
        } else if (entry && entry.revision === void 0) {
          urlsToWarnAbout.push(entry.url);
        }
        const { cacheKey, url } = createCacheKey(entry);
        const cacheMode = typeof entry !== "string" && entry.revision ? "reload" : "default";
        if (this._urlsToCacheKeys.has(url) && this._urlsToCacheKeys.get(url) !== cacheKey) {
          throw new WorkboxError("add-to-cache-list-conflicting-entries", {
            firstEntry: this._urlsToCacheKeys.get(url),
            secondEntry: cacheKey
          });
        }
        if (typeof entry !== "string" && entry.integrity) {
          if (this._cacheKeysToIntegrities.has(cacheKey) && this._cacheKeysToIntegrities.get(cacheKey) !== entry.integrity) {
            throw new WorkboxError("add-to-cache-list-conflicting-integrities", {
              url
            });
          }
          this._cacheKeysToIntegrities.set(cacheKey, entry.integrity);
        }
        this._urlsToCacheKeys.set(url, cacheKey);
        this._urlsToCacheModes.set(url, cacheMode);
        if (urlsToWarnAbout.length > 0) {
          const warningMessage = `Workbox is precaching URLs without revision info: ${urlsToWarnAbout.join(", ")}
This is generally NOT safe. Learn more at https://bit.ly/wb-precache`;
          if (true) {
            console.warn(warningMessage);
          } else {
            logger.warn(warningMessage);
          }
        }
      }
    }
    /**
     * Precaches new and updated assets. Call this method from the service worker
     * install event.
     *
     * Note: this method calls `event.waitUntil()` for you, so you do not need
     * to call it yourself in your event handlers.
     *
     * @param {ExtendableEvent} event
     * @return {Promise<workbox-precaching.InstallResult>}
     */
    install(event) {
      return waitUntil(event, async () => {
        const installReportPlugin = new PrecacheInstallReportPlugin();
        this.strategy.plugins.push(installReportPlugin);
        for (const [url, cacheKey] of this._urlsToCacheKeys) {
          const integrity = this._cacheKeysToIntegrities.get(cacheKey);
          const cacheMode = this._urlsToCacheModes.get(url);
          const request = new Request(url, {
            integrity,
            cache: cacheMode,
            credentials: "same-origin"
          });
          await Promise.all(this.strategy.handleAll({
            params: { cacheKey },
            request,
            event
          }));
        }
        const { updatedURLs, notUpdatedURLs } = installReportPlugin;
        if (false) {
          printInstallDetails(updatedURLs, notUpdatedURLs);
        }
        return { updatedURLs, notUpdatedURLs };
      });
    }
    /**
     * Deletes assets that are no longer present in the current precache manifest.
     * Call this method from the service worker activate event.
     *
     * Note: this method calls `event.waitUntil()` for you, so you do not need
     * to call it yourself in your event handlers.
     *
     * @param {ExtendableEvent} event
     * @return {Promise<workbox-precaching.CleanupResult>}
     */
    activate(event) {
      return waitUntil(event, async () => {
        const cache = await self.caches.open(this.strategy.cacheName);
        const currentlyCachedRequests = await cache.keys();
        const expectedCacheKeys = new Set(this._urlsToCacheKeys.values());
        const deletedURLs = [];
        for (const request of currentlyCachedRequests) {
          if (!expectedCacheKeys.has(request.url)) {
            await cache.delete(request);
            deletedURLs.push(request.url);
          }
        }
        if (false) {
          printCleanupDetails(deletedURLs);
        }
        return { deletedURLs };
      });
    }
    /**
     * Returns a mapping of a precached URL to the corresponding cache key, taking
     * into account the revision information for the URL.
     *
     * @return {Map<string, string>} A URL to cache key mapping.
     */
    getURLsToCacheKeys() {
      return this._urlsToCacheKeys;
    }
    /**
     * Returns a list of all the URLs that have been precached by the current
     * service worker.
     *
     * @return {Array<string>} The precached URLs.
     */
    getCachedURLs() {
      return [...this._urlsToCacheKeys.keys()];
    }
    /**
     * Returns the cache key used for storing a given URL. If that URL is
     * unversioned, like `/index.html', then the cache key will be the original
     * URL with a search parameter appended to it.
     *
     * @param {string} url A URL whose cache key you want to look up.
     * @return {string} The versioned URL that corresponds to a cache key
     * for the original URL, or undefined if that URL isn't precached.
     */
    getCacheKeyForURL(url) {
      const urlObject = new URL(url, location.href);
      return this._urlsToCacheKeys.get(urlObject.href);
    }
    /**
     * @param {string} url A cache key whose SRI you want to look up.
     * @return {string} The subresource integrity associated with the cache key,
     * or undefined if it's not set.
     */
    getIntegrityForCacheKey(cacheKey) {
      return this._cacheKeysToIntegrities.get(cacheKey);
    }
    /**
     * This acts as a drop-in replacement for
     * [`cache.match()`](https://developer.mozilla.org/en-US/docs/Web/API/Cache/match)
     * with the following differences:
     *
     * - It knows what the name of the precache is, and only checks in that cache.
     * - It allows you to pass in an "original" URL without versioning parameters,
     * and it will automatically look up the correct cache key for the currently
     * active revision of that URL.
     *
     * E.g., `matchPrecache('index.html')` will find the correct precached
     * response for the currently active service worker, even if the actual cache
     * key is `'/index.html?__WB_REVISION__=1234abcd'`.
     *
     * @param {string|Request} request The key (without revisioning parameters)
     * to look up in the precache.
     * @return {Promise<Response|undefined>}
     */
    async matchPrecache(request) {
      const url = request instanceof Request ? request.url : request;
      const cacheKey = this.getCacheKeyForURL(url);
      if (cacheKey) {
        const cache = await self.caches.open(this.strategy.cacheName);
        return cache.match(cacheKey);
      }
      return void 0;
    }
    /**
     * Returns a function that looks up `url` in the precache (taking into
     * account revision information), and returns the corresponding `Response`.
     *
     * @param {string} url The precached URL which will be used to lookup the
     * `Response`.
     * @return {workbox-routing~handlerCallback}
     */
    createHandlerBoundToURL(url) {
      const cacheKey = this.getCacheKeyForURL(url);
      if (!cacheKey) {
        throw new WorkboxError("non-precached-url", { url });
      }
      return (options) => {
        options.request = new Request(url);
        options.params = Object.assign({ cacheKey }, options.params);
        return this.strategy.handle(options);
      };
    }
  };

  // node_modules/workbox-precaching/utils/getOrCreatePrecacheController.js
  var precacheController;
  var getOrCreatePrecacheController = () => {
    if (!precacheController) {
      precacheController = new PrecacheController();
    }
    return precacheController;
  };

  // node_modules/workbox-routing/_version.js
  try {
    self["workbox:routing:7.4.0"] && _();
  } catch (e) {
  }

  // node_modules/workbox-routing/utils/constants.js
  var defaultMethod = "GET";

  // node_modules/workbox-routing/utils/normalizeHandler.js
  var normalizeHandler = (handler) => {
    if (handler && typeof handler === "object") {
      if (false) {
        finalAssertExports.hasMethod(handler, "handle", {
          moduleName: "workbox-routing",
          className: "Route",
          funcName: "constructor",
          paramName: "handler"
        });
      }
      return handler;
    } else {
      if (false) {
        finalAssertExports.isType(handler, "function", {
          moduleName: "workbox-routing",
          className: "Route",
          funcName: "constructor",
          paramName: "handler"
        });
      }
      return { handle: handler };
    }
  };

  // node_modules/workbox-routing/Route.js
  var Route = class {
    /**
     * Constructor for Route class.
     *
     * @param {workbox-routing~matchCallback} match
     * A callback function that determines whether the route matches a given
     * `fetch` event by returning a non-falsy value.
     * @param {workbox-routing~handlerCallback} handler A callback
     * function that returns a Promise resolving to a Response.
     * @param {string} [method='GET'] The HTTP method to match the Route
     * against.
     */
    constructor(match, handler, method = defaultMethod) {
      if (false) {
        finalAssertExports.isType(match, "function", {
          moduleName: "workbox-routing",
          className: "Route",
          funcName: "constructor",
          paramName: "match"
        });
        if (method) {
          finalAssertExports.isOneOf(method, validMethods, { paramName: "method" });
        }
      }
      this.handler = normalizeHandler(handler);
      this.match = match;
      this.method = method;
    }
    /**
     *
     * @param {workbox-routing-handlerCallback} handler A callback
     * function that returns a Promise resolving to a Response
     */
    setCatchHandler(handler) {
      this.catchHandler = normalizeHandler(handler);
    }
  };

  // node_modules/workbox-routing/RegExpRoute.js
  var RegExpRoute = class extends Route {
    /**
     * If the regular expression contains
     * [capture groups]{@link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp#grouping-back-references},
     * the captured values will be passed to the
     * {@link workbox-routing~handlerCallback} `params`
     * argument.
     *
     * @param {RegExp} regExp The regular expression to match against URLs.
     * @param {workbox-routing~handlerCallback} handler A callback
     * function that returns a Promise resulting in a Response.
     * @param {string} [method='GET'] The HTTP method to match the Route
     * against.
     */
    constructor(regExp, handler, method) {
      if (false) {
        finalAssertExports.isInstance(regExp, RegExp, {
          moduleName: "workbox-routing",
          className: "RegExpRoute",
          funcName: "constructor",
          paramName: "pattern"
        });
      }
      const match = ({ url }) => {
        const result = regExp.exec(url.href);
        if (!result) {
          return;
        }
        if (url.origin !== location.origin && result.index !== 0) {
          if (false) {
            logger.debug(`The regular expression '${regExp.toString()}' only partially matched against the cross-origin URL '${url.toString()}'. RegExpRoute's will only handle cross-origin requests if they match the entire URL.`);
          }
          return;
        }
        return result.slice(1);
      };
      super(match, handler, method);
    }
  };

  // node_modules/workbox-routing/Router.js
  var Router = class {
    /**
     * Initializes a new Router.
     */
    constructor() {
      this._routes = /* @__PURE__ */ new Map();
      this._defaultHandlerMap = /* @__PURE__ */ new Map();
    }
    /**
     * @return {Map<string, Array<workbox-routing.Route>>} routes A `Map` of HTTP
     * method name ('GET', etc.) to an array of all the corresponding `Route`
     * instances that are registered.
     */
    get routes() {
      return this._routes;
    }
    /**
     * Adds a fetch event listener to respond to events when a route matches
     * the event's request.
     */
    addFetchListener() {
      self.addEventListener("fetch", ((event) => {
        const { request } = event;
        const responsePromise = this.handleRequest({ request, event });
        if (responsePromise) {
          event.respondWith(responsePromise);
        }
      }));
    }
    /**
     * Adds a message event listener for URLs to cache from the window.
     * This is useful to cache resources loaded on the page prior to when the
     * service worker started controlling it.
     *
     * The format of the message data sent from the window should be as follows.
     * Where the `urlsToCache` array may consist of URL strings or an array of
     * URL string + `requestInit` object (the same as you'd pass to `fetch()`).
     *
     * ```
     * {
     *   type: 'CACHE_URLS',
     *   payload: {
     *     urlsToCache: [
     *       './script1.js',
     *       './script2.js',
     *       ['./script3.js', {mode: 'no-cors'}],
     *     ],
     *   },
     * }
     * ```
     */
    addCacheListener() {
      self.addEventListener("message", ((event) => {
        if (event.data && event.data.type === "CACHE_URLS") {
          const { payload } = event.data;
          if (false) {
            logger.debug(`Caching URLs from the window`, payload.urlsToCache);
          }
          const requestPromises = Promise.all(payload.urlsToCache.map((entry) => {
            if (typeof entry === "string") {
              entry = [entry];
            }
            const request = new Request(...entry);
            return this.handleRequest({ request, event });
          }));
          event.waitUntil(requestPromises);
          if (event.ports && event.ports[0]) {
            void requestPromises.then(() => event.ports[0].postMessage(true));
          }
        }
      }));
    }
    /**
     * Apply the routing rules to a FetchEvent object to get a Response from an
     * appropriate Route's handler.
     *
     * @param {Object} options
     * @param {Request} options.request The request to handle.
     * @param {ExtendableEvent} options.event The event that triggered the
     *     request.
     * @return {Promise<Response>|undefined} A promise is returned if a
     *     registered route can handle the request. If there is no matching
     *     route and there's no `defaultHandler`, `undefined` is returned.
     */
    handleRequest({ request, event }) {
      if (false) {
        finalAssertExports.isInstance(request, Request, {
          moduleName: "workbox-routing",
          className: "Router",
          funcName: "handleRequest",
          paramName: "options.request"
        });
      }
      const url = new URL(request.url, location.href);
      if (!url.protocol.startsWith("http")) {
        if (false) {
          logger.debug(`Workbox Router only supports URLs that start with 'http'.`);
        }
        return;
      }
      const sameOrigin = url.origin === location.origin;
      const { params, route } = this.findMatchingRoute({
        event,
        request,
        sameOrigin,
        url
      });
      let handler = route && route.handler;
      const debugMessages = [];
      if (false) {
        if (handler) {
          debugMessages.push([`Found a route to handle this request:`, route]);
          if (params) {
            debugMessages.push([
              `Passing the following params to the route's handler:`,
              params
            ]);
          }
        }
      }
      const method = request.method;
      if (!handler && this._defaultHandlerMap.has(method)) {
        if (false) {
          debugMessages.push(`Failed to find a matching route. Falling back to the default handler for ${method}.`);
        }
        handler = this._defaultHandlerMap.get(method);
      }
      if (!handler) {
        if (false) {
          logger.debug(`No route found for: ${getFriendlyURL(url)}`);
        }
        return;
      }
      if (false) {
        logger.groupCollapsed(`Router is responding to: ${getFriendlyURL(url)}`);
        debugMessages.forEach((msg) => {
          if (Array.isArray(msg)) {
            logger.log(...msg);
          } else {
            logger.log(msg);
          }
        });
        logger.groupEnd();
      }
      let responsePromise;
      try {
        responsePromise = handler.handle({ url, request, event, params });
      } catch (err) {
        responsePromise = Promise.reject(err);
      }
      const catchHandler = route && route.catchHandler;
      if (responsePromise instanceof Promise && (this._catchHandler || catchHandler)) {
        responsePromise = responsePromise.catch(async (err) => {
          if (catchHandler) {
            if (false) {
              logger.groupCollapsed(`Error thrown when responding to:  ${getFriendlyURL(url)}. Falling back to route's Catch Handler.`);
              logger.error(`Error thrown by:`, route);
              logger.error(err);
              logger.groupEnd();
            }
            try {
              return await catchHandler.handle({ url, request, event, params });
            } catch (catchErr) {
              if (catchErr instanceof Error) {
                err = catchErr;
              }
            }
          }
          if (this._catchHandler) {
            if (false) {
              logger.groupCollapsed(`Error thrown when responding to:  ${getFriendlyURL(url)}. Falling back to global Catch Handler.`);
              logger.error(`Error thrown by:`, route);
              logger.error(err);
              logger.groupEnd();
            }
            return this._catchHandler.handle({ url, request, event });
          }
          throw err;
        });
      }
      return responsePromise;
    }
    /**
     * Checks a request and URL (and optionally an event) against the list of
     * registered routes, and if there's a match, returns the corresponding
     * route along with any params generated by the match.
     *
     * @param {Object} options
     * @param {URL} options.url
     * @param {boolean} options.sameOrigin The result of comparing `url.origin`
     *     against the current origin.
     * @param {Request} options.request The request to match.
     * @param {Event} options.event The corresponding event.
     * @return {Object} An object with `route` and `params` properties.
     *     They are populated if a matching route was found or `undefined`
     *     otherwise.
     */
    findMatchingRoute({ url, sameOrigin, request, event }) {
      const routes = this._routes.get(request.method) || [];
      for (const route of routes) {
        let params;
        const matchResult = route.match({ url, sameOrigin, request, event });
        if (matchResult) {
          if (false) {
            if (matchResult instanceof Promise) {
              logger.warn(`While routing ${getFriendlyURL(url)}, an async matchCallback function was used. Please convert the following route to use a synchronous matchCallback function:`, route);
            }
          }
          params = matchResult;
          if (Array.isArray(params) && params.length === 0) {
            params = void 0;
          } else if (matchResult.constructor === Object && // eslint-disable-line
          Object.keys(matchResult).length === 0) {
            params = void 0;
          } else if (typeof matchResult === "boolean") {
            params = void 0;
          }
          return { route, params };
        }
      }
      return {};
    }
    /**
     * Define a default `handler` that's called when no routes explicitly
     * match the incoming request.
     *
     * Each HTTP method ('GET', 'POST', etc.) gets its own default handler.
     *
     * Without a default handler, unmatched requests will go against the
     * network as if there were no service worker present.
     *
     * @param {workbox-routing~handlerCallback} handler A callback
     * function that returns a Promise resulting in a Response.
     * @param {string} [method='GET'] The HTTP method to associate with this
     * default handler. Each method has its own default.
     */
    setDefaultHandler(handler, method = defaultMethod) {
      this._defaultHandlerMap.set(method, normalizeHandler(handler));
    }
    /**
     * If a Route throws an error while handling a request, this `handler`
     * will be called and given a chance to provide a response.
     *
     * @param {workbox-routing~handlerCallback} handler A callback
     * function that returns a Promise resulting in a Response.
     */
    setCatchHandler(handler) {
      this._catchHandler = normalizeHandler(handler);
    }
    /**
     * Registers a route with the router.
     *
     * @param {workbox-routing.Route} route The route to register.
     */
    registerRoute(route) {
      if (false) {
        finalAssertExports.isType(route, "object", {
          moduleName: "workbox-routing",
          className: "Router",
          funcName: "registerRoute",
          paramName: "route"
        });
        finalAssertExports.hasMethod(route, "match", {
          moduleName: "workbox-routing",
          className: "Router",
          funcName: "registerRoute",
          paramName: "route"
        });
        finalAssertExports.isType(route.handler, "object", {
          moduleName: "workbox-routing",
          className: "Router",
          funcName: "registerRoute",
          paramName: "route"
        });
        finalAssertExports.hasMethod(route.handler, "handle", {
          moduleName: "workbox-routing",
          className: "Router",
          funcName: "registerRoute",
          paramName: "route.handler"
        });
        finalAssertExports.isType(route.method, "string", {
          moduleName: "workbox-routing",
          className: "Router",
          funcName: "registerRoute",
          paramName: "route.method"
        });
      }
      if (!this._routes.has(route.method)) {
        this._routes.set(route.method, []);
      }
      this._routes.get(route.method).push(route);
    }
    /**
     * Unregisters a route with the router.
     *
     * @param {workbox-routing.Route} route The route to unregister.
     */
    unregisterRoute(route) {
      if (!this._routes.has(route.method)) {
        throw new WorkboxError("unregister-route-but-not-found-with-method", {
          method: route.method
        });
      }
      const routeIndex = this._routes.get(route.method).indexOf(route);
      if (routeIndex > -1) {
        this._routes.get(route.method).splice(routeIndex, 1);
      } else {
        throw new WorkboxError("unregister-route-route-not-registered");
      }
    }
  };

  // node_modules/workbox-routing/utils/getOrCreateDefaultRouter.js
  var defaultRouter;
  var getOrCreateDefaultRouter = () => {
    if (!defaultRouter) {
      defaultRouter = new Router();
      defaultRouter.addFetchListener();
      defaultRouter.addCacheListener();
    }
    return defaultRouter;
  };

  // node_modules/workbox-routing/registerRoute.js
  function registerRoute(capture, handler, method) {
    let route;
    if (typeof capture === "string") {
      const captureUrl = new URL(capture, location.href);
      if (false) {
        if (!(capture.startsWith("/") || capture.startsWith("http"))) {
          throw new WorkboxError("invalid-string", {
            moduleName: "workbox-routing",
            funcName: "registerRoute",
            paramName: "capture"
          });
        }
        const valueToCheck = capture.startsWith("http") ? captureUrl.pathname : capture;
        const wildcards = "[*:?+]";
        if (new RegExp(`${wildcards}`).exec(valueToCheck)) {
          logger.debug(`The '$capture' parameter contains an Express-style wildcard character (${wildcards}). Strings are now always interpreted as exact matches; use a RegExp for partial or wildcard matches.`);
        }
      }
      const matchCallback = ({ url }) => {
        if (false) {
          if (url.pathname === captureUrl.pathname && url.origin !== captureUrl.origin) {
            logger.debug(`${capture} only partially matches the cross-origin URL ${url.toString()}. This route will only handle cross-origin requests if they match the entire URL.`);
          }
        }
        return url.href === captureUrl.href;
      };
      route = new Route(matchCallback, handler, method);
    } else if (capture instanceof RegExp) {
      route = new RegExpRoute(capture, handler, method);
    } else if (typeof capture === "function") {
      route = new Route(capture, handler, method);
    } else if (capture instanceof Route) {
      route = capture;
    } else {
      throw new WorkboxError("unsupported-route-type", {
        moduleName: "workbox-routing",
        funcName: "registerRoute",
        paramName: "capture"
      });
    }
    const defaultRouter2 = getOrCreateDefaultRouter();
    defaultRouter2.registerRoute(route);
    return route;
  }

  // node_modules/workbox-precaching/utils/removeIgnoredSearchParams.js
  function removeIgnoredSearchParams(urlObject, ignoreURLParametersMatching = []) {
    for (const paramName of [...urlObject.searchParams.keys()]) {
      if (ignoreURLParametersMatching.some((regExp) => regExp.test(paramName))) {
        urlObject.searchParams.delete(paramName);
      }
    }
    return urlObject;
  }

  // node_modules/workbox-precaching/utils/generateURLVariations.js
  function* generateURLVariations(url, { ignoreURLParametersMatching = [/^utm_/, /^fbclid$/], directoryIndex = "index.html", cleanURLs = true, urlManipulation } = {}) {
    const urlObject = new URL(url, location.href);
    urlObject.hash = "";
    yield urlObject.href;
    const urlWithoutIgnoredParams = removeIgnoredSearchParams(urlObject, ignoreURLParametersMatching);
    yield urlWithoutIgnoredParams.href;
    if (directoryIndex && urlWithoutIgnoredParams.pathname.endsWith("/")) {
      const directoryURL = new URL(urlWithoutIgnoredParams.href);
      directoryURL.pathname += directoryIndex;
      yield directoryURL.href;
    }
    if (cleanURLs) {
      const cleanURL = new URL(urlWithoutIgnoredParams.href);
      cleanURL.pathname += ".html";
      yield cleanURL.href;
    }
    if (urlManipulation) {
      const additionalURLs = urlManipulation({ url: urlObject });
      for (const urlToAttempt of additionalURLs) {
        yield urlToAttempt.href;
      }
    }
  }

  // node_modules/workbox-precaching/PrecacheRoute.js
  var PrecacheRoute = class extends Route {
    /**
     * @param {PrecacheController} precacheController A `PrecacheController`
     * instance used to both match requests and respond to fetch events.
     * @param {Object} [options] Options to control how requests are matched
     * against the list of precached URLs.
     * @param {string} [options.directoryIndex=index.html] The `directoryIndex` will
     * check cache entries for a URLs ending with '/' to see if there is a hit when
     * appending the `directoryIndex` value.
     * @param {Array<RegExp>} [options.ignoreURLParametersMatching=[/^utm_/, /^fbclid$/]] An
     * array of regex's to remove search params when looking for a cache match.
     * @param {boolean} [options.cleanURLs=true] The `cleanURLs` option will
     * check the cache for the URL with a `.html` added to the end of the end.
     * @param {workbox-precaching~urlManipulation} [options.urlManipulation]
     * This is a function that should take a URL and return an array of
     * alternative URLs that should be checked for precache matches.
     */
    constructor(precacheController2, options) {
      const match = ({ request }) => {
        const urlsToCacheKeys = precacheController2.getURLsToCacheKeys();
        for (const possibleURL of generateURLVariations(request.url, options)) {
          const cacheKey = urlsToCacheKeys.get(possibleURL);
          if (cacheKey) {
            const integrity = precacheController2.getIntegrityForCacheKey(cacheKey);
            return { cacheKey, integrity };
          }
        }
        if (false) {
          logger.debug(`Precaching did not find a match for ` + getFriendlyURL(request.url));
        }
        return;
      };
      super(match, precacheController2.strategy);
    }
  };

  // node_modules/workbox-precaching/addRoute.js
  function addRoute(options) {
    const precacheController2 = getOrCreatePrecacheController();
    const precacheRoute = new PrecacheRoute(precacheController2, options);
    registerRoute(precacheRoute);
  }

  // node_modules/workbox-precaching/createHandlerBoundToURL.js
  function createHandlerBoundToURL(url) {
    const precacheController2 = getOrCreatePrecacheController();
    return precacheController2.createHandlerBoundToURL(url);
  }

  // node_modules/workbox-precaching/precache.js
  function precache(entries) {
    const precacheController2 = getOrCreatePrecacheController();
    precacheController2.precache(entries);
  }

  // node_modules/workbox-precaching/precacheAndRoute.js
  function precacheAndRoute(entries, options) {
    precache(entries);
    addRoute(options);
  }

  // node_modules/workbox-strategies/plugins/cacheOkAndOpaquePlugin.js
  var cacheOkAndOpaquePlugin = {
    /**
     * Returns a valid response (to allow caching) if the status is 200 (OK) or
     * 0 (opaque).
     *
     * @param {Object} options
     * @param {Response} options.response
     * @return {Response|null}
     *
     * @private
     */
    cacheWillUpdate: async ({ response }) => {
      if (response.status === 200 || response.status === 0) {
        return response;
      }
      return null;
    }
  };

  // node_modules/workbox-strategies/StaleWhileRevalidate.js
  var StaleWhileRevalidate = class extends Strategy {
    /**
     * @param {Object} [options]
     * @param {string} [options.cacheName] Cache name to store and retrieve
     * requests. Defaults to cache names provided by
     * {@link workbox-core.cacheNames}.
     * @param {Array<Object>} [options.plugins] [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
     * to use in conjunction with this caching strategy.
     * @param {Object} [options.fetchOptions] Values passed along to the
     * [`init`](https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters)
     * of [non-navigation](https://github.com/GoogleChrome/workbox/issues/1796)
     * `fetch()` requests made by this strategy.
     * @param {Object} [options.matchOptions] [`CacheQueryOptions`](https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions)
     */
    constructor(options = {}) {
      super(options);
      if (!this.plugins.some((p) => "cacheWillUpdate" in p)) {
        this.plugins.unshift(cacheOkAndOpaquePlugin);
      }
    }
    /**
     * @private
     * @param {Request|string} request A request to run this strategy for.
     * @param {workbox-strategies.StrategyHandler} handler The event that
     *     triggered the request.
     * @return {Promise<Response>}
     */
    async _handle(request, handler) {
      const logs = [];
      if (false) {
        finalAssertExports.isInstance(request, Request, {
          moduleName: "workbox-strategies",
          className: this.constructor.name,
          funcName: "handle",
          paramName: "request"
        });
      }
      const fetchAndCachePromise = handler.fetchAndCachePut(request).catch(() => {
      });
      void handler.waitUntil(fetchAndCachePromise);
      let response = await handler.cacheMatch(request);
      let error;
      if (response) {
        if (false) {
          logs.push(`Found a cached response in the '${this.cacheName}' cache. Will update with the network response in the background.`);
        }
      } else {
        if (false) {
          logs.push(`No response found in the '${this.cacheName}' cache. Will wait for the network response.`);
        }
        try {
          response = await fetchAndCachePromise;
        } catch (err) {
          if (err instanceof Error) {
            error = err;
          }
        }
      }
      if (false) {
        logger.groupCollapsed(messages2.strategyStart(this.constructor.name, request));
        for (const log of logs) {
          logger.log(log);
        }
        messages2.printFinalResponse(response);
        logger.groupEnd();
      }
      if (!response) {
        throw new WorkboxError("no-response", { url: request.url, error });
      }
      return response;
    }
  };

  // src/service-worker.ts
  clientsClaim();
  precacheAndRoute([{"revision":"fa1ded1ed7c11438a9b0385b1e112850","url":"robots.txt"},{"revision":"01f98e528ad7cea3b7952c6e75126256","url":"manifest.json"},{"revision":"917515db74ea8d1aee6a246cfbcc0b45","url":"logo512.png"},{"revision":"33dbdd0177549353eeeb785d02c294af","url":"logo192.png"},{"revision":"8603c5a0c6b3740c29c2e52eeb6bb647","url":"index.html"},{"revision":"c92b85a5b907c70211f4ec25e29a8c4a","url":"favicon.ico"},{"revision":"137d862b8b0380b19fe3ea4bcc945ea3","url":"static/js/lib-router.01768dc5f8.js.LICENSE.txt"},{"revision":"e77c59d65b03d4fce74591334de895f3","url":"static/js/lib-router.01768dc5f8.js"},{"revision":"b241f244e088423b41d2fcf4930a1593","url":"static/js/lib-react.603e4b997f.js.LICENSE.txt"},{"revision":"76b0438699c903252aa4d5d901589818","url":"static/js/lib-react.603e4b997f.js"},{"revision":"aaed8165df223404822b75bda44e7060","url":"static/js/j.893e7281b0.js.LICENSE.txt"},{"revision":"98e587ef250a77aa2e2a0f681e3f31e3","url":"static/js/j.893e7281b0.js"},{"revision":"95fb2b481153ef53d41295fb213f97df","url":"static/js/index.121e936de7.js"},{"revision":"27a4a03a4b56ffec4c494920ae29a8fb","url":"static/js/async/z8.a96053bca1.js"},{"revision":"995cce523d5d5b114301f2d103914a1d","url":"static/js/async/z1.1666a5e845.js"},{"revision":"f23a045ebdda096a38af7df5ef3f4d53","url":"static/js/async/z.3cf2b7734a.js"},{"revision":"cf6104fd1e783ba4ce771f9a24c6e759","url":"static/js/async/yj.97e2d7740f.js"},{"revision":"349673242fddcdf02e399d331bc6144d","url":"static/js/async/y6.e983991928.js"},{"revision":"29e19829d601bfc6570c8da24ae1f6c6","url":"static/js/async/y4.9c4e5fdd80.js"},{"revision":"9b33d35e9c56cbd8eeefa6879e1c738e","url":"static/js/async/y.f928f5b195.js"},{"revision":"fee6ec898df4947a6e55062979f9ab79","url":"static/js/async/x.616396b728.js"},{"revision":"1057ab605a82b222d90aef28ccbb53bd","url":"static/js/async/wa.ffb249974e.js"},{"revision":"7f9d758cdda5d60f34e5b8a1084e0479","url":"static/js/async/w1.5156164931.js"},{"revision":"2861ad33a82f81807839cda51f3fd17f","url":"static/js/async/w.05a8214b10.js"},{"revision":"8a5a7a53c1ef0a9d31f19552b5d90620","url":"static/js/async/vx.796674153d.js.LICENSE.txt"},{"revision":"1630c05be4bd5332d335ef222c9f8235","url":"static/js/async/vx.796674153d.js"},{"revision":"4f5d84a8e9aa9feb3539752cd9ece035","url":"static/js/async/vv.948e58db6c.js"},{"revision":"2b5467539ffa210ed78bfdb297583b2b","url":"static/js/async/vq.95747688dc.js"},{"revision":"0614a62f15066a54a3d26fe9a6bc9556","url":"static/js/async/vh.f21e75dacc.js"},{"revision":"ef96213cf017fc97dbb02c427b9ec858","url":"static/js/async/vd.0f59cf2e67.js"},{"revision":"df98ad01d7dbad80257cbb46bf2edded","url":"static/js/async/vb.829cf195c7.js"},{"revision":"494cf6623607646ade278de4d4034a92","url":"static/js/async/v4.7a6dcc2a96.js"},{"revision":"6d1f15c49c6f1f7ecabb8937b186a2ac","url":"static/js/async/v.43f973da40.js"},{"revision":"5449e7613d6ac0b2ae563a544ddb9de1","url":"static/js/async/ux.f7ff0e8b2b.js"},{"revision":"a7b02f31593a3f097779ff13e0ccfe3a","url":"static/js/async/up.21fc16ed25.js"},{"revision":"e9cab0035aae900cbe0bb4d59cc86d7e","url":"static/js/async/um.1134a18bf1.js"},{"revision":"6743b2faaf2d37e21f43eb50c027a59a","url":"static/js/async/ul.37b70c96a2.js"},{"revision":"d0b76b39ed38fe442b495ebc118bf61c","url":"static/js/async/uid.0fb15a5c25.js"},{"revision":"f7bd0e38a7dfb649342ca76315cd9ff0","url":"static/js/async/ui.1e72fabcfd.js"},{"revision":"72529385b109a0a993bbc73c39b2f34d","url":"static/js/async/ud.b1f42c7315.js"},{"revision":"3817edba662bc0592560076c56fdf34b","url":"static/js/async/ub.47a809d10a.js"},{"revision":"db2853c40c0a0cbe5c89e926fc158e40","url":"static/js/async/u6.d3f6ee43a5.js"},{"revision":"2548747d004d93a84fb14eb62182ea4b","url":"static/js/async/u0.17e1c2605c.js"},{"revision":"256485df315d86602a5969756b74a580","url":"static/js/async/u.3a603f50d1.js"},{"revision":"8fda9b810449597eba638dc5eda8b43d","url":"static/js/async/ti.6436a653a3.js"},{"revision":"40453c08f2dfd8b42082008d4875b479","url":"static/js/async/t7.7fb3fbbfdd.js"},{"revision":"5783e9765523a7aac81afe6ca8be5558","url":"static/js/async/t0.a8d37c70c6.js"},{"revision":"284f7aad2512e17e3b93bfd96f6b0c01","url":"static/js/async/t.74b3b4957e.js"},{"revision":"70d7791e9ebb072f311fe62706bb0acf","url":"static/js/async/s.d20ca53d61.js"},{"revision":"cfa32a8f62514d8cee125776d0689b26","url":"static/js/async/rq.9159e3618b.js"},{"revision":"caea2130fd3032d7d5036c25677e515e","url":"static/js/async/rd.f7c0976cf9.js"},{"revision":"78b2601d0740edc0ad46b08987aaa873","url":"static/js/async/r.a82a8510cd.js"},{"revision":"4cceb704a0d76c86b7d6341f9df54dde","url":"static/js/async/q.6fec39c203.js"},{"revision":"2ba59161bc3d24f75c2c887da4d009d0","url":"static/js/async/pu.a681a3061e.js"},{"revision":"09af151e19c28b85bd8cd3dcfb0b950a","url":"static/js/async/pq.a194b97931.js"},{"revision":"725f34b0c2bfd4fe2640fe56f48b0871","url":"static/js/async/pm.3541bdf02a.js"},{"revision":"c76ba0d1d1c08c86c637874a0a1d1f32","url":"static/js/async/pf.0a031ee4b8.js"},{"revision":"2525d21da9615113e36159cc884e0484","url":"static/js/async/p.00d55eb37c.js"},{"revision":"397fdfe78294e92cdd94e5ff2b503f66","url":"static/js/async/ox.7164412318.js"},{"revision":"3aab80e5cc73364aa8d2277d17fe8a27","url":"static/js/async/od.330e64f89c.js"},{"revision":"3791230d600aefb3aed265c5a482e08f","url":"static/js/async/o.3c1ed695bb.js"},{"revision":"c274bd523dd81750f4e1f85bf89df5b7","url":"static/js/async/n3.c0ac675ef3.js"},{"revision":"6db2d15211c17a3266c42aa2e5d73943","url":"static/js/async/n2.e28a150ff3.js"},{"revision":"2eb0798613b2f9cddfcabe04165744ce","url":"static/js/async/n.b823df6d38.js"},{"revision":"bfec512685224a1053750a851c753d9a","url":"static/js/async/mh.e73ae8ee5f.js"},{"revision":"8c74e746a893bc678ccabe83c51255c6","url":"static/js/async/ma.3cdfb31ae9.js"},{"revision":"ac32cb880d1fdf28a9c61cd1b5f1a1f0","url":"static/js/async/m1.180bc0d093.js"},{"revision":"d449c8a766008c138d6ea5ad053503ee","url":"static/js/async/m.28196c2d82.js"},{"revision":"cec676fda313eb32456b4158137d8233","url":"static/js/async/lk.16762b5f0f.js"},{"revision":"9ed5634e4caf4b690ed58f911c6886d1","url":"static/js/async/lc.51e361a370.js"},{"revision":"5fd673163d093eb2a32bde2fdf2d068d","url":"static/js/async/l3.de561fee7c.js"},{"revision":"bad784d3aa67291a1d5ecbe531f1a45b","url":"static/js/async/l.de3a28f84f.js"},{"revision":"09c0a11808ccd2af8b2609dc15436f86","url":"static/js/async/kx.734842a3b9.js"},{"revision":"2b7f69491a4be94e11e113b665fe6f10","url":"static/js/async/kn.1379b0b51b.js"},{"revision":"6464a263c3ccedbcd3ffed7139211c55","url":"static/js/async/ki.62df554769.js"},{"revision":"e211de5908cb64a409ad29b2881f6614","url":"static/js/async/k.3e018be029.js"},{"revision":"9e86be0ab982cfb87e096179f2709b36","url":"static/js/async/jz.a665e25657.js"},{"revision":"010447ee38b324d285bf8b662763ad54","url":"static/js/async/jq.84e8645f24.js"},{"revision":"2f9ca2d43bb8bb6d1d91d4f630e601e9","url":"static/js/async/jlx.7636e32a46.js"},{"revision":"53c82fe66256fde227eaf59600b5a4c3","url":"static/js/async/jl.3ac9b5a779.js"},{"revision":"44219fd2da95a54dc1687a212d916fd0","url":"static/js/async/jf.4b7c15e196.js"},{"revision":"d7a79df8a764141a913661f076c068d6","url":"static/js/async/it.ddabbe7b9f.js"},{"revision":"701fb22c74076639f84c7ddf5498edd6","url":"static/js/async/id.6b569917bd.js"},{"revision":"3ad893eaa127fdf4c015c086b4ec9ff5","url":"static/js/async/ic.f75ebefe7d.js.LICENSE.txt"},{"revision":"8ae98a9019d8dcd469e0b577cb23b3bf","url":"static/js/async/ic.f75ebefe7d.js"},{"revision":"5d08fe19a306716cd5c52f3626de7414","url":"static/js/async/i.e7863bcbed.js"},{"revision":"3e7168cdc65df88cf187c533b774bd33","url":"static/js/async/hv.ed5a6fb05c.js"},{"revision":"e3e465cd97b83c4ed8b82cb3ace93dd6","url":"static/js/async/hq.f5336296dd.js"},{"revision":"123a8168ce11173230fe7be10f741cf3","url":"static/js/async/hp.a8a992247b.js"},{"revision":"c73ea12d73dad136debf0b4b4f194dd4","url":"static/js/async/hn.deb224f112.js"},{"revision":"dba2a87c79bcdd2a89baba3c227b5c28","url":"static/js/async/hm.f379e40fbf.js"},{"revision":"0ced7204764bfffc01de25909a37711b","url":"static/js/async/hk.4e80e8b785.js"},{"revision":"680937d8f96aa5638fad17b37dd2b73c","url":"static/js/async/hi.fde020022e.js"},{"revision":"6dc487251dd8f6cc61004b5c63e0107a","url":"static/js/async/hh.b0356547ef.js"},{"revision":"4a1c35d5ff15c5c63a6bc1b5e8becd6d","url":"static/js/async/hed.027237db73.js"},{"revision":"c16fc08ce67450140d8cbda1331538af","url":"static/js/async/he.e0d62ac3fa.js"},{"revision":"08fb708f955c9dcaa6991e5e3d92925d","url":"static/js/async/hd.590ab9565f.js"},{"revision":"de16042d0e1b74605fae11e383650467","url":"static/js/async/h.58424ce5dd.js"},{"revision":"2bbd4b12d79aaa7876d32bff15e5fe04","url":"static/js/async/gz.3375aebb18.js"},{"revision":"f716bde4a27c6561c899ea2d892e151f","url":"static/js/async/gt.0074ed57f7.js"},{"revision":"e57bf2c1dfb64c706eb618b3d35aabc3","url":"static/js/async/gs.94c2d09dc3.js"},{"revision":"2c6e2cff444a3696d07c83fe310e2fb5","url":"static/js/async/g0.321b84be1e.js"},{"revision":"d110b4b3170af9680f856cd0b7876539","url":"static/js/async/g.a2045729dc.js"},{"revision":"4eb5979e3acffbfd65ab4ce060cc242d","url":"static/js/async/fv.ec766e8f98.js"},{"revision":"5f1b2ac2890fe4214158479ad2cd4bd3","url":"static/js/async/ft.e9a573407f.js"},{"revision":"f02549bc21d5f1a36dc15e73b5f19ae2","url":"static/js/async/fq.98a7fde544.js"},{"revision":"81d5f0995c770a19438dd44e4ec81378","url":"static/js/async/fj.e6077d3bd9.js"},{"revision":"49e980f72e9857f62c79bd26c15e546a","url":"static/js/async/fh.7a41b48d2e.js"},{"revision":"36c77a3bc0e9de7bb41b414692ef4ed5","url":"static/js/async/fd.9001679241.js"},{"revision":"fc92dcd8e366c0c3fa3ca262b0bb52c9","url":"static/js/async/f1.159d6a85c9.js"},{"revision":"b44bd25f4e845cc73ecc9eef088fcff5","url":"static/js/async/f.a5f493ec77.js"},{"revision":"806a48c41e49242f2b17071d6f6ead2a","url":"static/js/async/eu.b77e7882a8.js"},{"revision":"53a21aa6d8da3d991bbd1b43f4905d99","url":"static/js/async/eg.661f777f97.js"},{"revision":"42f8f8f87a413ba5cd5e3b043641139e","url":"static/js/async/ef.53ae90bf37.js"},{"revision":"b32dd126924a43c547b5ceeb56aa01b6","url":"static/js/async/e2.636a343a19.js"},{"revision":"2bcdb038ccfb7923bedc9875d6cae252","url":"static/js/async/e0.0e46f5d588.js"},{"revision":"204782f70c8245712762bdc66b345621","url":"static/js/async/e.f12721ca74.js"},{"revision":"01035d02f9d874642b66971ac155f95e","url":"static/js/async/cv.d78816fdcf.js"},{"revision":"9712ee25d3d712bf45824e843d2279dd","url":"static/js/async/cu.ab03a933d9.js"},{"revision":"558534820af4e9d1731c80b414aedda4","url":"static/js/async/ct.343f9c8a3e.js"},{"revision":"fec7366fbf796bcbcd9cf739d772bc8a","url":"static/js/async/ckw.d6a3fd75ba.js"},{"revision":"4b1942385d85d3e07b0f6c5469ff05b7","url":"static/js/async/ck.4810f99a0d.js"},{"revision":"148820ef77996a16d6578783a81e9fb5","url":"static/js/async/c.5012fd00af.js"},{"revision":"c904efa0f5037a5c7611d6a0750428c9","url":"static/js/async/bn.54aa253d52.js"},{"revision":"92e2f234a7fca67152d5dd7394a8f2a7","url":"static/js/async/b8.667bb89aa3.js"},{"revision":"91d3b4dba6f0ebfe8367dbe61cf8743f","url":"static/js/async/b4.c12535c6de.js"},{"revision":"3e61446e34c4f7f842422e767722bfad","url":"static/js/async/b.e9f923115b.js"},{"revision":"6d6f43377edec8c33233bec03e9dbdd5","url":"static/js/async/ad.f769810cef.js"},{"revision":"aea1c0c761c3cfb2524289da63e38afd","url":"static/js/async/ac.dabef2a39f.js"},{"revision":"09aa28f07c1194a5fa999ae75136cf8c","url":"static/js/async/a.60e695a551.js"},{"revision":"fe75443cd319ba9e57a070e7ebceba20","url":"static/js/async/9u.266284b1bc.js"},{"revision":"9d5032807d30d8e1cc29ae66851333f8","url":"static/js/async/9k.82f05ea6e2.js"},{"revision":"a2542aad2d22e69038fc9dbd287928ce","url":"static/js/async/99.97580ebe04.js"},{"revision":"c6f315d88bfc703110bf832d3ae527db","url":"static/js/async/9.ca3bd73ad3.js"},{"revision":"4177bcb4158399328d4cf19a87d08b04","url":"static/js/async/8w.5d2ade988f.js"},{"revision":"bc8498f781a634ae5250f681899097d8","url":"static/js/async/8p.b9ac956ba3.js"},{"revision":"7bf81648a04006aa6bbaa25236ab9a03","url":"static/js/async/8k.84c8932139.js"},{"revision":"7fbdede310c975311112e229b557f10a","url":"static/js/async/8c.6b2f131b86.js"},{"revision":"821f2dc0bb02e035baae7bd8aefe96aa","url":"static/js/async/8.8690f1db5b.js"},{"revision":"1387dd5e40642927a6a13b15561fd137","url":"static/js/async/7z.1a924db63d.js"},{"revision":"c4a2ae54eff567769d35391bdabd85ff","url":"static/js/async/7m.a6e5684b09.js"},{"revision":"c2274a155364e700e639fbfd0ade9d7e","url":"static/js/async/7d.f15a8864b7.js"},{"revision":"00f9cd272232c41adc3af4d8c11fa81c","url":"static/js/async/76.06c6dbccfe.js"},{"revision":"1095b2f5618610d7b15dd659a09ff2ac","url":"static/js/async/72.fd0803e021.js"},{"revision":"4d23c5db27e19e3192c142bdbab74a67","url":"static/js/async/7.9139f5ed8d.js"},{"revision":"6e8462062821b9f39fd6775fb33a1669","url":"static/js/async/6w.6b5a983911.js"},{"revision":"cad5c8c50cf5d2fa62bfefd64ab00f7e","url":"static/js/async/6h.23c0c33200.js"},{"revision":"39315ffb305d94b6b06c9648c80f97c3","url":"static/js/async/69.6d9a021ec2.js"},{"revision":"c7edd118238e69ac7d617ffc543b6a89","url":"static/js/async/6.795cb8aa9d.js"},{"revision":"9383ab2ed579da9e4c4d07d039c37c08","url":"static/js/async/54.fffe590fac.js"},{"revision":"7c6a8a149283c2281acdd7c438dd8fc5","url":"static/js/async/50.ddf8384258.js"},{"revision":"049213a244187132a4a6b5a11efddcf8","url":"static/js/async/5.66ff778197.js"},{"revision":"a83e90167e339946ea5cc05e6499cec4","url":"static/js/async/4.49516c56f9.js"},{"revision":"aff6b23dd19c66a090c5d4781db8444d","url":"static/js/async/3d.571eb72962.js"},{"revision":"c568f21d6ee5c5e9860ce863a1c54d99","url":"static/js/async/3.cfa938312e.js"},{"revision":"78121badf870d58e83605b7ce20a4096","url":"static/js/async/2s.d4c1c5f29d.js"},{"revision":"76b13624a81f4c067fbf2bafa45da029","url":"static/js/async/2.fcd71550b7.js"},{"revision":"fd84e28bfac1bb17ad9388905994e4da","url":"static/js/async/1y.08fd57beed.js"},{"revision":"14f2da1658e1e4a820ce35baaec9c3ec","url":"static/js/async/1u.e95f41d0c3.js"},{"revision":"72613093ed5d9f59048b5ba07a386dd2","url":"static/js/async/1i.4f5aba7459.js"},{"revision":"6e5c089dcbec6045d0bde8d546dd2a80","url":"static/js/async/1g.2b9dc5d190.js"},{"revision":"d82e463ab31e7696caa115103b87a7ba","url":"static/js/async/1eo.5303b9e85b.js"},{"revision":"af5fd4194a0ade471809179111229862","url":"static/js/async/1e.5fda994492.js"},{"revision":"e993c5d3ea6c639425f138b3a48f2a5f","url":"static/js/async/11.9087de4311.js"},{"revision":"3b3c7a62204b7556377cd1bbaa87ba08","url":"static/js/async/1.9b2571d2ff.js"},{"revision":"fcef7792559e616de0ec15a1a9bd5ef8","url":"static/js/async/0x.92f0bc4577.js"},{"revision":"6f1cf3ecba4480709208920c90c67627","url":"static/js/async/0t.84afcee4bd.js"},{"revision":"49e590e19271335958580f91fa8543ce","url":"static/js/async/0b.cb051110cb.js"},{"revision":"3a51bd4ce8249a4e156c8baca52b36cb","url":"static/js/async/0.867412ceef.js"},{"revision":"98fb0dd10c39e381b70914f913663515","url":"static/font/be-vietnam-pro-v10-vietnamese_latin-regular.9ed18734f7.woff2"},{"revision":"24e0a7a5b8dc632c07721813eedc965d","url":"static/font/be-vietnam-pro-v10-vietnamese_latin-800.83c5a45311.woff2"},{"revision":"952676e9783ef7b40c96a1840a3222bf","url":"static/font/be-vietnam-pro-v10-vietnamese_latin-700.91a16c72df.woff2"},{"revision":"61db62f1e23ec6d6a13862d5a7038854","url":"static/font/be-vietnam-pro-v10-vietnamese_latin-600.808e111a3f.woff2"},{"revision":"608282ab4f7faff19ab8c174e1b7ebaa","url":"static/font/be-vietnam-pro-v10-vietnamese_latin-500.6de72b40e4.woff2"},{"revision":"a8d700629f338a1622467ccb9381a12a","url":"static/css/index.f6a261f408.css"},{"revision":"e8929b7dee37874c05ca23ddd9083da5","url":"static/css/async/z.d482d49f9a.css"},{"revision":"ae0bc7ccb7a11d922f68b95fb53b28dd","url":"static/css/async/ux.438aa61691.css"},{"revision":"ae0bc7ccb7a11d922f68b95fb53b28dd","url":"static/css/async/u6.438aa61691.css"},{"revision":"ae0bc7ccb7a11d922f68b95fb53b28dd","url":"static/css/async/u.438aa61691.css"},{"revision":"e8929b7dee37874c05ca23ddd9083da5","url":"static/css/async/s.d482d49f9a.css"},{"revision":"ae0bc7ccb7a11d922f68b95fb53b28dd","url":"static/css/async/pf.438aa61691.css"},{"revision":"e8929b7dee37874c05ca23ddd9083da5","url":"static/css/async/m.d482d49f9a.css"},{"revision":"64143aa8001662d8b182d841fa874917","url":"static/css/async/kn.4db84bb2aa.css"},{"revision":"9d3462856e954d43758d72d2c4ab29b0","url":"static/css/async/ki.41160c310e.css"},{"revision":"e8929b7dee37874c05ca23ddd9083da5","url":"static/css/async/i.d482d49f9a.css"},{"revision":"ae0bc7ccb7a11d922f68b95fb53b28dd","url":"static/css/async/hv.438aa61691.css"},{"revision":"8937bf4499af219dedb6905ca6559ee8","url":"static/css/async/hq.f602038b5c.css"},{"revision":"9d3462856e954d43758d72d2c4ab29b0","url":"static/css/async/hh.41160c310e.css"},{"revision":"e8929b7dee37874c05ca23ddd9083da5","url":"static/css/async/ft.d482d49f9a.css"},{"revision":"d5e81eaf700ee7ed63ee239ade7f0622","url":"static/css/async/fd.3d8db94f24.css"},{"revision":"ae0bc7ccb7a11d922f68b95fb53b28dd","url":"static/css/async/ck.438aa61691.css"},{"revision":"ae0bc7ccb7a11d922f68b95fb53b28dd","url":"static/css/async/a.438aa61691.css"},{"revision":"e8929b7dee37874c05ca23ddd9083da5","url":"static/css/async/8.d482d49f9a.css"},{"revision":"e8929b7dee37874c05ca23ddd9083da5","url":"static/css/async/54.d482d49f9a.css"},{"revision":"e8929b7dee37874c05ca23ddd9083da5","url":"static/css/async/1e.d482d49f9a.css"},{"revision":"45fc23c46164b5292e431d6d76eb3605","url":"images/warningBg.png"},{"revision":"0feb1b579fbdfa0c95768b536b137a74","url":"images/splashScreen.png"},{"revision":"0a8e8501406bb5c31808d29648aba202","url":"images/showMore.png"},{"revision":"d811db923dde7dfaf0d26d24fb0d0744","url":"images/settingIcon.svg"},{"revision":"b6f333200748e1307187ae06e23c201f","url":"images/selectedIcon.svg"},{"revision":"d872a6f2e4fa4163aa5f1d1a318b6b06","url":"images/sample.png"},{"revision":"183813c9b7f5fcbe1e114abf1162cc8f","url":"images/receiveLinkBackground.png"},{"revision":"a5b2f948748690dc7d20aca6b84756ea","url":"images/qrPayME.png"},{"revision":"2ac021d4fc846bd6784bbdbeb635eec1","url":"images/qrLogo.png"},{"revision":"45a53a07a3b360f00ad07ade90e84156","url":"images/qrCodeMethod.png"},{"revision":"35210bb80b25335d725338a3904e1c62","url":"images/qrCodeBg.png"},{"revision":"22f896f72cac3abcc05fcb327fef42f8","url":"images/profileHeaderBackground.svg"},{"revision":"44002527178ef014d27f1b87b70e62b3","url":"images/pciLogo.svg"},{"revision":"7bc93bc429b351a2b14652fa0b9ddf2d","url":"images/paymeCreditMethod.png"},{"revision":"89e68b6ffcc3823ed11f58ff88cdd01f","url":"images/linkTransferBackground.png"},{"revision":"9212b9a4b2290d9c2e57a8319927f8af","url":"images/linkMethod.png"},{"revision":"4cceac9db124ac40862656f389405e38","url":"images/icon_bank.svg"},{"revision":"c18bd469b9b8b894a0db5864278388aa","url":"images/iconReload.png"},{"revision":"1ebc28198b08d1edc6748a9be4b8f6fb","url":"images/iconRefresh.png"},{"revision":"58f1f7f3275353a7ee98adce0031b3d3","url":"images/iconPayme.png"},{"revision":"51f0a0e25ed2e6d4c44c75eef9e3ff8f","url":"images/iconLink.png"},{"revision":"087f8bde6b8731e49f4eebb8cdf5ac59","url":"images/iconCredit.png"},{"revision":"83b2cbde2fcd4c13300d4e2dd72cc84e","url":"images/iconClose.png"},{"revision":"2be473e619493d2d59bea099f16b74fc","url":"images/iconCheck.svg"},{"revision":"a39e939e5d9ffb478422def306d1e67e","url":"images/iconAddCard.png"},{"revision":"7264bad4d5bffee4b7eb7bd453b13214","url":"images/footer.svg"},{"revision":"08150b5d487ac4c59187fe1f150c47c8","url":"images/flashIcon.svg"},{"revision":"c15e07748ad677a028a68fdf2e5013da","url":"images/dropDownIcon.png"},{"revision":"9068fdea35e3cac30affabd7da8dbc08","url":"images/downLoad.svg"},{"revision":"a030b1265b9676814883fea42d6f9add","url":"images/defaultAvatarContact.svg"},{"revision":"61c11056c812df14eab76f58eb599a87","url":"images/defaultAvatar.png"},{"revision":"5f8959a4ba74a10fba6e58d73e1d764b","url":"images/copyIcon.svg"},{"revision":"49adb5e7166985a079cd68a58747a456","url":"images/contract.png"},{"revision":"c52b6a39de63037457138490e4a04204","url":"images/cautionIcon.svg"},{"revision":"b4eb22c61e974a627f8a0f3a4be86179","url":"images/cameraIcon.svg"},{"revision":"68ccc6873ebf50c354f17785a05ed318","url":"images/bgCreateAccBank.png"},{"revision":"8ba3e51bbeae66a6e43bb5dee94174e3","url":"images/bank_default.png"},{"revision":"144652c9106abeaf11938c52f7732cba","url":"images/backgroundLogin.svg"},{"revision":"6c24415729deb8f96ca2e71f096b54cd","url":"images/atmMethod.png"},{"revision":"3f0b674c57cff39d10e9cb2924da24f7","url":"images/appIcon.svg"},{"revision":"49643fdd9e3b047b7ed9e38d75a70a27","url":"images/QRCode.svg"},{"revision":"41db98fed941b74d70a62b334b18b5f4","url":"images/toast/iconWarning.svg"},{"revision":"5038b41d9728e182a087b5064275d956","url":"images/toast/iconSuccess.svg"},{"revision":"86f19d358ddef7c7385e6302714aa3af","url":"images/toast/iconError.svg"},{"revision":"b7d9b2964193d46c48c9b014b22b64c7","url":"images/supplier/bill-ZING.png"},{"revision":"1c4377f984060118510a1f95b2fda881","url":"images/supplier/bill-VTVC.png"},{"revision":"37452a2bd73564f8e25d934dc8d3aeb1","url":"images/supplier/bill-VTC.png"},{"revision":"c60f1f4ad084a15fbc129f8d49eec0d0","url":"images/supplier/bill-VNPT.png"},{"revision":"8ba3b3f9d39d8a1c1d96d91feff0c453","url":"images/supplier/bill-VNPAYEVN.png"},{"revision":"218d51531e950d1f3bb09eb3b7c9a5a0","url":"images/supplier/bill-VINA.png"},{"revision":"12620149b4a033024c236ad5e4765820","url":"images/supplier/bill-VIETTEL.png"},{"revision":"66775d81cc13f0a3054545a4a26cabe0","url":"images/supplier/bill-VIETNAMOBILE.png"},{"revision":"5bc382422f4e04df7e9c61673a5e6108","url":"images/supplier/bill-VCOIN.png"},{"revision":"68ab675e189ee4e7a5eb20ebf16028b9","url":"images/supplier/bill-STT.png"},{"revision":"5ccaf463d582b7d48108b0eb0433f643","url":"images/supplier/bill-SST.png"},{"revision":"bde460255f865a6018cab991f89a43a2","url":"images/supplier/bill-SPT.png"},{"revision":"c8f130ad51d0f834d58ed3560452fbd8","url":"images/supplier/bill-SOHACOIN.png"},{"revision":"611ecb4f1c934a2c81b3deea442f30ee","url":"images/supplier/bill-SFONE.png"},{"revision":"46f5b2c51e7df7e8d287a1ff025f4e55","url":"images/supplier/bill-SCTVHCM.png"},{"revision":"c7078c7caf4ea9c46bd421103f3e4215","url":"images/supplier/bill-ONGAME.png"},{"revision":"66932c42aa1a905dbb4b2c80db9a4b1d","url":"images/supplier/bill-NUOC-VUNGTAU.png"},{"revision":"f51c94d9e6778e2cf178bc606e699b03","url":"images/supplier/bill-NUOC-VIWACO.png"},{"revision":"3fd38ae48f736f4be58e1089d41d6d2f","url":"images/supplier/bill-NUOC-VINHLONG.png"},{"revision":"30190b2f443ce68d9445a7050b723d35","url":"images/supplier/bill-NUOC-TRUNGAN.png"},{"revision":"b77528e1ca06af471672d2df4b72ff01","url":"images/supplier/bill-NUOC-TRANOC.png"},{"revision":"d4de748b8832596cfae3d903d8893db5","url":"images/supplier/bill-NUOC-TIENGIANG.png"},{"revision":"bc51c99ebfe7289c2ce270741516439a","url":"images/supplier/bill-NUOC-THUDUC.png"},{"revision":"960b4d98b190bec0ea4a8771345b494a","url":"images/supplier/bill-NUOC-THOTNOT.png"},{"revision":"42efb669add50a6443e0e360677c7a71","url":"images/supplier/bill-NUOC-TAYHANOI.png"},{"revision":"711842803dac3c9370e60cabbf9b36bb","url":"images/supplier/bill-NUOC-TANHOA.png"},{"revision":"194a5ad534d7a379068f7262e029cc0e","url":"images/supplier/bill-NUOC-SONTAY.png"},{"revision":"f81fcfe9978b1324afef6b530cc46dfc","url":"images/supplier/bill-NUOC-SONLA.png"},{"revision":"dd22cba30a514805020d8f40dcffc694","url":"images/supplier/bill-NUOC-SOCTRANG.png"},{"revision":"7853eaa5c00082c659060fcb5b8bdbc2","url":"images/supplier/bill-NUOC-QUANGTRI.png"},{"revision":"95f6d3a5d420b06ec3c2aeb79eac0610","url":"images/supplier/bill-NUOC-QUANGNINH.png"},{"revision":"9cd3dd96dbe1803b40b5fea0c6a0b7a9","url":"images/supplier/bill-NUOC-PHUHOATAN.png"},{"revision":"73c1fd77ec13ab8b7e790e33d28b8981","url":"images/supplier/bill-NUOC-NHONTRACH.png"},{"revision":"c37fe2e780a44fc3e0c2233ae2970221","url":"images/supplier/bill-NUOC-NHABE.png"},{"revision":"ed04c46d5e32bda2876f023a541153eb","url":"images/supplier/bill-NUOC-LONGKHANH.png"},{"revision":"d90bc2f64fe2f71e29d21c213bbda2fd","url":"images/supplier/bill-NUOC-LONGAN.png"},{"revision":"7599b4cc9858d246fa233656b5a89d47","url":"images/supplier/bill-NUOC-LAICHAU.png"},{"revision":"6fb4a604e0ca51840adee2f8cf1905b9","url":"images/supplier/bill-NUOC-HOABINH.png"},{"revision":"44a2c5b39b3718af7d42ff4673c1298c","url":"images/supplier/bill-NUOC-HANOIVTS.png"},{"revision":"be838047a86cce275712833b55d90245","url":"images/supplier/bill-NUOC-HANOIHAWACO.png"},{"revision":"55c245e13d2610eab9aea086c8a5e8d9","url":"images/supplier/bill-NUOC-HANOI3.png"},{"revision":"d8be1a6c3c16fb231c0f1286686f9b76","url":"images/supplier/bill-NUOC-HANOI2.png"},{"revision":"236cab82707ee0269dce07b69ce2a7cf","url":"images/supplier/bill-NUOC-HANAM.png"},{"revision":"f00fb0de25d7d3c4b4f860a709287dc1","url":"images/supplier/bill-NUOC-HAIPHONG.png"},{"revision":"473da1f38fc56b755a063af87a125372","url":"images/supplier/bill-NUOC-GIALAI.png"},{"revision":"7012fc8ccb95161831b1ca8ffb4e1b55","url":"images/supplier/bill-NUOC-GIADINH.png"},{"revision":"3f7f9b50ed8ea68f8c658041496e70a1","url":"images/supplier/bill-NUOC-DONGTHAP.png"},{"revision":"f09f4b0d67a4249e801ad46a862d2133","url":"images/supplier/bill-NUOC-DONGNAI.png"},{"revision":"3ab4fab0f776e39a1484dd385d58a2a1","url":"images/supplier/bill-NUOC-DANANG.png"},{"revision":"82b76a714444cbf505cd752601301688","url":"images/supplier/bill-NUOC-DAKLAK.png"},{"revision":"ca72329aa5f6eb95613d834863938094","url":"images/supplier/bill-NUOC-CUCHI.png"},{"revision":"5a7272b40ae9b835da45ac5246c68ee2","url":"images/supplier/bill-NUOC-CHOLON.png"},{"revision":"95b8c078dd072659b735668a4a41be57","url":"images/supplier/bill-NUOC-CAOBANG.png"},{"revision":"960b4d98b190bec0ea4a8771345b494a","url":"images/supplier/bill-NUOC-CANTHO.png"},{"revision":"ae0cc951034d46cc772dd8b77c85d725","url":"images/supplier/bill-NUOC-BINHTHUAN.png"},{"revision":"9c4fb317bb0871e27afe2785a9e32ded","url":"images/supplier/bill-NUOC-BINHDUONG.png"},{"revision":"5064154e2b20086ff716695edd74c29e","url":"images/supplier/bill-NUOC-BINHCHANH.png"},{"revision":"2722377b690f86ff457859390adc22ba","url":"images/supplier/bill-NUOC-BENTRE.png"},{"revision":"b0f8fdc66efad96e13ce3db86a9273ca","url":"images/supplier/bill-NUOC-BENTHANH.png"},{"revision":"d118ccbc697ffef7007de22e9c4d4e43","url":"images/supplier/bill-NUOC-BACLIEU.png"},{"revision":"99de52e0be46b7c3a1fd6b0cdc211f42","url":"images/supplier/bill-NUOC-ANGIANG.png"},{"revision":"87841ca72cb9a9e00302a7b8692728a8","url":"images/supplier/bill-NHUE.png"},{"revision":"681fb73a0304655525e65d097284bbab","url":"images/supplier/bill-NHCM_NONGTHON.png"},{"revision":"6ff0250c43f491abe21a61f81c499a91","url":"images/supplier/bill-NHCM_HOAANDONGNAI.png"},{"revision":"35e7724a7cadc650fc4bf4a9acf31d3b","url":"images/supplier/bill-NHCM.png"},{"revision":"ff8d4aa8e4877ed4ed34c97259c253d3","url":"images/supplier/bill-NCM.png"},{"revision":"dac78b6e565c1c4e9b6f215114526ce9","url":"images/supplier/bill-MYTV.png"},{"revision":"d5ce40f622b4d285b5e8d9fd95e77c96","url":"images/supplier/bill-MOBI.png"},{"revision":"961f1adc121f535c54760ffd19260ead","url":"images/supplier/bill-KPLUS.png"},{"revision":"6ebd34981d99aa9662be9b7d06ea04ff","url":"images/supplier/bill-HCATV.png"},{"revision":"97f7516296c0eeebda276d0bcce4663e","url":"images/supplier/bill-GMOBILE.png"},{"revision":"41f77c9e9c0f19def13dc32a8616be16","url":"images/supplier/bill-GATE.png"},{"revision":"76254d787a561521f4fda3d96c4bd24a","url":"images/supplier/bill-GARENA.png"},{"revision":"d88125d50e4b9279e35d16dcbd7382b4","url":"images/supplier/bill-FUNTAP.png"},{"revision":"8c2db826c88dd1f412fd5f380815ab10","url":"images/supplier/bill-FPT.png"},{"revision":"72e47c56f8c29c4a0f9e611f64adf763","url":"images/supplier/bill-EVNMN.png"},{"revision":"aa2d8043c2c14b4d9d201e5abddd022d","url":"images/supplier/bill-EVNMIENBAC.png"},{"revision":"001525380525a43162490aa882d03b8c","url":"images/supplier/bill-EVNHCM.png"},{"revision":"7e1cde50f8638f8f003d565deed0fc9b","url":"images/supplier/bill-EVNHANOI.png"},{"revision":"b3ddcf73d68377d79c0884217ec83294","url":"images/supplier/bill-EVN-TINHKHAC.png"},{"revision":"c5b236cc9fb5b0de4a4e155f3bba4bd4","url":"images/supplier/bill-EVN-MIENTRUNG.png"},{"revision":"a6e8d7340279b8a2e96453c7bf867ccf","url":"images/supplier/bill-CMC-TELECOM.png"},{"revision":"d6826d3d90bf1ea83f0fd7e8d8343b65","url":"images/supplier/bill-ANVIEN.png"},{"revision":"f793cac50750de0ec14aa013539b07dc","url":"images/supplier/bill-ADAPOTA.png"},{"revision":"f18b0deeb9c388720289cc10b5155991","url":"images/services/topup/iconTopupPermission.svg"},{"revision":"979f1326a3a3a3d24dc21dd4497edb1f","url":"images/services/bill/WATE_ROUND.svg"},{"revision":"7180f05152ad6a709756a1716a608dd0","url":"images/services/bill/WATE.svg"},{"revision":"f96e5bb6b5c871cc3376810af4ade5bc","url":"images/services/bill/TIVI.svg"},{"revision":"0be31f81f3c56a9ab18174ea0da965b5","url":"images/services/bill/PPMB.svg"},{"revision":"40ad0e523440c297fad54f9d3848bd9e","url":"images/services/bill/POWE_ROUND.svg"},{"revision":"8c28198a087673bc0c52b1aa56cf0f3d","url":"images/services/bill/POWE.svg"},{"revision":"62b67b871aa281b1ca5d62a4509e946d","url":"images/services/bill/MOTAIKHOAN.svg"},{"revision":"5994a6b765f11fdcca14a3b2c08518bb","url":"images/services/bill/MOBILE_TOPUP_ROUND.svg"},{"revision":"4badb6ad0bd753e521777c275f659eb4","url":"images/services/bill/MOBILE_TOPUP.svg"},{"revision":"5582a13463735502e49c7159adc1c16c","url":"images/services/bill/MOBILE_CARD_ROUND.svg"},{"revision":"92aa94ea1c31900699c464ba337b72bc","url":"images/services/bill/MOBILE_CARD.svg"},{"revision":"c45e6e3bdebc669b419dad39449afd16","url":"images/services/bill/GAME_CARD.svg"},{"revision":"91843ec7886f48340f7fa5af037ab16b","url":"images/services/bill/ADSL.svg"},{"revision":"cf63534a74394667c75dec5cd9a40f57","url":"images/salary-advance/salaryAdvancePending.png"},{"revision":"df3300b0e404ada1c10a548fe2958137","url":"images/salary-advance/salaryAdvanceIntro.png"},{"revision":"b63b7231de22cc12f3c8e0dc009cd8c3","url":"images/salary-advance/salaryAdvanceIcon.png"},{"revision":"65dfecbdd57d16ed62d6a36a94ae6d8d","url":"images/salary-advance/notification.png"},{"revision":"02ac6c2e461bb98b2b2acd6e02e15d2f","url":"images/salary-advance/icon_whitelist_salary_3.svg"},{"revision":"621983ffa92ba055be4f0d19bc6db195","url":"images/salary-advance/icon_whitelist_salary_2.svg"},{"revision":"c833603f9625c522daed27cdc03d6398","url":"images/salary-advance/icon_whitelist_salary_1.svg"},{"revision":"4fd52fff125d1237fc03df6f30a913d9","url":"images/salary-advance/icon_pay_store.svg"},{"revision":"7f3200e56389dcb52fdf982c8d93cf40","url":"images/salary-advance/chartIcon.png"},{"revision":"28a096bf5f5e7760090330409b4566d7","url":"images/profile/quocHuy.png"},{"revision":"5256dc6cc01e874dcc13c9ef10d95d63","url":"images/profile/passport.png"},{"revision":"32493cd446eb9ae677af3a25ab875dc8","url":"images/profile/chip.png"},{"revision":"552f64e6e3449fc2c2fce6a75d654892","url":"images/profile/ccChip.png"},{"revision":"f6851d1c3a5f8d6ea001e4a0fa470571","url":"images/profile/CMND.png"},{"revision":"7e4b750471beebb38302f72d4ef20b7d","url":"images/profile/CCCD.png"},{"revision":"b7f3ccab1a456a3230c136c81d63bfc4","url":"images/profile/CC.png"},{"revision":"219616b0c711dd510ecaccd95c50d539","url":"images/notification/iconReadAll.svg"},{"revision":"ab54e93df6b670f366e698affdafc31e","url":"images/notification/iconNotification.svg"},{"revision":"2fc2d70da1bd2c77bea79615778009da","url":"images/mini-app/iconLink3.png"},{"revision":"e4b7c1bffe5b34f07cc305531ee624d5","url":"images/mini-app/iconLink2.png"},{"revision":"bf079341476ab270f7948d4c1ac31608","url":"images/mini-app/iconLink1.png"},{"revision":"0bdda51e56e65943b68f7f91e1230f53","url":"images/mini-app/ic_payme.svg"},{"revision":"3d63865af6127175e463a12e96ca98a1","url":"images/mini-app/ic_link_4.svg"},{"revision":"bb1dac9e6970491905587c9a0a830175","url":"images/mini-app/ic_link_3.svg"},{"revision":"8e73120be55b73618df44bb1c4130586","url":"images/mini-app/ic_link_2.svg"},{"revision":"1c9d12ffa74c08ea4674bd28d4c9c165","url":"images/mini-app/ic_link_1.svg"},{"revision":"7442085fa677d068e90f2ac764e376db","url":"images/mini-app/ic_link_0.svg"},{"revision":"a9a6aa2586c99542a8cc7a0aa96109bc","url":"images/mini-app/ic_link.svg"},{"revision":"934854ffca2ed2288deccfd0f0e34c89","url":"images/mini-app/bg_link.svg"},{"revision":"b3e0e2792c97e09a398a2e5a851b2fd4","url":"images/kyc/updateCCCD.svg"},{"revision":"d9b997d642af236e2bc45ade1c6bd113","url":"images/kyc/request_kyc.svg"},{"revision":"102e8534c4ce6cf0d0b04a49193bac13","url":"images/kyc/noKYCIcon.svg"},{"revision":"5ab85d313a7d5a21e2f1519b37bc7042","url":"images/kyc/kycRejectedIcon.svg"},{"revision":"8c62cd46f398d33e79bfcd0c82a61594","url":"images/kyc/kycPendingIcon.svg"},{"revision":"39f451c1688284c5a6472c6af0513b80","url":"images/kyc/kycExpiriedIcon.svg"},{"revision":"4b380fc55d573ea382f42b4fbe6c3177","url":"images/kyc/img_nfc_introduce.png"},{"revision":"6f6706431f917652b5083a38f27f0129","url":"images/kyc/icon_nfc_introduce_3.png"},{"revision":"a81e828ef03cb0e11eb888398a4fc1c3","url":"images/kyc/icon_nfc_introduce_2.png"},{"revision":"30f89989228157b4e57fcb76c3554245","url":"images/kyc/icon_nfc_introduce_1.png"},{"revision":"676c281f379b72bdb0e9a86f7ef54d3e","url":"images/kyc/ic_kyc_3.png"},{"revision":"9e77ea35a67f865abf92336b8ab9b914","url":"images/kyc/ic_kyc_2.png"},{"revision":"d8048d18e616ff68fdd98cb646828db4","url":"images/kyc/ic_kyc_1.png"},{"revision":"44380978b895f126896caa1d2ec79464","url":"images/kyc/document.png"},{"revision":"e9ebc6a9a051fac0ed80e384c8bf2834","url":"images/kyc/bg_kyc_2.png"},{"revision":"673752b69a6018b5bc6be763f87a6500","url":"images/kyc/banner_kyc_2.svg"},{"revision":"78bfde5acae2cfeec5efb87452f23cbe","url":"images/insurance/insurance-motor.svg"},{"revision":"444ac91e89ae9efb55abecc9ee9b40a2","url":"images/insurance/insurance-motor-disable.svg"},{"revision":"1e4b1287bd7846325b508b00448700a1","url":"images/insurance/insurance-instruction-motor_icon3.svg"},{"revision":"7dd0eb449da6a2d3c6c3be7123d14d47","url":"images/insurance/insurance-instruction-motor_icon2.svg"},{"revision":"8b3544cb9b073110b9f4e5a0c3652ce8","url":"images/insurance/insurance-instruction-motor_icon1.svg"},{"revision":"4b949ce500fe87bce4eb2d19d56213e2","url":"images/insurance/insurance-instruction-breast_cancer_icon5.svg"},{"revision":"6862a3ccd8ef426263f62ba4f5ce5d34","url":"images/insurance/insurance-instruction-breast_cancer_icon4.svg"},{"revision":"1b9e699f171c041f5c39b896a53c1856","url":"images/insurance/insurance-instruction-breast_cancer_icon3.svg"},{"revision":"3826174342ca36f5c987e3e6dc0d80bf","url":"images/insurance/insurance-instruction-breast_cancer_icon2.svg"},{"revision":"e254181ef75977ba1a1d1d8f0b438422","url":"images/insurance/insurance-instruction-breast_cancer_icon1.svg"},{"revision":"5d4f78156f820a72a6a6137261f64f82","url":"images/insurance/insurance-breast_cancer.svg"},{"revision":"550eaee5baadfe145e1179e87d6e470a","url":"images/insurance/insurance-breast_cancer-disable.svg"},{"revision":"354006aa7ce76d80a2dfe29f70f308d6","url":"images/insurance/insurance-banner-motor.svg"},{"revision":"c493b51b82b74897d1d74d23a4ea6def","url":"images/insurance/insurance-banner-breast_cancer.svg"},{"revision":"2cceea3cf6c06c474f7329c56211cdf8","url":"images/insurance/banner-insurance.svg"},{"revision":"b442b3e4739f0e349ec23901b81d67a9","url":"images/icons/walletMethodIcon.svg"},{"revision":"e5ad3f4f81d53dfc7ea77eb82d867d06","url":"images/icons/walletIcon.png"},{"revision":"10fc4d62dc282d835098b7dfe90d8546","url":"images/icons/timerIcon1.svg"},{"revision":"80f6879fea5b741f16d668bdd23b4d74","url":"images/icons/timerIcon.svg"},{"revision":"79aab8d56011896b5c0b4f4d6384961d","url":"images/icons/policyIcon.svg"},{"revision":"7764ffe63b593559874ed1cb30decbb1","url":"images/icons/pinIcon.svg"},{"revision":"d68c7b083b145ed8d2c779362e205074","url":"images/icons/pictureIcon.png"},{"revision":"5b6af4bc551075abb49e642f5f8cd450","url":"images/icons/pciIcon.svg"},{"revision":"0d31dfa8bd11ee183659b2bca6314f60","url":"images/icons/payme.svg"},{"revision":"80e1a10dbeb36e87d40cdcf1610bf17f","url":"images/icons/paper.svg"},{"revision":"99a6120d052ef8952b26fcbaf161f968","url":"images/icons/notiIcon.svg"},{"revision":"8595e3799b8fabcbe75c9ad6e513423a","url":"images/icons/noKYCIcon.svg"},{"revision":"69ce52fde07896702f46932ba1f7d685","url":"images/icons/logoutIcon.svg"},{"revision":"b4ca4645237b37899c32e62135d2178b","url":"images/icons/lockIcon.svg"},{"revision":"9a5d768a77092c4b2a010b15fcbb3415","url":"images/icons/languageIcon.png"},{"revision":"594f0b273c3541b55cab34246b761d49","url":"images/icons/infoIcon.svg"},{"revision":"e8305dff71fb468bb2ae1619c77f12e5","url":"images/icons/infoBlueIcon.svg"},{"revision":"c6476183b082393b5a6131f1339a818d","url":"images/icons/infoBlackIcon.svg"},{"revision":"c8bd19393d13d977c8ed0905233128f4","url":"images/icons/info.svg"},{"revision":"34712eea2ca10356e2797824c3bb13f7","url":"images/icons/iconTimeWhite.png"},{"revision":"4030caf3d852b21e43153fa7682ea8c4","url":"images/icons/iconLinkedCard.svg"},{"revision":"a72181e12e0f177411f05806cc11ed0e","url":"images/icons/iconDone.svg"},{"revision":"a208ae114b5eaf174344e674a9d5d169","url":"images/icons/historyIcon.svg"},{"revision":"352dc41f34cfec437ca154faca2a7dd1","url":"images/icons/helpIcon.svg"},{"revision":"ff44270ac8e06002b5b55a03e447a2ff","url":"images/icons/generalIcon.svg"},{"revision":"9548c4927beb79abaf1562ecca79faf0","url":"images/icons/filterIcon.svg"},{"revision":"50d8fb94293dad9337ab860611f47a2e","url":"images/icons/editIcon.svg"},{"revision":"95b3147bde998534c02a2c02fd4cd3a0","url":"images/icons/download-2.svg"},{"revision":"ac38e8ac56893c726802ae7b5ca17870","url":"images/icons/creditInfo.svg"},{"revision":"ddc45a90f1172671d62a512d12c35233","url":"images/icons/contactIcon.svg"},{"revision":"18579e7f0daf938d1978af99b6ba8f1a","url":"images/icons/closeIcon.svg"},{"revision":"4c884a8f717529c7aaaa6734e243f473","url":"images/icons/clockIcon.svg"},{"revision":"e2c1b1490f6ce161cb6bb7eceab341fb","url":"images/icons/clockCreditIcon.svg"},{"revision":"c841ae31eb339499b1e8c391f62cf1d4","url":"images/icons/clearIcon.svg"},{"revision":"014e5cb80465d79e4393d61a1073013b","url":"images/icons/circle-info-blue.png"},{"revision":"975ae57e7430b43bcf1a6567b50da153","url":"images/icons/checkIcon.svg"},{"revision":"03a0582ceef8c4dc9678fe567de33b1a","url":"images/icons/caution.svg"},{"revision":"a566270faef0a6d7729799b2519779b6","url":"images/icons/cashSuccessIcon.svg"},{"revision":"7b90d814e46b680b7f2f56191ceb62e2","url":"images/icons/cashPendingIcon.svg"},{"revision":"ba843bdd641969569ff7fb05a8758941","url":"images/icons/cashFailedIcon.svg"},{"revision":"adc94c7238b6a8edbb982a277e706352","url":"images/icons/cardIcon01.svg"},{"revision":"6f9f1f8943216189ea5ab0ad66a5e0d4","url":"images/icons/cardIcon.svg"},{"revision":"2cd52ec0c1865a34efe4d63529231a8e","url":"images/icons/calendarIcon2.png"},{"revision":"0914b96c35f344a3930e59d734459dcd","url":"images/icons/calendarIcon.png"},{"revision":"fb9afbf01be660f3e315fb69d7502029","url":"images/icons/bank.svg"},{"revision":"063913038a8c7fb242cae04d3ac9b754","url":"images/icons/back.svg"},{"revision":"dd3a071f80ab192e9f4b59919ffbb3cd","url":"images/icons/autoPaymentIcon.svg"},{"revision":"529c55b37845fe4997942aea94f9bed6","url":"images/icons/approvedKYCIcon.svg"},{"revision":"8b2409e6cfb1eaac994661e8f0aec9e5","url":"images/icons/accountInfo.svg"},{"revision":"5e539b67d40d97625d9c78afac3aa3e0","url":"images/icons/accountDotIcon.svg"},{"revision":"a85d55e55daaf0354360f7e8aea65c56","url":"images/icons/FaceID.svg"},{"revision":"17050876f8d220c1929b02bfe3aab128","url":"images/icons/transactions/icon_withdraw.svg"},{"revision":"6aac6ef0bbfc9baa589666895f215868","url":"images/icons/transactions/icon_transfer.svg"},{"revision":"520e75bf2f20e4d866fb65e358cc2173","url":"images/icons/transactions/icon_system.svg"},{"revision":"c149345e9c68ee9d08616a9113aee3ca","url":"images/icons/transactions/icon_service_default.svg"},{"revision":"64ef3ad757dbba27d2c39df3f13e6730","url":"images/icons/transactions/icon_require_link_bank.svg"},{"revision":"46a806dfdd83af9789baf6692a33e774","url":"images/icons/transactions/icon_refund.svg"},{"revision":"0edc0b7b0ca94d86832c38c5f161ca22","url":"images/icons/transactions/icon_receive.svg"},{"revision":"8e22377444babaae5bc16d3dcc14e569","url":"images/icons/transactions/icon_promotion.svg"},{"revision":"5099dbff2b8947901e00b2e18bdba7d4","url":"images/icons/transactions/icon_payment_water.svg"},{"revision":"f853774a177c7f231cff4e6279340822","url":"images/icons/transactions/icon_payment_tv.svg"},{"revision":"a8d8658eaf87e284b66e8c2c749eb50e","url":"images/icons/transactions/icon_payment_tuition.svg"},{"revision":"32dbabfadcd358acba737faaa4a309f4","url":"images/icons/transactions/icon_payment_salary_advance.svg"},{"revision":"ad393cd67a63be70e54afe418754c7aa","url":"images/icons/transactions/icon_payment_phone_deposit.svg"},{"revision":"a8e201b82f72edb3a3ff5c9fba25f55b","url":"images/icons/transactions/icon_payment_phone_card.svg"},{"revision":"cfdfe59d9933c61de15d1155cba2903b","url":"images/icons/transactions/icon_payment_internet.svg"},{"revision":"991473247be59b8a93eabba33bf0f9c4","url":"images/icons/transactions/icon_payment_game_card.svg"},{"revision":"a89ec5403969560ed0c3c8d2406039c9","url":"images/icons/transactions/icon_payment_fast_loan.svg"},{"revision":"d8a79e50203877dccec1cac8de328b55","url":"images/icons/transactions/icon_payment_electricity.svg"},{"revision":"fcb61709a183266ad07d08235d013aff","url":"images/icons/transactions/icon_pay_store.svg"},{"revision":"e5b2efef318c038e4c072478d008a418","url":"images/icons/transactions/icon_kyc_expried.svg"},{"revision":"27945534aecb7f131e7f97681a292b04","url":"images/icons/transactions/icon_deposit.svg"},{"revision":"ceda8d5f96f127ef7dfe312ea0b4266d","url":"images/icons/transactions/icon_credit_wallet.svg"},{"revision":"72622b21d5a929c5fdca804da872dd54","url":"images/flags/ic_flag_vietnam.svg"},{"revision":"c26630444459177bdc52a91374d57f7e","url":"images/flags/ic_flag_uk.svg"},{"revision":"bd08c54f9cc512fa0f6a70977f5689f7","url":"images/credit-wallet/successIcon.svg"},{"revision":"9e131f70e3dcf49e98fd82e22e0dc119","url":"images/credit-wallet/moneyIcon.png"},{"revision":"d9765115b91e35fa2fe97bf5d30ef0ab","url":"images/credit-wallet/moneyIcon-colored.png"},{"revision":"db0e726eb99d1180568aa42c72a5da5e","url":"images/credit-wallet/freeIcon.png"},{"revision":"4866abedcb5242ce7fbffc59eca2bb7c","url":"images/credit-wallet/freeIcon-colored.png"},{"revision":"8bbff3969327faea169f961317171e02","url":"images/credit-wallet/discountIcon.png"},{"revision":"d0178de6071aafdf1d0e1a6f4355179d","url":"images/credit-wallet/discountIcon-colored.png"},{"revision":"4e89efd02bac48778e17fe0a355b5b34","url":"images/credit-wallet/credit-wallet-card.png"},{"revision":"4ece5490437f10bc3103b40e7e8eaaa7","url":"images/credit-wallet/credit-title.png"},{"revision":"c765de0406d8ce70a4ab21be3ac2d191","url":"images/credit-wallet/credit-banner.png"},{"revision":"9e28c72deee6a606492a234dad27a922","url":"images/credit/backgroundApproved.png"},{"revision":"9f290893479ada495dc30a266d96a111","url":"images/credit/Wallet.png"},{"revision":"9449cf3cebb74297e4c244d5185eb3e6","url":"images/credit/UngLuong.png"},{"revision":"70c3ea7b8e6919fab4b307289a6dc2c6","url":"images/credit/TienIch.png"},{"revision":"68a8ae20ef682c646898fef0421daa43","url":"images/credit/NguonLK.png"},{"revision":"3cd43cb0adc4dd72563482e0eeaa9562","url":"images/credit/BaoHiem.png"},{"revision":"03dc03968fe785a2e17f1c1ceb3c6365","url":"images/artworks/warningDefault.png"},{"revision":"ffa937470d19f7745eb4e0a8e35d8716","url":"images/artworks/networkError.png"},{"revision":"6c7e5f3545aa1b7ea0646c2a3282700e","url":"images/artworks/logout.png"},{"revision":"f2d5a42c10a916e0dcb71142300288a8","url":"images/artworks/kycRegulation.png"},{"revision":"dc8110e61e0e4eb31e92a68ca30607a0","url":"images/artworks/invalidIcon.png"},{"revision":"d868b10fb837fd1c901f08ee07d8aaba","url":"images/artworks/expiredIcon.png"},{"revision":"a5f4e164ecad2114757286082d2d8531","url":"images/artworks/doiPINThanhCong.png"},{"revision":"b6cfc4b45e9064e70353f6516c4b146c","url":"images/artworks/bioErrorIcon.png"},{"revision":"ad734472a153b3d85a7f47803d332eed","url":"images/artworks/XacNhanMail.png"},{"revision":"66e3ea30e7435f3dfc210861b5e3337c","url":"images/artworks/Waiting.png"},{"revision":"108d79300bd1ba78c8e11b66768adaec","url":"images/artworks/UpdateThanhCong.png"},{"revision":"ca62784c478ecd4678d5b430a7f3341c","url":"images/artworks/ThongBao.png"},{"revision":"a55fff68caad5b1a96203d078e867f7d","url":"images/artworks/SendSuccess.png"},{"revision":"32bf829c599fb9a933c1019b7f0391f9","url":"images/artworks/SendError.png"},{"revision":"510585045367861684175d736c33a4cf","url":"images/artworks/Search.png"},{"revision":"6adcd5efd8821903eebd3bc1f5942800","url":"images/artworks/QRkhongtimthay.png"},{"revision":"78d4ef0b0de7618f67925505fc35dcbc","url":"images/artworks/PayME_Pin.png"},{"revision":"8e1b7d4358c7368b6ceba715b5be5fae","url":"images/artworks/OTP.png"},{"revision":"1f5084cff30638b5f926ccf0371f23ce","url":"images/artworks/NextUpdate.png"},{"revision":"59b173cfdecb82dfe2fc0a463226fb5a","url":"images/artworks/MoTaiKhoanThatBai.png"},{"revision":"c772042605e63cf9ae7e483711470d34","url":"images/artworks/MoTaiKhoanPending.png"},{"revision":"38a38485ddb6771f8017eb66dd5e242c","url":"images/artworks/LienKetTheThatBai.png"},{"revision":"612a00e8ce1964b08b92032e5beb4f1e","url":"images/artworks/LienKetTheThanhCong.png"},{"revision":"af5aad429dd776cebde6156ea9445386","url":"images/artworks/LichSuGiaoDich.png"},{"revision":"3cbc23f5111954cfc8172a55a90a5900","url":"images/artworks/KhongHoTroNFC.png"},{"revision":"a8a28ea11572fe80be6af1cc5a794119","url":"images/artworks/KhoaxacminhTK.png"},{"revision":"0712a0393774391e02a475dde427d274","url":"images/artworks/Khoataikhoan.png"},{"revision":"6f8a4f851a73b4c1f75fc7d6c2f4b923","url":"images/artworks/KhoaPIN.png"},{"revision":"16719b847b956b893ffd202c2647a2b1","url":"images/artworks/KYCthatbai.png"},{"revision":"7454c6919532b0c5028ac453a034bcf6","url":"images/artworks/KYCthanhcong.png"},{"revision":"1a407cc87069f347140fd73b98eb51c6","url":"images/artworks/KYCdoiduyet.png"},{"revision":"f8e9497e254e554428f7878ea8c951ba","url":"images/artworks/KYCcanduyet.png"},{"revision":"900a22994e44bf2681725aec05b101d6","url":"images/artworks/KYCWaiting_1.png"},{"revision":"3cfc55b03e71a28a5a3f060385632d6b","url":"images/artworks/KYCWaiting3.png"},{"revision":"bf3e5a3f688201b4b90f6694a979d4ae","url":"images/artworks/KYCCapNhat.png"},{"revision":"50b8c4966125d4a63b06a982010fcab9","url":"images/artworks/ID_card.png"},{"revision":"701ccd3f0280fc04a4b0b75e12272317","url":"images/artworks/EmptyLinedList.png"},{"revision":"b1c5027d53d54f24a8db150ff138b632","url":"images/artworks/DaMoTaiKhoan.png"},{"revision":"f2132e92365f939698eb9653430086a9","url":"images/artworks/CreditRejected.png"},{"revision":"e32a6a153df59aceaba226447cd24e6a","url":"images/artworks/CreditPending.png"},{"revision":"860d665e3bff6873b1d46c7867272032","url":"images/artworks/CreditApproved.png"}]);
  var fileExtensionRegexp = new RegExp("/[^/?]+\\.[^/]+$");
  registerRoute(
    // Trả về false để yêu cầu không được phục vụ bằng index.html.
    ({ request, url }) => {
      if (request.mode !== "navigate") {
        return false;
      }
      if (url.pathname.startsWith("/_")) {
        return false;
      }
      if (url.pathname.match(fileExtensionRegexp)) {
        return false;
      }
      return true;
    },
    createHandlerBoundToURL(`${""}/index.html`)
  );
  registerRoute(
    // Thêm phần mở rộng tệp hoặc điều kiện định tuyến khác nếu cần.
    ({ url }) => url.origin === self.location.origin && url.pathname.endsWith(".png"),
    // Tùy chỉnh chiến lược nếu cần, ví dụ đổi thành CacheFirst.
    new StaleWhileRevalidate({
      cacheName: "images",
      plugins: [
        // Khi cache lúc chạy đạt kích thước tối đa,
        // xóa các ảnh ít được dùng gần đây nhất.
        new ExpirationPlugin({ maxEntries: 50 })
      ]
    })
  );
  self.addEventListener("message", (event) => {
    if (event.data && event.data.type === "SKIP_WAITING") {
      self.skipWaiting();
    }
  });
})();
